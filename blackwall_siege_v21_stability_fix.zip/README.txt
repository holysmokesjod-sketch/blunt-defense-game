BLACKWALL SIEGE - Three.js Tower Defense

WHAT'S NEW IN THIS BUILD (ULTIMATE VISUAL OVERHAUL)
- FIXED: Map now fully visible (reduced fog density + optimized camera angle)
- FREE PLACEMENT towers anywhere valid (ground or on glowing monuments/pads)
- TOWERS HAVE A LIFE OF THEIR OWN: Idle particles, core pulses, breathing animations. Each level-up makes them MORE CHAOTIC (jitters, orbiting corruption orbs, wild color flashes, extra sparks at lvl 4)
- BLACKHOLE added in cosmic sky with realistic swirling accretion disks, Einstein ring, dynamic glow (grass + space theme complete)
- VOLCANO + CASTLE + BLACKHOLE + lush grass + psychedelic space sky = most immersive TD map ever
- ENEMIES move FUNNY & WEIRD: Exaggerated bouncy walks, flailing limbs, head bobs, lean tilts, aura pulses - bosses feel alive and threatening
- BEST VISUALS: Enhanced shaders, massive particle explosions on hits/upgrades, screen shake, dynamic lights, shockwave FX, glowing trails, level-up evolution bursts, more detailed tower/enemy models with personality
- Attacks feel spectacular: Bigger splashes, chain lightning with beams, fire bursts with ember smoke, sniper flashes, turret muzzle pops, hawk bursts

FILES
- index.html
- style.css
- script.js

HOW TO RUN
- Extract the zip
- Open index.html in a modern browser
- Click to place towers on valid ground or monuments
- Use the UI to upgrade and sell towers

NOTES
- Random/Chaos tower can roll from the hidden tower pool
- Pads are monuments now, but still clickable build anchors
- Built for local browser play with Three.js loaded from CDN
