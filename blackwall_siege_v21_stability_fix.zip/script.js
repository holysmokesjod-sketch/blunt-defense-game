(() => {
  const container = document.getElementById('gameContainer');
  const ui = {
    gold: document.getElementById('gold'),
    lives: document.getElementById('lives'),
    wave: document.getElementById('wave'),
    enemiesLeft: document.getElementById('enemiesLeft'),
    startWaveBtn: document.getElementById('startWaveBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    speedBtn: document.getElementById('speedBtn'),
    towerDetails: document.getElementById('towerDetails'),
    upgradeBtn: document.getElementById('upgradeBtn'),
    sellBtn: document.getElementById('sellBtn'),
    message: document.getElementById('message')
  };

  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', alpha: true, preserveDrawingBuffer: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = true;
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111d33);
  scene.fog = new THREE.FogExp2(0x13213a, 0.00235);

  const camera = new THREE.PerspectiveCamera(48, window.innerWidth / window.innerHeight, 0.1, 400);
  const cameraBasePos = new THREE.Vector3(72, 65, 92);
  const cameraLookAt = new THREE.Vector3(82, 6, 38);
  camera.position.copy(cameraBasePos);
  camera.lookAt(cameraLookAt);

  const world = new THREE.Group();
  scene.add(world);

  const WORLD_BOUNDS = { minX: -20, maxX: 165, minZ: -15, maxZ: 80 };
  const BUILD_LANE_INNER = 3.2;
  const BUILD_LANE_OUTER = 12.25;
  const TOWER_FOOTPRINT = 1.6;
  const staticFootprints = [];
  let buildLaneOverlay = null;

  const game = {
    gold: 260,
    lives: 25,
    wave: 0,
    speed: 1,
    paused: false,
    waveActive: false,
    spawnTimer: 0,
    spawnIndex: 0,
    selectedBuild: 'arrow',
    selectedTower: null,
    hoveredPad: null,
    gameOver: false,
    time: 0,
    screenShake: 0,
    towers: [],
    pads: [],
    enemies: [],
    projectiles: [],
    particles: [],
    beams: [],
    torches: [],
    mistPlanes: [],
    flashLights: [],
    flags: [],
    ufos: [],
    waterFX: [],
    skyFX: [],
    shaderMats: [],
    events: [],
    volcanoFX: [],
    skyEventTimer: 3.2,
    mapEventTimer: 4.8,
    cameraLerp: 0,
    cameraStartPos: null,
    cameraStartLook: null,
    cameraTargetPos: null,
    cameraTargetLook: null,
    forbiddenPositions: [],
    npcs: [],
    creatures: [],
    decorFX: [],
  };

  const interactive = [];
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const curvePoints = [
    new THREE.Vector3(-16, 0, 5),
    new THREE.Vector3(6, 0, 4),
    new THREE.Vector3(18, 0, 10),
    new THREE.Vector3(34, 0, 10),
    new THREE.Vector3(48, 0, 23),
    new THREE.Vector3(71, 0, 23),
    new THREE.Vector3(87, 0, 8),
    new THREE.Vector3(114, 0, 8),
    new THREE.Vector3(128, 0, 23),
    new THREE.Vector3(128, 0, 49),
    new THREE.Vector3(144, 0, 64),
    new THREE.Vector3(168, 0, 64),
  ];
  const pathCurve = new THREE.CatmullRomCurve3(curvePoints, false, 'centripetal');
  const pathLength = pathCurve.getLength();
  let currentWave = [];
  let buildSurface = null;
  let placementGhost = null;
  const tempVecA = new THREE.Vector3();
  const tempVecB = new THREE.Vector3();

  const towerDefs = {
    arrow: { name: 'Longbow Keep', cost: 55, range: 4.75, fireRate: 0.42, damage: 15, projectileSpeed: 44, color: 0x3fbf7f, glow: 0x8fffd2, projectileColor: 0xcfffee, persona: 'A vigilant ranger tower lined with animated archers and rapid volleys.' },
    ballista: { name: 'Ballista Bastion', cost: 95, range: 6.25, fireRate: 1.05, damage: 54, projectileSpeed: 60, color: 0xc88a3d, glow: 0xffd39b, projectileColor: 0xfff0d4, pierce: 2, persona: 'A heavy bolt engine with punishing anti-column pierce.' },
    bombard: { name: 'Bombard Forge', cost: 140, range: 5.75, fireRate: 1.65, damage: 44, projectileSpeed: 28, color: 0xd64f4f, glow: 0xff9f73, projectileColor: 0x2f333c, splash: 7.5, persona: 'A smoke-belching cannon tower with explosive shells.' },
    frost: { name: 'Frost Reliquary', cost: 110, range: 4.5, fireRate: 0.86, damage: 13, projectileSpeed: 38, color: 0x5ad8ff, glow: 0xc7f8ff, projectileColor: 0xe9feff, slow: 0.48, persona: 'A floating ice shrine with orbiting shards and crowd control.' },
    sunfire: { name: 'Sunfire Chapel', cost: 155, range: 5.25, fireRate: 1.15, damage: 76, projectileSpeed: 52, color: 0xffc93a, glow: 0xfff2a6, projectileColor: 0xfff7d1, persona: 'A radiant chapel weapon that deletes elites with solar judgment.' },
    storm: { name: 'Storm Spire', cost: 165, range: 5.25, fireRate: 0.95, damage: 31, projectileSpeed: 64, color: 0x7b6dff, glow: 0xc9c2ff, projectileColor: 0xe7e3ff, chain: 2, persona: 'A crackling tesla tower with chain-burst lightning.' },
    alchemist: { name: 'Plague Lab', cost: 125, range: 4.5, fireRate: 0.72, damage: 24, projectileSpeed: 34, color: 0x8bd83c, glow: 0xdfff8f, projectileColor: 0xeeffb0, splash: 5.2, persona: 'A toxic brew tower that hurls glowing vials.' },
    dragon: { name: 'Dragon Roost', cost: 190, range: 6.0, fireRate: 1.05, damage: 58, projectileSpeed: 40, color: 0xff7a2f, glow: 0xffb877, projectileColor: 0xffd0a1, splash: 6.2, persona: 'A perched drake tower with scorching burst fire.' },
    sniper: { name: 'Moonshot Perch', baseType: 'ballista', cost: 175, range: 8.5, fireRate: 1.85, damage: 86, projectileSpeed: 82, color: 0xf4f7ff, glow: 0xbfd1ff, projectileColor: 0xffffff, pierce: 1, persona: 'A long-range marksman perch built for execution shots.' },
    turret: { name: 'Iron Turret', baseType: 'arrow', cost: 135, range: 5.0, fireRate: 0.24, damage: 10, projectileSpeed: 58, color: 0xb07258, glow: 0xffd2b0, projectileColor: 0xffdfbf, persona: 'A rotating auto-turret that chews through swarms.' },
    hawk: { name: 'Sky Talon Aerie', baseType: 'dragon', cost: 160, range: 6.0, fireRate: 0.9, damage: 28, projectileSpeed: 50, color: 0x6f4f2e, glow: 0xd5b889, projectileColor: 0xf2dec0, splash: 3.2, persona: 'A hunting tower that launches falcons to slash from above.' },
    wildcard: { name: 'Chaos Vault', cost: 175, range: 0, fireRate: 1, damage: 0, projectileSpeed: 0, color: 0xff4fd8, glow: 0xffb8f4, projectileColor: 0xffffff, persona: 'Roll one of ten hidden towers that cannot be built normally.' },
    hiddenVoidNeedler: { name: 'Void Needler', baseType: 'ballista', hidden: true, cost: 175, range: 9.0, fireRate: 1.75, damage: 96, projectileSpeed: 92, color: 0x6e46ff, glow: 0xd6c7ff, projectileColor: 0xf3eeff, pierce: 2, persona: 'A hidden anti-boss sniper threaded with voidlight.' },
    hiddenWarIdol: { name: 'War Idol', baseType: 'ballista', hidden: true, cost: 165, range: 6.0, fireRate: 0.96, damage: 62, projectileSpeed: 62, color: 0xd3a062, glow: 0xffebb9, projectileColor: 0xfff3db, pierce: 3, persona: 'A hidden war engine that hammers columns.' },
    hiddenGlacierEye: { name: 'Glacier Eye', baseType: 'frost', hidden: true, cost: 160, range: 4.75, fireRate: 0.74, damage: 26, projectileSpeed: 38, color: 0x4fe7ff, glow: 0xdbffff, projectileColor: 0xf0ffff, slow: 0.42, persona: 'A hidden freezing eye with brutal lane control.' },
    hiddenSunLance: { name: 'Sunlance Basilica', baseType: 'sunfire', hidden: true, cost: 195, range: 6.0, fireRate: 1.02, damage: 43, projectileSpeed: 52, color: 0xf3ba2f, glow: 0xfff1af, projectileColor: 0xfff6d1, persona: 'A hidden radiant weapon with sharper beam chains.' },
    hiddenSkyReaver: { name: 'Sky Reaver', baseType: 'dragon', hidden: true, cost: 185, range: 6.25, fireRate: 0.78, damage: 36, projectileSpeed: 56, color: 0xa16a34, glow: 0xf3d7ae, projectileColor: 0xf3e6c8, splash: 4.2, persona: 'A hidden predatory rookery with vicious raptor passes.' },
    hiddenBlightCauldron: { name: 'Blight Cauldron', baseType: 'alchemist', hidden: true, cost: 170, range: 4.75, fireRate: 0.66, damage: 29, projectileSpeed: 36, color: 0x6ce039, glow: 0xdbff96, projectileColor: 0xf0ffbf, splash: 5.8, persona: 'A hidden plague tower that floods lanes with virulent toxins.' },
    hiddenMeteorNest: { name: 'Meteor Nest', baseType: 'dragon', hidden: true, cost: 205, range: 6.0, fireRate: 1.14, damage: 64, projectileSpeed: 46, color: 0xff5a32, glow: 0xffb26b, projectileColor: 0xffcc94, splash: 5.6, persona: 'A hidden drake nest with heavier splash fire.' },
    hiddenShockMill: { name: 'Shock Mill', baseType: 'arrow', hidden: true, cost: 170, range: 5.25, fireRate: 0.18, damage: 12, projectileSpeed: 64, color: 0x9f86ff, glow: 0xdff7ff, projectileColor: 0xf0fbff, persona: 'A hidden sentry that spits hypercharged rounds.' },
    hiddenDoomMortar: { name: 'Doom Mortar', baseType: 'bombard', hidden: true, cost: 205, range: 6.0, fireRate: 1.45, damage: 52, projectileSpeed: 32, color: 0xff6b3a, glow: 0xffbf7a, projectileColor: 0xffd59c, splash: 7.0, persona: 'A hidden artillery monstrosity with larger blast zones.' },
    hiddenRangerCathedral: { name: 'Ranger Cathedral', baseType: 'arrow', hidden: true, cost: 160, range: 5.25, fireRate: 0.34, damage: 18, projectileSpeed: 48, color: 0x86d06e, glow: 0xefffbc, projectileColor: 0xf8ffd7, persona: 'A hidden archer citadel that floods lanes with elegant volleys.' }
  };

  const hiddenTowerPool = Object.keys(towerDefs).filter(key => towerDefs[key].hidden);

  const towerFamilyPalette = {
    arrow: { primary: 0x4fdc8f, accent: 0xdfffe8 },
    ballista: { primary: 0xd79242, accent: 0xffebb9 },
    bombard: { primary: 0xf05b4d, accent: 0xffc091 },
    frost: { primary: 0x5ad8ff, accent: 0xeaffff },
    sunfire: { primary: 0xffca39, accent: 0xfff4b3 },
    storm: { primary: 0x8a74ff, accent: 0xe3ddff },
    alchemist: { primary: 0x90eb45, accent: 0xf0ffbd },
    dragon: { primary: 0xff7a2f, accent: 0xffddb2 },
    sniper: { primary: 0xf0f6ff, accent: 0xb8d6ff },
    turret: { primary: 0xbe7c56, accent: 0xffd8bf },
    hawk: { primary: 0x7d5a33, accent: 0xf1ddb7 }
  };

  function colorizeTowerMaterials(root, displayType, projectileColor) {
    const palette = towerFamilyPalette[displayType] || towerFamilyPalette[root.type] || null;
    if (!palette) return;
    root.traverse(obj => {
      if (!obj.isMesh || !obj.material) return;
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      for (const mat of mats) {
        if ('emissive' in mat && mat.emissiveIntensity > 0.5) {
          if (mat.color) mat.color.setHex(palette.accent);
          mat.emissive?.setHex(projectileColor || palette.primary);
        } else if ('metalness' in mat && mat.metalness > 0.45) {
          if (mat.color) mat.color.lerp(new THREE.Color(palette.accent), 0.35);
        } else if (mat.color && mat.color.getHex && (mat.color.getHex() === 0x795737 || mat.color.getHex()===0x7b6756 || mat.color.getHex()===0x6b5b56 || mat.color.getHex()===0x61788c || mat.color.getHex()===0x8b7056 || mat.color.getHex()===0x5e5f82 || mat.color.getHex()===0x6d6f57 || mat.color.getHex()===0x6f5a54)) {
          mat.color.lerp(new THREE.Color(palette.primary), 0.45);
        }
      }
    });
  }

  const enemyDefs = {
    raider: { name: 'Raider', hp: 58, speed: 7.2, reward: 10, color: 0xbd714f, emissive: 0x3b180d, size: 1.08 },
    scout: { name: 'Scout', hp: 44, speed: 8.7, reward: 9, color: 0x6fb38d, emissive: 0x173629, size: 0.98 },
    knight: { name: 'Knight', hp: 132, speed: 4.8, reward: 18, color: 0x8f9bc0, emissive: 0x202b4a, size: 1.28 },
    rider: { name: 'Wolf Rider', hp: 92, speed: 8.1, reward: 14, color: 0x9d8056, emissive: 0x36250f, size: 1.14 },
    cultist: { name: 'Fire Cultist', hp: 106, speed: 6.25, reward: 16, color: 0xee8648, emissive: 0x59210f, size: 1.18 },
    brute: { name: 'Siege Brute', hp: 250, speed: 3.7, reward: 28, color: 0xa84749, emissive: 0x421012, size: 1.62 },
    warWagon: { name: 'War Wagon', hp: 210, speed: 4.2, reward: 24, color: 0x9b755e, emissive: 0x3f291b, size: 1.72 },
    plagueCart: { name: 'Plague Cart', hp: 235, speed: 3.8, reward: 26, color: 0x7ea157, emissive: 0x21371b, size: 1.76 },
    dreadKnight: { name: 'Dread Knight', hp: 700, speed: 3.9, reward: 90, color: 0x905fff, emissive: 0x38146e, size: 1.9, phase: 'miniBoss' },
    pyreAbbot: { name: 'Pyre Abbot', hp: 760, speed: 4.1, reward: 95, color: 0xff6a5f, emissive: 0x68140f, size: 1.9, phase: 'miniBoss' },
    batteringRam: { name: 'Battering Ram', hp: 960, speed: 2.9, reward: 105, color: 0xc49b77, emissive: 0x4b3320, size: 2.25, phase: 'miniBoss' },
    astralWarden: { name: 'Astral Warden', hp: 1650, speed: 3.2, reward: 180, color: 0x9d86ff, emissive: 0x4d2fa2, size: 2.15, phase: 'boss' }
  };

  const materials = {
    ground: new THREE.MeshStandardMaterial({ color: 0x3f6642, roughness: 0.95, metalness: 0.02 }),
    road: new THREE.MeshStandardMaterial({ color: 0xa38b63, roughness: 0.97, metalness: 0.02 }),
    roadEdge: new THREE.MeshStandardMaterial({ color: 0x726246, roughness: 1 }),
    stone: new THREE.MeshStandardMaterial({ color: 0x7b828d, roughness: 0.88, metalness: 0.08 }),
    wood: new THREE.MeshStandardMaterial({ color: 0x5a412d, roughness: 0.94 }),
    darkMetal: new THREE.MeshStandardMaterial({ color: 0x343b46, roughness: 0.52, metalness: 0.4 }),
    grass: new THREE.MeshStandardMaterial({ color: 0x4c7a53, roughness: 1 }),
    ember: new THREE.MeshBasicMaterial({ color: 0xffab5c }),
  };

  const tmpVecA = new THREE.Vector3();
  const tmpVecB = new THREE.Vector3();
  const clock = new THREE.Clock();

  function registerStaticFootprint(x, z, radius, type = 'obstacle') {
    staticFootprints.push({ position: new THREE.Vector3(x, 0, z), radius, type });
  }

  function clearStaticFootprints() {
    staticFootprints.length = 0;
  }

  function rand(min, max) {
    return min + Math.random() * (max - min);
  }


  function makeGlowShaderMaterial(colorA, colorB, opts = {}) {
    const uniforms = {
      uTime: { value: 0 },
      uColorA: { value: new THREE.Color(colorA) },
      uColorB: { value: new THREE.Color(colorB) },
      uOpacity: { value: opts.opacity ?? 0.7 },
      uSpeed: { value: opts.speed ?? 1.0 }
    };
    const material = new THREE.ShaderMaterial({
      uniforms,
      transparent: true,
      depthWrite: false,
      side: opts.side || THREE.DoubleSide,
      blending: opts.blending || THREE.AdditiveBlending,
      vertexShader: `
        varying vec2 vUv;
        uniform float uTime;
        uniform float uSpeed;
        void main() {
          vUv = uv;
          vec3 transformed = position;
          transformed.z += sin((uv.x + uv.y * 1.2) * 6.283185 + uTime * uSpeed) * 0.015;
          transformed.x += cos((uv.y + uv.x * 0.5) * 6.283185 + uTime * (uSpeed * 0.7)) * 0.01;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform vec3 uColorA;
        uniform vec3 uColorB;
        uniform float uOpacity;
        uniform float uTime;
        void main() {
          vec2 p = vUv - 0.5;
          float radial = 1.0 - smoothstep(0.08, 0.76, length(p) * 1.35);
          float wave = 0.5 + 0.5 * sin((vUv.y * 8.0) + (vUv.x * 4.0) + uTime * 2.4);
          float pulse = 0.6 + 0.4 * sin(uTime * 2.0 + vUv.y * 7.0);
          float alpha = radial * wave * pulse * uOpacity;
          vec3 col = mix(uColorA, uColorB, clamp(vUv.y * 0.75 + wave * 0.25, 0.0, 1.0));
          gl_FragColor = vec4(col, alpha);
        }
      `,
    });
    game.shaderMats.push(material);
    return material;
  }

  function makeLavaShaderMaterial(colorA = 0xff5a1f, colorB = 0xffc14f, opts = {}) {
    const uniforms = {
      uTime: { value: 0 },
      uColorA: { value: new THREE.Color(colorA) },
      uColorB: { value: new THREE.Color(colorB) },
      uOpacity: { value: opts.opacity ?? 0.95 },
      uSpeed: { value: opts.speed ?? 1.0 }
    };
    const material = new THREE.ShaderMaterial({
      uniforms,
      transparent: true,
      depthWrite: false,
      side: opts.side || THREE.DoubleSide,
      blending: opts.blending || THREE.AdditiveBlending,
      vertexShader: `
        varying vec2 vUv;
        uniform float uTime;
        uniform float uSpeed;
        void main() {
          vUv = uv;
          vec3 transformed = position;
          transformed.z += sin((uv.x * 11.0) + uTime * (2.5 * uSpeed)) * 0.02;
          transformed.y += cos((uv.y * 14.0) + uTime * (1.8 * uSpeed)) * 0.01;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform vec3 uColorA;
        uniform vec3 uColorB;
        uniform float uOpacity;
        uniform float uTime;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
        float noise(vec2 p){
          vec2 i = floor(p);
          vec2 f = fract(p);
          float a = hash(i);
          float b = hash(i + vec2(1.0,0.0));
          float c = hash(i + vec2(0.0,1.0));
          float d = hash(i + vec2(1.0,1.0));
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(a,b,u.x) + (c-a)*u.y*(1.0-u.x) + (d-b)*u.x*u.y;
        }
        void main(){
          vec2 p = vUv * vec2(3.0, 8.0);
          p.y += uTime * 1.2;
          float n = noise(p) * 0.8 + noise(p * 1.8 + 7.0) * 0.2;
          float glow = smoothstep(0.3, 0.95, n);
          float edge = 1.0 - smoothstep(0.25, 0.5, length(vUv - 0.5));
          vec3 col = mix(uColorA, uColorB, glow);
          gl_FragColor = vec4(col, glow * edge * uOpacity);
        }
      `,
    });
    game.shaderMats.push(material);
    return material;
  }

  function randomGroundPoint() {
    for (let i = 0; i < 40; i++) {
      const x = rand(-14, 152);
      const z = rand(-12, 72);
      if (distanceToPathXZ(x, z) > 8 && !(x > 118 && z > 54)) return new THREE.Vector3(x, 0, z);
    }
    return new THREE.Vector3(20, 0, 20);
  }

  function showMessage(text) {
    ui.message.textContent = text;
    ui.message.classList.add('show');
    clearTimeout(showMessage.timer);
    showMessage.timer = setTimeout(() => ui.message.classList.remove('show'), 1800);
  }

  function getUpgradeCost(tower) {
    return Math.round(tower.baseCost * (0.68 + tower.level * 0.42));
  }

  function getTowerAbilities(tower) {
    const tier = tower.level;
    const kind = tower.displayType || tower.type;
    const map = {
      arrow: ['Volley Shot', 'Ranger Splitshot', 'Hunter Crits'], ballista: ['Pinning Bolts', 'Twin Release', 'Armor Break'], bombard: ['Bigger Blast', 'Cluster Burst', 'Molten Quake'],
      frost: ['Cold Pulse', 'Permafrost Burst', 'Deep Freeze'], sunfire: ['Solar Chain', 'Scorch Mark', 'Radiant Nova'], storm: ['Chain Lightning', 'Static Surge', 'Thunder Lock'],
      alchemist: ['Acid Splash', 'Corrosive Rain', 'Gold Transmute'], dragon: ['Dual Fireballs', 'Burning Aura', 'Meteor Breath'], sniper: ['Headshot', 'Piercing Sight', 'Execution Round'], turret: ['Twin Barrels', 'Tracer Storm', 'Suppression Field'], hawk: ['Swoop Strike', 'Falcon Flock', 'Bleeding Talons'], wildcard: ['Chaos Roll', 'Wild Upgrade', 'Mythic Pull']
    };
    return (map[kind] || []).slice(0, Math.max(0, tier - 1));
  }

  function updateHUD() {
    ui.gold.textContent = Math.floor(game.gold);
    ui.lives.textContent = Math.max(0, Math.floor(game.lives));
    ui.wave.textContent = game.wave;
    ui.enemiesLeft.textContent = game.enemies.length + Math.max(0, currentWave.length - game.spawnIndex);

    if (game.selectedTower) {
      const t = game.selectedTower;
      const upgradeCost = getUpgradeCost(t);
      const bits = [`Level ${t.level}`, `${Math.round(t.damage)} dmg`, `${Math.round(t.range)} range`];
      if (t.splash) bits.push(`${Math.round(t.splash)} splash`);
      if (t.slow) bits.push(`${Math.round(t.slow * 100)}% slow`);
      if (t.pierce) bits.push(`${t.pierce} pierce`);
      if (t.chain) bits.push(`${t.chain} chain`);
      const abilities = getTowerAbilities(t);
      ui.towerDetails.innerHTML = `<strong>${t.name}</strong><br>${bits.join(' · ')}<br><em>${t.persona || ''}</em><br>${abilities.length ? `Abilities: ${abilities.join(' · ')}` : 'Level up to unlock extra abilities.'}<br>Upgrade cost ${upgradeCost}`;
      ui.upgradeBtn.disabled = t.level >= 4 || game.gold < upgradeCost;
      ui.sellBtn.disabled = false;
    } else {
      ui.towerDetails.innerHTML = 'Select a tower and click the field to place it.<br><em>Every upgrade unlocks a new ability, and towers can be placed freely off the road.</em>';
      ui.upgradeBtn.disabled = true;
      ui.sellBtn.disabled = true;
    }
  }

  function buildScene() {
    buildLights();
    buildSky();
    buildTerrain();
    buildPath();
    buildCastle();
    buildNPCs();
    buildBackgroundCreatures();
    try { buildGraphicsPolish(); } catch (err) { console.warn('Graphics polish skipped:', err); }
    buildRangeIndicator();
  }

  function buildLights() {
    const hemi = new THREE.HemisphereLight(0xd3edff, 0x1b2c1b, 2.25);
    scene.add(hemi);

    const moon = new THREE.DirectionalLight(0xbad4ff, 2.1);
    moon.position.set(58, 82, 18);
    moon.castShadow = true;
    moon.shadow.mapSize.set(2048, 2048);
    moon.shadow.camera.left = -140;
    moon.shadow.camera.right = 140;
    moon.shadow.camera.top = 140;
    moon.shadow.camera.bottom = -140;
    moon.shadow.bias = -0.00012;
    moon.shadow.normalBias = 0.02;
    scene.add(moon);

    const astralFill = new THREE.DirectionalLight(0xa06cff, 0.65);
    astralFill.position.set(-40, 38, -52);
    scene.add(astralFill);

    const cyanFill = new THREE.PointLight(0x69d8ff, 2.4, 180, 2);
    cyanFill.position.set(92, 32, 10);
    scene.add(cyanFill);

    const magentaFill = new THREE.PointLight(0xc067ff, 1.5, 120, 2);
    magentaFill.position.set(30, 24, 42);
    scene.add(magentaFill);

    const gateWarm = new THREE.PointLight(0xffbf74, 2.1, 72, 2);
    gateWarm.position.set(140, 10, 62);
    scene.add(gateWarm);

    const riverRim = new THREE.PointLight(0x75d5ff, 1.4, 130, 2);
    riverRim.position.set(170, 7, 32);
    scene.add(riverRim);

    const siegeGlow = new THREE.PointLight(0xff8a5b, 0.9, 90, 2);
    siegeGlow.position.set(18, 9, -2);
    scene.add(siegeGlow);
  }

  function buildSky() {
    const moon = new THREE.Mesh(
      new THREE.SphereGeometry(4.4, 24, 24),
      new THREE.MeshBasicMaterial({ color: 0xf5f2ec })
    );
    moon.position.set(112, 70, -86);
    scene.add(moon);

    const moonGlow = new THREE.Mesh(
      new THREE.SphereGeometry(14, 24, 24),
      new THREE.MeshBasicMaterial({ color: 0xd8e8ff, transparent: true, opacity: 0.14 })
    );
    moonGlow.position.copy(moon.position);
    scene.add(moonGlow);

    const planet = new THREE.Mesh(
      new THREE.SphereGeometry(9.5, 32, 32),
      new THREE.MeshBasicMaterial({ color: 0x7d6cff, transparent: true, opacity: 0.9 })
    );
    planet.position.set(-48, 64, -92);
    scene.add(planet);
    const planetRing = new THREE.Mesh(
      new THREE.TorusGeometry(14, 0.22, 10, 64),
      new THREE.MeshBasicMaterial({ color: 0xf49eff, transparent: true, opacity: 0.4 })
    );
    planetRing.position.copy(planet.position);
    planetRing.rotation.x = 1.1;
    planetRing.rotation.y = 0.35;
    scene.add(planetRing);
    game.skyFX.push({ mesh: planetRing, kind: 'planetRing', speed: 0.06 });

    const starGeometry = new THREE.BufferGeometry();
    const starCount = 950;
    const positions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      positions[i * 3] = rand(-130, 200);
      positions[i * 3 + 1] = rand(34, 120);
      positions[i * 3 + 2] = rand(-170, -15);
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const stars = new THREE.Points(starGeometry, new THREE.PointsMaterial({ color: 0xe7f0ff, size: 0.55, transparent: true, opacity: 0.92 }));
    scene.add(stars);

    const nebulaColors = [0x56d8ff, 0xc86cff, 0x88ffcb, 0xff80dd];
    for (let i = 0; i < 8; i++) {
      const nebula = new THREE.Mesh(
        new THREE.SphereGeometry(1, 16, 12),
        new THREE.MeshBasicMaterial({ color: nebulaColors[i % nebulaColors.length], transparent: true, opacity: 0.08, depthWrite: false })
      );
      nebula.scale.set(rand(12, 28), rand(4, 8), rand(10, 18));
      nebula.position.set(rand(-30, 160), rand(44, 78), rand(-120, -54));
      scene.add(nebula);
      game.skyFX.push({ mesh: nebula, kind: 'nebula', baseY: nebula.position.y, phase: rand(0, Math.PI * 2), speed: rand(0.16, 0.34) });
    }

    for (let i = 0; i < 3; i++) {
      const arc = new THREE.Mesh(
        new THREE.TorusGeometry(20 + i * 6, 0.45, 6, 72, Math.PI * 0.72),
        new THREE.MeshBasicMaterial({ color: i % 2 ? 0x74ffd1 : 0xbb6fff, transparent: true, opacity: 0.2 })
      );
      arc.position.set(28 + i * 24, 44 + i * 5, -68 - i * 4);
      arc.rotation.z = 0.55 + i * 0.2;
      arc.rotation.x = 0.3;
      scene.add(arc);
      game.skyFX.push({ mesh: arc, kind: 'auroraArc', speed: 0.08 + i * 0.02 });
    }

    function createUfo(x, y, z, scale, color) {
      const group = new THREE.Group();
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(2.6 * scale, 4.2 * scale, 1.0 * scale, 24), new THREE.MeshStandardMaterial({ color: 0x8c98aa, metalness: 0.56, roughness: 0.38 }));
      group.add(disc);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(1.55 * scale, 18, 18), new THREE.MeshStandardMaterial({ color: 0x8be7ff, emissive: color, emissiveIntensity: 0.55, transparent: true, opacity: 0.75 }));
      dome.scale.y = 0.55;
      dome.position.y = 0.48 * scale;
      group.add(dome);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2 * scale, 0.11 * scale, 8, 30), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75 }));
      ring.rotation.x = Math.PI / 2;
      group.add(ring);
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.7 * scale, 2.2 * scale, 10 * scale, 18, 1, true), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.11, side: THREE.DoubleSide, depthWrite: false }));
      beam.position.y = -5.2 * scale;
      group.add(beam);
      const light = new THREE.PointLight(color, 1.5, 26 * scale, 2);
      light.position.y = -1.2 * scale;
      group.add(light);
      group.position.set(x, y, z);
      scene.add(group);
      game.ufos.push({ group, ring, beam, light, base: new THREE.Vector3(x, y, z), phase: rand(0, Math.PI * 2), speed: rand(0.35, 0.72) });
    }

    createUfo(18, 23, -6, 0.75, 0x69edff);
    createUfo(66, 27, 18, 0.92, 0xcf72ff);
    createUfo(122, 30, 28, 0.84, 0x8effbb);

    function createBlackhole() {
      const bhGroup = new THREE.Group();
      const horizon = new THREE.Mesh(
        new THREE.SphereGeometry(6.5, 48, 48),
        new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.98 })
      );
      bhGroup.add(horizon);

      const diskMat1 = makeGlowShaderMaterial(0xffaa33, 0xff4400, { opacity: 0.75, speed: 0.9, side: THREE.DoubleSide });
      const disk1 = new THREE.Mesh(new THREE.TorusGeometry(9.8, 2.1, 12, 72), diskMat1);
      disk1.rotation.x = 1.35;
      disk1.position.y = 0.8;
      bhGroup.add(disk1);
      game.shaderMats.push(diskMat1);

      const diskMat2 = makeGlowShaderMaterial(0x88ddff, 0xffffff, { opacity: 0.35, speed: 1.6, side: THREE.DoubleSide });
      const disk2 = new THREE.Mesh(new THREE.TorusGeometry(7.2, 1.4, 10, 64), diskMat2);
      disk2.rotation.x = 1.28;
      disk2.position.y = 0.3;
      bhGroup.add(disk2);
      game.shaderMats.push(diskMat2);

      const ringMat = makeGlowShaderMaterial(0xffffff, 0xaaddff, { opacity: 0.9, speed: 2.4 });
      const einsteinRing = new THREE.Mesh(new THREE.TorusGeometry(11.5, 0.35, 8, 80), ringMat);
      einsteinRing.rotation.x = 1.32;
      bhGroup.add(einsteinRing);
      game.shaderMats.push(ringMat);

      const bhLight = new THREE.PointLight(0xff8833, 2.8, 180, 1.5);
      bhLight.position.set(0, 4, 0);
      bhGroup.add(bhLight);

      bhGroup.position.set(-65, 95, -125);
      bhGroup.scale.set(1.1, 1.1, 1.1);
      scene.add(bhGroup);

      game.skyFX.push({ mesh: disk1, kind: 'blackholeDisk', speed: 0.7, phase: 0, light: bhLight, baseY: 0.8 });
      game.skyFX.push({ mesh: disk2, kind: 'blackholeDisk', speed: 1.35, phase: 1.2, baseY: 0.3 });
      game.skyFX.push({ mesh: einsteinRing, kind: 'blackholeRing', speed: 0.4, phase: 0.8 });
    }
    createBlackhole();
  }

  function buildTerrain() {
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(230, 150), materials.ground);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    ground.userData.type = 'ground';
    ground.material.side = THREE.DoubleSide;
    buildSurface = ground;
    world.add(ground);
    clearStaticFootprints();

    const meadowPatches = [0x426d48, 0x355a3a, 0x2e4d34, 0x507a53];
    for (let i = 0; i < 22; i++) {
      const patch = new THREE.Mesh(
        new THREE.CircleGeometry(rand(7, 16), 24),
        new THREE.MeshStandardMaterial({ color: meadowPatches[i % meadowPatches.length], roughness: 1, transparent: true, opacity: rand(0.28, 0.55) })
      );
      patch.rotation.x = -Math.PI / 2;
      patch.position.set(rand(-20, 165), 0.03 + i * 0.0005, rand(-10, 74));
      if (distanceToPathXZ(patch.position.x, patch.position.z) < 7) continue;
      world.add(patch);
    }

    const farHillMat = new THREE.MeshStandardMaterial({ color: 0x355540, roughness: 1 });
    for (let i = 0; i < 6; i++) {
      const hill = new THREE.Mesh(new THREE.SphereGeometry(18 + i * 3, 20, 14), farHillMat);
      hill.scale.y = rand(0.18, 0.38);
      hill.position.set(-24 + i * 38 + rand(-7, 7), 1.2 + i * 0.15, -28 - i * 7);
      hill.receiveShadow = true;
      world.add(hill);
    }

    const river = new THREE.Mesh(
      new THREE.PlaneGeometry(76, 166),
      new THREE.MeshStandardMaterial({ color: 0x1f385d, roughness: 0.22, metalness: 0.24, transparent: true, opacity: 0.94, emissive: 0x112a44, emissiveIntensity: 0.3 })
    );
    river.rotation.x = -Math.PI / 2;
    river.position.set(182, -0.02, 34);
    world.add(river);
    game.waterFX.push({ mesh: river, kind: 'river', baseColor: new THREE.Color(0x1f385d) });

    for (let i = 0; i < 16; i++) {
      const ripple = new THREE.Mesh(
        new THREE.RingGeometry(rand(0.4, 1.0), rand(1.2, 2.2), 28),
        new THREE.MeshBasicMaterial({ color: i % 2 ? 0x93cfff : 0xb16fff, transparent: true, opacity: 0.09 })
      );
      ripple.rotation.x = -Math.PI / 2;
      ripple.position.set(rand(153, 210), 0.01, rand(-14, 82));
      world.add(ripple);
      game.waterFX.push({ mesh: ripple, kind: 'ripple', phase: rand(0, Math.PI * 2), speed: rand(0.8, 1.6) });
    }

    const bankMat = new THREE.MeshStandardMaterial({ color: 0x6e664d, roughness: 1 });
    for (let i = 0; i < 18; i++) {
      const rock = new THREE.Mesh(new THREE.BoxGeometry(rand(2.5, 5.5), rand(0.7, 2.2), rand(2.5, 4.8)), bankMat);
      rock.position.set(rand(145, 152), rand(0.25, 0.9), rand(-10, 78));
      rock.rotation.y = rand(-0.5, 0.5);
      rock.castShadow = rock.receiveShadow = true;
      world.add(rock);
    }

    function addTree(x, z, scale = 1, variant = null) {
      if (variant === null) variant = Math.floor(Math.random() * 5);

      const trunkH = rand(2.4, 5.2) * scale;
      const trunkColor = variant === 4 ? 0x2a1f15 : 0x332419;
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22 * scale, 0.38 * scale, trunkH, 7),
        new THREE.MeshStandardMaterial({ color: trunkColor, roughness: 1 })
      );
      trunk.position.set(x, trunkH / 2, z);
      trunk.castShadow = trunk.receiveShadow = true;
      world.add(trunk);

      const leafColors = variant === 4 ? [0x3a2a1f] : [0x1f3f25, 0x28492e, 0x1a3a22, 0x2a5a32];
      for (let j = 0; j < (variant === 4 ? 2 : 4); j++) {
        const crown = new THREE.Mesh(
          new THREE.SphereGeometry(rand(1.1, 2.6) * scale, 12, 12),
          new THREE.MeshStandardMaterial({ color: leafColors[j % leafColors.length], roughness: 1 })
        );
        crown.position.set(
          x + rand(-0.6, 0.6) * scale,
          trunkH * 0.82 + rand(0.7, 1.6) * scale,
          z + rand(-0.6, 0.6) * scale
        );
        crown.castShadow = crown.receiveShadow = true;
        world.add(crown);
      }

      if (variant === 0 || variant === 2) {
        const vine = new THREE.Mesh(
          new THREE.CylinderGeometry(0.04 * scale, 0.03 * scale, rand(1.5, 2.8) * scale, 4),
          new THREE.MeshStandardMaterial({ color: 0x1a4a2a, roughness: 0.9 })
        );
        vine.position.set(x + 0.3 * scale, trunkH * 0.6, z);
        vine.rotation.z = rand(-0.4, 0.4);
        vine.castShadow = vine.receiveShadow = true;
        world.add(vine);
      }

      if (variant === 3) {
        const mush = new THREE.Mesh(
          new THREE.SphereGeometry(0.25 * scale, 8, 8),
          new THREE.MeshStandardMaterial({ color: 0x88ffaa, emissive: 0x44ff88, emissiveIntensity: 0.8 })
        );
        mush.position.set(x, trunkH + 0.6 * scale, z);
        mush.castShadow = mush.receiveShadow = true;
        world.add(mush);
      }

    }

    for (let i = 0; i < 140; i++) {
      const x = rand(-18, 165);
      const z = rand(-12, 78);
      if (distanceToPathXZ(x, z) < 5.5 || (z > 58 && x > 118)) continue;
      addTree(x, z, rand(0.7, 1.45));
    }


    const grassColors = [0x4c7a53, 0x608e61, 0x3f6847, 0x5c8c63];
    for (let i = 0; i < 720; i++) {
      const x = rand(-22, 168);
      const z = rand(-10, 76);
      if (distanceToPathXZ(x, z) < 2.6) continue;
      const blade = new THREE.Mesh(
        new THREE.ConeGeometry(rand(0.05, 0.14), rand(0.25, 0.9), 4),
        new THREE.MeshStandardMaterial({ color: grassColors[i % grassColors.length], roughness: 1 })
      );
      blade.position.set(x, blade.geometry.parameters.height / 2, z);
      blade.rotation.y = rand(0, Math.PI * 2);
      blade.rotation.z = rand(-0.12, 0.12);
      world.add(blade);
    }

    for (let i = 0; i < 90; i++) {
      const x = rand(-20, 170);
      const z = rand(-8, 74);
      if (distanceToPathXZ(x, z) < 3.5) continue;
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(rand(0.12, 0.48), 0), new THREE.MeshStandardMaterial({ color: 0x48535e, roughness: 1 }));
      rock.position.set(x, rand(0.05, 0.24), z);
      rock.rotation.set(rand(0, Math.PI), rand(0, Math.PI), rand(0, Math.PI));
      rock.castShadow = rock.receiveShadow = true;
      world.add(rock);
    }

    for (let i = 0; i < 14; i++) {
      const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(rand(0.25, 0.6), 0), new THREE.MeshStandardMaterial({ color: i % 2 ? 0xa06cff : 0x60f5ff, emissive: i % 2 ? 0x7b4bff : 0x2dcfff, emissiveIntensity: 0.65, roughness: 0.18, metalness: 0.12 }));
      const x = rand(4, 138); const z = rand(-6, 62);
      if (distanceToPathXZ(x, z) < 5.5) continue;
      crystal.position.set(x, rand(0.5, 1.2), z);
      crystal.scale.y = rand(1.6, 3.2);
      crystal.rotation.y = rand(0, Math.PI);
      crystal.castShadow = true;
      world.add(crystal);
      game.skyFX.push({ mesh: crystal, kind: 'crystal', baseY: crystal.position.y, phase: rand(0, Math.PI * 2), speed: rand(0.8, 1.4) });
    }

    for (let i = 0; i < 3; i++) {
      const circle = new THREE.Group();
      const outer = new THREE.Mesh(new THREE.RingGeometry(2.6, 3.4, 48), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x72ffd1 : 0xb86fff, transparent: true, opacity: 0.3, side: THREE.DoubleSide }));
      outer.rotation.x = -Math.PI / 2;
      circle.add(outer);
      const inner = new THREE.Mesh(new THREE.RingGeometry(0.8, 1.6, 32), new THREE.MeshBasicMaterial({ color: 0xecfff3, transparent: true, opacity: 0.18, side: THREE.DoubleSide }));
      inner.rotation.x = -Math.PI / 2;
      inner.position.y = 0.01;
      circle.add(inner);
      for (let j = 0; j < 12; j++) {
        const rune = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.02, 0.64), new THREE.MeshBasicMaterial({ color: 0xe8e2ff, transparent: true, opacity: 0.35 }));
        const a = j / 12 * Math.PI * 2;
        rune.position.set(Math.cos(a) * 2.35, 0.02, Math.sin(a) * 2.35);
        rune.rotation.y = -a;
        circle.add(rune);
      }
      circle.position.set(20 + i * 34, 0.05, 48 - i * 12);
      if (distanceToPathXZ(circle.position.x, circle.position.z) > 8) {
        world.add(circle);
        game.skyFX.push({ mesh: circle, kind: 'cropCircle', phase: rand(0, Math.PI * 2), speed: 0.5 + i * 0.15 });
      }
    }

    for (let i = 0; i < 4; i++) {
      const mist = new THREE.Mesh(
        new THREE.PlaneGeometry(rand(38, 72), rand(11, 18)),
        new THREE.MeshBasicMaterial({ color: i % 2 ? 0xe7fff3 : 0xe7d7ff, transparent: true, opacity: 0.05, depthWrite: false })
      );
      mist.rotation.x = -Math.PI / 2;
      mist.position.set(42 + i * 24, 0.16 + i * 0.05, 22 + i * 7);
      game.mistPlanes.push({ mesh: mist, baseX: mist.position.x, speed: rand(0.8, 1.5), amp: rand(1.4, 3.2), phase: rand(0, Math.PI * 2), kind: 'mist' });
      world.add(mist);
    }

    const palisadeMat = new THREE.MeshStandardMaterial({ color: 0x5b432b, roughness: 1 });
    for (let i = 0; i < 12; i++) {
      const stake = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 2.0, 6), palisadeMat);
      stake.position.set(-12 + i * 1.4, 1.0, 7 + Math.sin(i * 0.5) * 1.2);
      stake.rotation.z = rand(-0.08, 0.08);
      stake.castShadow = stake.receiveShadow = true;
      world.add(stake);
    }

    const cart = new THREE.Group();
    const cartBody = new THREE.Mesh(new THREE.BoxGeometry(3.1, 1.0, 1.9), new THREE.MeshStandardMaterial({ color: 0x73543a, roughness: 0.95 }));
    cartBody.position.y = 1.0;
    cart.add(cartBody);
    for (const dx of [-1.1, 1.1]) {
      for (const dz of [-0.9, 0.9]) {
        const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.18, 14), new THREE.MeshStandardMaterial({ color: 0x3a2b1d, roughness: 0.9 }));
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(dx, 0.42, dz);
        cart.add(wheel);
      }
    }
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.48, 1.0, 10), new THREE.MeshStandardMaterial({ color: 0x654831, roughness: 0.95 }));
    barrel.rotation.z = Math.PI / 2;
    barrel.position.set(-0.4, 1.7, 0);
    cart.add(barrel);
    cart.position.set(-10, 0, -1);
    cart.rotation.y = -0.45;
    cart.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
    world.add(cart);
    game.forbiddenPositions.push(cart.position.clone());

    const tentColors = [0x6b1b22, 0x505d74, 0x785d3d];
    for (let i = 0; i < 3; i++) {
      const tent = new THREE.Group();
      const cloth = new THREE.Mesh(new THREE.ConeGeometry(1.6, 2.3, 4, 1), new THREE.MeshStandardMaterial({ color: tentColors[i], roughness: 1 }));
      cloth.rotation.y = Math.PI / 4;
      cloth.position.y = 1.15;
      tent.add(cloth);
      const frame = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.2, 6), new THREE.MeshStandardMaterial({ color: 0x3c2b1d }));
      frame.position.y = 1.1;
      tent.add(frame);
      tent.position.set(-3 + i * 3.2, 0, -8 + (i % 2) * 3.2);
      tent.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
      world.add(tent);
    }

    const volcano = new THREE.Group();
    const volcanoBase = new THREE.Mesh(new THREE.ConeGeometry(24, 20, 28, 1, true), new THREE.MeshStandardMaterial({ color: 0x30271f, roughness: 1 }));
    volcanoBase.position.set(54, 8, -62);
    volcanoBase.scale.y = 0.75;
    volcanoBase.castShadow = volcanoBase.receiveShadow = true;
    volcano.add(volcanoBase);
    const volcanoCap = new THREE.Mesh(new THREE.CylinderGeometry(7.2, 9.2, 4.2, 22, 1, true), new THREE.MeshStandardMaterial({ color: 0x1f1716, roughness: 1 }));
    volcanoCap.position.set(54, 16.8, -62);
    volcanoCap.castShadow = volcanoCap.receiveShadow = true;
    volcano.add(volcanoCap);
    const craterGlow = new THREE.Mesh(new THREE.CircleGeometry(5.8, 28), makeLavaShaderMaterial(0xff4d1f, 0xffd160, { opacity: 0.8, speed: 1.2 }));
    craterGlow.rotation.x = -Math.PI / 2;
    craterGlow.position.set(54, 18.95, -62);
    volcano.add(craterGlow);
    const lavaFall = new THREE.Mesh(new THREE.PlaneGeometry(7, 14), makeLavaShaderMaterial(0xff5c1c, 0xffde73, { opacity: 0.58, speed: 1.5 }));
    lavaFall.position.set(56.5, 12.6, -53.2);
    lavaFall.rotation.x = -0.15;
    lavaFall.rotation.z = -0.24;
    volcano.add(lavaFall);
    const volcanoLight = new THREE.PointLight(0xff7a30, 1.4, 70, 2);
    volcanoLight.position.set(54, 21, -58);
    volcano.add(volcanoLight);
    for (let i = 0; i < 7; i++) {
      const smoke = new THREE.Mesh(new THREE.SphereGeometry(rand(1.8, 3.6), 16, 16), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x4a3b46 : 0x332f36, transparent: true, opacity: 0.22, depthWrite: false }));
      smoke.position.set(54 + rand(-1.8, 1.8), 20 + i * 2.2, -62 + rand(-1.5, 1.5));
      volcano.add(smoke);
      game.volcanoFX.push({ kind: 'smoke', mesh: smoke, base: smoke.position.clone(), phase: rand(0, Math.PI * 2), speed: rand(0.5, 1.0) });
    }
    const emberCone = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.9, 10, 16, 1, true), makeGlowShaderMaterial(0xff8c47, 0xfff1a8, { opacity: 0.25, speed: 1.2 }));
    emberCone.position.set(54, 22.5, -62);
    volcano.add(emberCone);
    volcano.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
    world.add(volcano);
    game.volcanoFX.push({ kind: 'light', light: volcanoLight, phase: rand(0, Math.PI * 2) });
    game.volcanoFX.push({ kind: 'emberCone', mesh: emberCone, phase: rand(0, Math.PI * 2) });

    for (let i = 0; i < 24; i++) {
      const cluster = new THREE.Group();
      const x = i < 12 ? rand(-14, 154) : (i % 2 ? rand(-18, 8) : rand(136, 166));
      const z = i < 12 ? (i % 2 ? rand(-13, -4) : rand(68, 78)) : rand(-10, 74);
      if (distanceToPathXZ(x, z) < 8 || (x > 118 && z > 54)) continue;
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(rand(0.7, 1.6), 0), new THREE.MeshStandardMaterial({ color: 0x231b19, roughness: 1 }));
      rock.position.y = rand(0.45, 0.9);
      rock.rotation.set(rand(0, Math.PI), rand(0, Math.PI), rand(0, Math.PI));
      cluster.add(rock);
      const crack = new THREE.Mesh(new THREE.CircleGeometry(rand(0.45, 0.95), 18), makeLavaShaderMaterial(0xff5127, 0xffd85a, { opacity: 0.45, speed: rand(0.8, 1.5) }));
      crack.rotation.x = -Math.PI / 2;
      crack.position.y = rock.position.y + 0.02;
      cluster.add(crack);
      cluster.position.set(x, 0, z);
      cluster.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
      world.add(cluster);
      game.volcanoFX.push({ kind: 'lavaRock', group: cluster, rock, crack, phase: rand(0, Math.PI * 2), speed: rand(0.5, 1.2) });
    }
  }

  function buildPath() {
    function buildRibbon(halfWidth, y, material, offset = 0) {
      const segments = 180;
      const positions = [], normals = [], uvs = [], indices = [];
      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const p = pathCurve.getPointAt(t);
        const prev = pathCurve.getPointAt(Math.max(0, t - 1 / segments));
        const next = pathCurve.getPointAt(Math.min(1, t + 1 / segments));
        const tangent = next.clone().sub(prev).setY(0).normalize();
        const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
        const left = p.clone().addScaledVector(normal, halfWidth + offset);
        const right = p.clone().addScaledVector(normal, -halfWidth + offset);
        positions.push(left.x, y, left.z, right.x, y, right.z);
        normals.push(0, 1, 0, 0, 1, 0);
        uvs.push(0, t * 9, 1, t * 9);
        if (i < segments) {
          const a = i * 2;
          indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
        }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      geo.setIndex(indices);
      const mesh = new THREE.Mesh(geo, material);
      mesh.receiveShadow = true;
      return mesh;
    }

    const shoulder = buildRibbon(3.8, 0.04, new THREE.MeshStandardMaterial({ color: 0x5c4f3a, roughness: 1 }));
    const road = buildRibbon(2.9, 0.11, new THREE.MeshStandardMaterial({ color: 0x8c7a5e, roughness: 0.95 }));
    const rutLeft = buildRibbon(0.32, 0.13, new THREE.MeshStandardMaterial({ color: 0x6b5a48, roughness: 1, transparent: true, opacity: 0.55 }), -0.9);
    const rutRight = buildRibbon(0.32, 0.13, new THREE.MeshStandardMaterial({ color: 0x6b5a48, roughness: 1, transparent: true, opacity: 0.55 }), 0.9);
    world.add(shoulder, road, rutLeft, rutRight);

    for (let i = 0; i <= 160; i++) {
      const t = i / 160;
      const p = pathCurve.getPointAt(t);
      if (i % 2 === 0) {
        const cobble = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.04, 0.38), new THREE.MeshStandardMaterial({ color: 0xc8b38a }));
        cobble.position.set(p.x + (Math.random() - 0.5) * 1.8, 0.15, p.z + (Math.random() - 0.5) * 1.4);
        cobble.rotation.y = Math.random() * Math.PI;
        world.add(cobble);
      }
      if (i % 12 === 0) {
        for (const side of [-1, 1]) {
          const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.15, 0.9, 6), new THREE.MeshStandardMaterial({ color: 0x3f2e1f }));
          const markerPos = p.clone().add(new THREE.Vector3(side * 3.6, 0, 0));
          post.position.set(markerPos.x, 0.45, markerPos.z);
          world.add(post);
          const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffe070 }));
          lantern.position.set(markerPos.x, 0.95, markerPos.z);
          world.add(lantern);
        }
      }
    }
  }

  function buildCastle() {
    const castle = new THREE.Group();
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x9aa3af, roughness: 0.88, metalness: 0.06 });
    const darkStoneMat = new THREE.MeshStandardMaterial({ color: 0x7a828d, roughness: 0.92 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x4f5867, roughness: 0.95 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5a4030, roughness: 1 });

    const outerWall = new THREE.Mesh(new THREE.BoxGeometry(24, 8, 11), stoneMat);
    outerWall.position.set(140, 4, 63);
    outerWall.castShadow = outerWall.receiveShadow = true;
    castle.add(outerWall);

    const gatehouse = new THREE.Mesh(new THREE.BoxGeometry(8, 10, 10.5), darkStoneMat);
    gatehouse.position.set(137.5, 5, 63);
    gatehouse.castShadow = gatehouse.receiveShadow = true;
    castle.add(gatehouse);

    const gateArch = new THREE.Mesh(new THREE.BoxGeometry(4.2, 4.8, 10.8), woodMat);
    gateArch.position.set(136.9, 2.4, 63);
    gateArch.castShadow = gateArch.receiveShadow = true;
    castle.add(gateArch);

    for (let i = 0; i < 7; i++) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.14, 4.2, 0.2), new THREE.MeshStandardMaterial({ color: 0x30343b, metalness: 0.6, roughness: 0.4 }));
      bar.position.set(136.7, 2.2, 60.4 + i * 0.85);
      castle.add(bar);
    }

    const keep = new THREE.Mesh(new THREE.BoxGeometry(10, 11, 8), stoneMat);
    keep.position.set(145.5, 5.5, 63);
    keep.castShadow = keep.receiveShadow = true;
    castle.add(keep);

    const keepRoof = new THREE.Mesh(new THREE.ConeGeometry(5.8, 4, 4), roofMat);
    keepRoof.position.set(145.5, 13, 63);
    keepRoof.rotation.y = Math.PI / 4;
    keepRoof.castShadow = true;
    castle.add(keepRoof);

    const towerGeo = new THREE.CylinderGeometry(2.7, 3.1, 12, 8);
    const towerPositions = [
      [131.8, 6, 57.8], [131.8, 6, 68.2], [148.8, 6, 57.8], [148.8, 6, 68.2]
    ];
    towerPositions.forEach(pos => {
      const t = new THREE.Mesh(towerGeo, stoneMat);
      t.position.set(pos[0], pos[1], pos[2]);
      t.castShadow = t.receiveShadow = true;
      castle.add(t);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(3.15, 3.6, 8), roofMat);
      roof.position.set(pos[0], 13.8, pos[2]);
      roof.castShadow = true;
      castle.add(roof);
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * Math.PI * 2;
        const battlement = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.9, 0.7), darkStoneMat);
        battlement.position.set(pos[0] + Math.cos(a) * 2.6, 12.2, pos[2] + Math.sin(a) * 2.6);
        castle.add(battlement);
      }
    });

    for (let i = 0; i < 8; i++) {
      const merlon = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.0, 0.9), darkStoneMat);
      merlon.position.set(131.2 + i * 2.3, 8.8, 57.2);
      castle.add(merlon);
      const merlon2 = merlon.clone();
      merlon2.position.z = 68.8;
      castle.add(merlon2);
    }

    for (let i = 0; i < 4; i++) {
      const window = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 1.1), new THREE.MeshBasicMaterial({ color: 0xffdd98, transparent: true, opacity: 0.7 }));
      window.position.set(145.5, 6.7 + (i % 2) * 2.3, 60.2 + i * 1.7);
      window.rotation.y = -Math.PI / 2;
      castle.add(window);
    }

    const bannerMat = new THREE.MeshStandardMaterial({ color: 0x6b1520, roughness: 0.85, side: THREE.DoubleSide });
    [[132.2, 11.6, 57.8], [149.3, 11.6, 68.2], [145.5, 14.5, 58.8]].forEach(pos => {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.2, 6), new THREE.MeshStandardMaterial({ color: 0x2a2d32 }));
      pole.position.set(pos[0], pos[1], pos[2]);
      castle.add(pole);
      const banner = new THREE.Mesh(new THREE.PlaneGeometry(2.1, 1.3), bannerMat.clone());
      banner.position.set(pos[0] + 1.0, pos[1] + 0.1, pos[2]);
      banner.rotation.y = -Math.PI / 2;
      castle.add(banner);
      game.flags.push({ mesh: banner, baseY: banner.position.y, baseRotY: banner.rotation.y, phase: rand(0, Math.PI * 2), hue: rand(0, 1) });
    });

    function addHouse(x, z, sx, sz, color) {
      const house = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(sx, 3.8, sz), new THREE.MeshStandardMaterial({ color: 0xbcb2a1, roughness: 1 }));
      body.position.y = 1.9;
      house.add(body);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(sx, sz) * 0.8, 2.8, 4), new THREE.MeshStandardMaterial({ color, roughness: 1 }));
      roof.position.y = 5.0;
      roof.rotation.y = Math.PI / 4;
      house.add(roof);
      const door = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.7, 0.14), woodMat);
      door.position.set(0, 0.9, sz / 2 + 0.03);
      house.add(door);
      for (const wx of [-sx * 0.22, sx * 0.22]) {
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.7), new THREE.MeshBasicMaterial({ color: 0xffd79b, transparent: true, opacity: 0.65 }));
        win.position.set(wx, 2.0, sz / 2 + 0.08);
        house.add(win);
      }
      house.position.set(x, 0, z);
      house.rotation.y = rand(-0.15, 0.15);
      house.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
      castle.add(house);
    }

    addHouse(154, 56.5, 4.4, 3.8, 0x5d6473);
    addHouse(154.8, 69.2, 5.0, 4.2, 0x7a5d42);
    addHouse(160.5, 62.4, 4.2, 3.6, 0x4b5668);

    // MORE BUILDINGS
    addHouse(25, -18, 5.5, 4.2, 0x5d6473);
    addHouse(48, 68, 4.8, 3.9, 0x7a5d42);
    addHouse(112, -9, 6.2, 4.8, 0x4b5668);
    addHouse(138, 55, 5.0, 4.0, 0x6b5a4a);
    addHouse(162, 12, 4.5, 3.6, 0x52453a);

    // Watchtowers
    for (let i = 0; i < 4; i++) {
      const tw = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.3, 5, 6), new THREE.MeshStandardMaterial({ color: 0x6b6254 }));
      base.position.y = 2.5;
      tw.add(base);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.6, 2.2, 6), new THREE.MeshStandardMaterial({ color: 0x4a3f35 }));
      roof.position.y = 6.2;
      tw.add(roof);
      tw.position.set(18 + i * 38, 0, 62 - i * 8);
      tw.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(tw);
    }

    const bridge = new THREE.Mesh(new THREE.BoxGeometry(8, 0.5, 6.2), woodMat);
    bridge.position.set(147.5, 0.25, 63.2);
    bridge.castShadow = bridge.receiveShadow = true;
    castle.add(bridge);
    for (let i = 0; i < 6; i++) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(7.8, 0.08, 0.72), new THREE.MeshStandardMaterial({ color: 0x76563b, roughness: 1 }));
      plank.position.set(147.5, 0.54, 61.2 + i * 0.8);
      castle.add(plank);
    }

    [[134.8, 3.7, 57.5], [141.8, 4.0, 68.7], [148.6, 3.6, 61.2], [144.8, 6.0, 68.0], [154.3, 2.1, 61.8]].forEach(pos => {
      const torch = createTorch(pos[0], pos[1], pos[2]);
      castle.add(torch.group);
      game.torches.push(torch);
    });

    registerStaticFootprint(140, 63, 8.5, 'castle');
    registerStaticFootprint(145.5, 63, 6.4, 'castleKeep');
    registerStaticFootprint(131.8, 57.8, 3.4, 'tower');
    registerStaticFootprint(131.8, 68.2, 3.4, 'tower');
    registerStaticFootprint(148.8, 57.8, 3.4, 'tower');
    registerStaticFootprint(148.8, 68.2, 3.4, 'tower');
    registerStaticFootprint(154, 56.5, 3.1, 'house');
    registerStaticFootprint(154.8, 69.2, 3.1, 'house');
    registerStaticFootprint(160.5, 62.4, 3.0, 'house');
    registerStaticFootprint(25, -18, 3.2, 'house');
    registerStaticFootprint(48, 68, 3.0, 'house');
    registerStaticFootprint(112, -9, 3.5, 'house');
    registerStaticFootprint(138, 55, 3.2, 'house');
    registerStaticFootprint(162, 12, 3.0, 'house');
    for (let i = 0; i < 4; i++) registerStaticFootprint(18 + i * 38, 62 - i * 8, 3.2, 'watchtower');
    buildLaneOverlay = buildLaneOverlay || createBuildLaneOverlay();
    if (buildLaneOverlay && !buildLaneOverlay.parent) world.add(buildLaneOverlay);

    world.add(castle);
  }

  function buildNPCs() {
    const skinTones = [0xf0d9be, 0xd9b48b, 0xb88459, 0x7a573a, 0x4f3424];
    const hairColors = [0x1e1714, 0x4a2f1d, 0x7a4f2e, 0xc29a62, 0x6f1d1b];
    const clothPalette = [0x7a1f2b, 0x23456b, 0x466b2d, 0x6a4d9e, 0xb36a2e, 0x3c3c46];

    for (let i = 0; i < 18; i++) {
      const npc = new THREE.Group();
      const skin = skinTones[Math.floor(Math.random() * skinTones.length)];
      const hairColor = hairColors[Math.floor(Math.random() * hairColors.length)];
      const clothColor = clothPalette[Math.floor(Math.random() * clothPalette.length)];
      const trimColor = clothPalette[Math.floor(Math.random() * clothPalette.length)];
      const role = ['villager', 'guard', 'merchant'][Math.floor(Math.random() * 3)];

      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.98, 6, 12), new THREE.MeshStandardMaterial({ color: clothColor, roughness: 0.82 }));
      torso.position.y = 0.62;
      npc.add(torso);

      const chestTrim = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.35, 0.05), new THREE.MeshStandardMaterial({ color: trimColor, metalness: 0.15, roughness: 0.7 }));
      chestTrim.position.set(0, 0.72, 0.2);
      npc.add(chestTrim);

      const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 16), new THREE.MeshStandardMaterial({ color: skin, roughness: 0.68 }));
      head.position.y = 1.24;
      npc.add(head);

      for (let f = 0; f < 8; f++) {
        const freckle = new THREE.Mesh(new THREE.SphereGeometry(0.012, 4, 4), new THREE.MeshBasicMaterial({ color: 0x8b5a2b }));
        freckle.position.set((Math.random() - 0.5) * 0.2, 1.24 + (Math.random() - 0.5) * 0.12, 0.18 + (Math.random() - 0.5) * 0.05);
        npc.add(freckle);
      }

      const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 12), new THREE.MeshStandardMaterial({ color: skin, roughness: 0.75 }));
      jaw.position.set(0, 1.14, 0.03);
      jaw.scale.set(1, 0.72, 0.88);
      npc.add(jaw);

      const hairStyle = Math.floor(Math.random() * 5);
      if (hairStyle === 0) {
        const hair = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.9 }));
        hair.position.y = 1.37;
        hair.scale.set(1.05, 0.62, 1);
        npc.add(hair);
      } else if (hairStyle === 1) {
        const hair = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.18, 0.28, 10), new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.82 }));
        hair.position.y = 1.4;
        npc.add(hair);
      } else if (hairStyle === 2) {
        const hood = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.48, 8), new THREE.MeshStandardMaterial({ color: trimColor, roughness: 0.9 }));
        hood.position.y = 1.42;
        npc.add(hood);
      } else if (hairStyle === 3) {
        const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 0.18, 10), new THREE.MeshStandardMaterial({ color: 0x2a2220, roughness: 0.95 }));
        hat.position.y = 1.46;
        npc.add(hat);
      } else {
        const crest = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.18, 0.2), new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.82 }));
        crest.position.y = 1.45;
        npc.add(crest);
      }

      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.036, 8, 8), new THREE.MeshBasicMaterial({ color: 0x1a1412 }));
      eyeL.position.set(-0.065, 1.28, 0.175);
      npc.add(eyeL);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.065;
      npc.add(eyeR);

      const browL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.012, 0.012), new THREE.MeshBasicMaterial({ color: hairColor }));
      browL.position.set(-0.065, 1.34, 0.18);
      npc.add(browL);
      const browR = browL.clone();
      browR.position.x = 0.065;
      npc.add(browR);

      if (Math.random() > 0.45) {
        const mustache = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.016, 0.014), new THREE.MeshBasicMaterial({ color: hairColor }));
        mustache.position.set(0, 1.205, 0.19);
        npc.add(mustache);
      }

      const shoulderL = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshStandardMaterial({ color: trimColor, roughness: 0.8 }));
      shoulderL.position.set(-0.23, 0.8, 0);
      shoulderL.scale.set(1.2, 0.7, 1);
      npc.add(shoulderL);
      const shoulderR = shoulderL.clone();
      shoulderR.position.x = 0.23;
      npc.add(shoulderR);

      let prop = null;
      if (role === 'guard') {
        const spear = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.95, 6), new THREE.MeshStandardMaterial({ color: 0x72502f, roughness: 0.9 }));
        spear.position.set(0.28, 0.85, 0);
        spear.rotation.z = 0.12;
        npc.add(spear);
        const spearTip = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.14, 6), new THREE.MeshStandardMaterial({ color: 0xbfc7cf, metalness: 0.8, roughness: 0.3 }));
        spearTip.position.set(0.28, 1.32, 0);
        npc.add(spearTip);
        prop = spear;
      } else if (role === 'merchant') {
        const satchel = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.24, 0.14), new THREE.MeshStandardMaterial({ color: 0x5d3b23, roughness: 0.85 }));
        satchel.position.set(0.3, 0.78, 0.02);
        npc.add(satchel);
        const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffe58a, emissive: 0xffd255, emissiveIntensity: 0.9 }));
        lantern.position.set(-0.22, 0.74, 0.1);
        npc.add(lantern);
        prop = lantern;
      } else {
        const loaf = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.08, 0.08), new THREE.MeshStandardMaterial({ color: 0xc68c45, roughness: 0.9 }));
        loaf.position.set(0.24, 0.76, 0.12);
        npc.add(loaf);
        prop = loaf;
      }

      const cape = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.5), new THREE.MeshStandardMaterial({ color: clothPalette[Math.floor(Math.random() * clothPalette.length)], side: THREE.DoubleSide, roughness: 0.95 }));
      cape.position.set(0, 0.82, -0.18);
      cape.rotation.x = 0.2;
      npc.add(cape);

      npc.position.set(rand(-28, 158), 0, rand(-18, 72));
      if (distanceToPathXZ(npc.position.x, npc.position.z) < 5.5) continue;

      npc.userData = { walkPhase: Math.random() * Math.PI * 2, speed: 0.45 + Math.random() * 0.45, home: npc.position.clone(), headBob: Math.random() * Math.PI * 2, swagger: 0.6 + Math.random() * 0.7, role, head, torso, cape, prop, shoulderL, shoulderR, eyeL, eyeR };

      npc.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(npc);
      game.npcs.push(npc);
    }
  }

  function buildBackgroundCreatures() {
    const dinoMat = new THREE.MeshStandardMaterial({ color: 0x4a6b3a, roughness: 0.9 });
    const alienMat = new THREE.MeshStandardMaterial({ color: 0x8a5cff, emissive: 0x3a1f8a, emissiveIntensity: 0.4 });

    for (let i = 0; i < 7; i++) {
      const group = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.9, 2.2, 4, 10), dinoMat);
      body.position.set(0, 1.1, 0);
      group.add(body);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.55, 10, 10), dinoMat);
      head.position.set(1.6, 1.6, 0);
      group.add(head);
      const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.45, 1.8, 6), dinoMat);
      tail.position.set(-1.5, 1.0, 0);
      tail.rotation.z = 0.6;
      group.add(tail);
      const alienBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.35, 1.4, 4, 8), alienMat);
      alienBody.position.set(-2.8, 1.3, 0);
      group.add(alienBody);
      const alienHead = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 10), alienMat);
      alienHead.position.set(-2.8, 2.4, 0);
      group.add(alienHead);
      group.userData = { fightPhase: Math.random() * Math.PI * 2, isFighting: true };
      group.position.set(rand(-30, 180), 0, rand(-20, 85));
      if (distanceToPathXZ(group.position.x, group.position.z) < 9) continue;
      group.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(group);
      game.creatures = game.creatures || [];
      game.creatures.push(group);
    }
  }

  function createTorch(x, y, z) {
    const group = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 1.1, 6), new THREE.MeshStandardMaterial({ color: 0x2c2118 }));
    pole.position.y = 0.55;
    group.add(pole);

    const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 10), new THREE.MeshStandardMaterial({ color: 0x593623, emissive: 0x22120a }));
    bowl.position.y = 1.1;
    group.add(bowl);

    const flame = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 10), new THREE.MeshBasicMaterial({ color: 0xffc169, transparent: true, opacity: 0.9 }));
    flame.position.y = 1.34;
    group.add(flame);

    const light = new THREE.PointLight(0xffa550, 1.35, 16, 2);
    light.position.y = 1.45;
    group.add(light);

    group.position.set(x, y, z);
    return { group, flame, light, seed: rand(0, 1000) };
  }


  function buildGraphicsPolish() {
    const cliffMat = new THREE.MeshStandardMaterial({ color: 0x253340, roughness: 1, metalness: 0.02 });
    const cliffCapMat = new THREE.MeshStandardMaterial({ color: 0x334653, roughness: 0.96 });
    const ruinMat = new THREE.MeshStandardMaterial({ color: 0x7c807f, roughness: 0.95, metalness: 0.03 });
    const shrubPalette = [0x315439, 0x3c6540, 0x476f46, 0x2e4931];

    const cliffBands = [
      [-26, -14, 24, 11, 32], [8, -18, 30, 12, 28], [46, -16, 26, 10, 30], [88, -20, 34, 13, 34], [128, -16, 30, 11, 28],
      [-18, 80, 26, 10, 26], [26, 84, 34, 12, 30], [78, 82, 28, 10, 24], [126, 86, 36, 13, 32], [170, 78, 26, 10, 24]
    ];
    for (const [x, z, sx, sy, sz] of cliffBands) {
      const mesa = new THREE.Group();
      const base = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), cliffMat);
      base.position.y = sy * 0.5 - 1.2;
      base.rotation.z = rand(-0.06, 0.06);
      mesa.add(base);
      for (let i = 0; i < 4; i++) {
        const shard = new THREE.Mesh(new THREE.BoxGeometry(rand(4, 9), rand(5, 10), rand(4, 8)), cliffCapMat);
        shard.position.set(rand(-sx * 0.35, sx * 0.35), sy * 0.6 + rand(1.5, 4.5), rand(-sz * 0.3, sz * 0.3));
        shard.rotation.set(rand(-0.2, 0.2), rand(0, Math.PI), rand(-0.12, 0.12));
        mesa.add(shard);
      }
      mesa.position.set(x, 0, z);
      mesa.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(mesa);
    }

    const shrubSpots = [
      [-15, 58], [-8, 26], [6, 72], [18, -10], [31, 70], [52, -12], [68, 70], [82, -10], [100, 72], [122, -8], [155, 72], [161, 28]
    ];
    for (const [x, z] of shrubSpots) {
      const cluster = new THREE.Group();
      for (let i = 0; i < 7; i++) {
        const leaf = new THREE.Mesh(
          new THREE.SphereGeometry(rand(0.55, 1.1), 10, 10),
          new THREE.MeshStandardMaterial({ color: shrubPalette[i % shrubPalette.length], roughness: 1 })
        );
        leaf.position.set(rand(-1.3, 1.3), rand(0.45, 1.4), rand(-1.2, 1.2));
        cluster.add(leaf);
      }
      const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.24, 0.7, 6), new THREE.MeshStandardMaterial({ color: 0x493324, roughness: 1 }));
      stump.position.y = 0.35;
      cluster.add(stump);
      cluster.position.set(x, 0, z);
      cluster.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(cluster);
    }

    for (let i = 0; i < 48; i++) {
      const t = i / 109;
      const p = pathCurve.getPointAt(t);
      const prev = pathCurve.getPointAt(Math.max(0, t - 1 / 109));
      const next = pathCurve.getPointAt(Math.min(1, t + 1 / 109));
      const tangent = next.clone().sub(prev).setY(0).normalize();
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
      if (i % 2 === 0) {
        const stone = new THREE.Mesh(
          new THREE.DodecahedronGeometry(rand(0.1, 0.24), 0),
          new THREE.MeshStandardMaterial({ color: i % 4 === 0 ? 0x8d7553 : 0x5f5142, roughness: 1 })
        );
        const dir = i % 4 < 2 ? -1 : 1;
        stone.position.copy(p).addScaledVector(normal, (3.35 + rand(0.2, 1.8)) * dir).add(new THREE.Vector3(0, rand(0.05, 0.2), 0));
        stone.castShadow = stone.receiveShadow = true;
        world.add(stone);
      }
      if (i % 5 === 0) {
        const tuft = new THREE.Group();
        for (let j = 0; j < 4; j++) {
          const blade = new THREE.Mesh(
            new THREE.ConeGeometry(rand(0.04, 0.08), rand(0.35, 0.75), 4),
            new THREE.MeshStandardMaterial({ color: shrubPalette[(i + j) % shrubPalette.length], roughness: 1 })
          );
          blade.position.set(rand(-0.16, 0.16), blade.geometry.parameters.height * 0.5, rand(-0.16, 0.16));
          blade.rotation.z = rand(-0.2, 0.2);
          tuft.add(blade);
        }
        const side = i % 10 === 0 ? 1 : -1;
        tuft.position.copy(p).addScaledVector(normal, 4.1 * side + rand(-0.35, 0.35));
        world.add(tuft);
      }
    }

    const beaconSpots = [
      { x: 12, z: 62, colorA: 0x66ffd7, colorB: 0xb88cff },
      { x: 63, z: 67, colorA: 0x7fe0ff, colorB: 0xffffff },
      { x: 108, z: -8, colorA: 0xffb066, colorB: 0xffe6aa },
      { x: 154, z: 8, colorA: 0x9eff7a, colorB: 0xebffc8 }
    ];
    for (const spot of beaconSpots) {
      const shrine = new THREE.Group();
      const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.45, 1.3, 8), ruinMat);
      pedestal.position.y = 0.65;
      shrine.add(pedestal);
      for (let i = 0; i < 3; i++) {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.34, 2.4, 0.34), ruinMat);
        const a = i / 3 * Math.PI * 2 + Math.PI / 6;
        pillar.position.set(Math.cos(a) * 1.15, 1.85, Math.sin(a) * 1.15);
        pillar.rotation.y = a;
        shrine.add(pillar);
      }
      const core = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.45, 0),
        new THREE.MeshStandardMaterial({ color: spot.colorB, emissive: spot.colorA, emissiveIntensity: 1.2, roughness: 0.18, metalness: 0.22 })
      );
      core.position.y = 2.7;
      shrine.add(core);
      const halo = new THREE.Mesh(new THREE.TorusGeometry(1.35, 0.08, 8, 40), makeGlowShaderMaterial(spot.colorA, spot.colorB, { opacity: 0.42, speed: 1.25 }));
      halo.position.y = 2.02;
      halo.rotation.x = Math.PI / 2;
      shrine.add(halo);
      const light = new THREE.PointLight(spot.colorA, 1.1, 22, 2);
      light.position.y = 2.55;
      shrine.add(light);
      shrine.position.set(spot.x, 0, spot.z);
      shrine.traverse(o => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
      world.add(shrine);
      game.decorFX.push({ kind: 'beacon', group: shrine, core, halo, light, baseY: core.position.y, phase: rand(0, Math.PI * 2), speed: rand(0.75, 1.25) });
    }

    const riverBankMat = new THREE.MeshStandardMaterial({ color: 0x64835a, roughness: 1 });
    for (let i = 0; i < 12; i++) {
      const reeds = new THREE.Group();
      for (let j = 0; j < 5; j++) {
        const reed = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, rand(0.8, 1.6), 5), riverBankMat);
        reed.position.set(rand(-0.35, 0.35), reed.geometry.parameters.height * 0.5, rand(-0.35, 0.35));
        reed.rotation.z = rand(-0.08, 0.08);
        reeds.add(reed);
      }
      reeds.position.set(rand(148, 159), 0, rand(-10, 76));
      world.add(reeds);
      if (i % 3 === 0) {
        const foam = new THREE.Mesh(new THREE.RingGeometry(0.22, rand(0.44, 0.75), 20), new THREE.MeshBasicMaterial({ color: 0xe3f8ff, transparent: true, opacity: 0.12, side: THREE.DoubleSide }));
        foam.rotation.x = -Math.PI / 2;
        foam.position.set(rand(160, 183), 0.015, rand(-12, 78));
        world.add(foam);
        game.waterFX.push({ mesh: foam, kind: 'ripple', phase: rand(0, Math.PI * 2), speed: rand(0.5, 1.2) });
      }
    }

    const castleTorchSpots = [[129.5, 55.4], [129.5, 70.5], [150.9, 55.5], [151.3, 70.4], [158.6, 58.4], [158.6, 67.7]];
    for (const [x, z] of castleTorchSpots) {
      const plinth = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.62, 0.5, 7), ruinMat);
      plinth.position.set(x, 0.25, z);
      plinth.castShadow = plinth.receiveShadow = true;
      world.add(plinth);
      const torch = createTorch(x, 0.28, z);
      world.add(torch.group);
      game.torches.push(torch);
    }

    const fireflyGroves = [
      { x: 12, y: 1.8, z: 26 }, { x: 31, y: 1.7, z: 56 }, { x: 67, y: 1.6, z: 63 },
      { x: 98, y: 1.9, z: 44 }, { x: 26, y: 1.5, z: -2 }, { x: 118, y: 1.8, z: 16 }
    ];
    for (const grove of fireflyGroves) {
      for (let i = 0; i < 4; i++) {
        const mote = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), new THREE.MeshBasicMaterial({ color: i % 2 ? 0xfff6a8 : 0x9fffd8, transparent: true, opacity: 0.6 }));
        mote.position.set(grove.x + rand(-1.4, 1.4), grove.y + rand(-0.6, 0.8), grove.z + rand(-1.4, 1.4));
        world.add(mote);
        game.decorFX.push({ kind: 'firefly', mesh: mote, base: mote.position.clone(), phase: rand(0, Math.PI * 2), speed: rand(0.9, 2.1), radius: rand(0.35, 1.3) });
      }
    }

    const siegeCampSpots = [[-15, -3], [-11, -9], [-6, 3], [0, -11]];
    for (const [x, z] of siegeCampSpots) {
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.42, 0.9, 10), new THREE.MeshStandardMaterial({ color: 0x6a4a30, roughness: 0.95 }));
      barrel.position.set(x, 0.45, z);
      barrel.rotation.y = rand(0, Math.PI);
      barrel.castShadow = barrel.receiveShadow = true;
      world.add(barrel);
      const sack = new THREE.Mesh(new THREE.SphereGeometry(0.38, 10, 10), new THREE.MeshStandardMaterial({ color: 0x88735e, roughness: 1 }));
      sack.scale.y = 1.2;
      sack.position.set(x + rand(0.5, 1.1), 0.34, z + rand(-0.5, 0.5));
      sack.castShadow = sack.receiveShadow = true;
      world.add(sack);
    }
  }

  function buildPads() {
    // MONUMENTS REMOVED as requested
  }

  let rangeIndicator = null;
  function buildRangeIndicator() {
    const geometry = new THREE.RingGeometry(0.98, 1, 64);
    const material = new THREE.MeshBasicMaterial({ color: 0xfff1a8, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false });
    rangeIndicator = new THREE.Mesh(geometry, material);
    rangeIndicator.rotation.x = -Math.PI / 2;
    rangeIndicator.visible = false;
    rangeIndicator.position.y = 0.06;
    world.add(rangeIndicator);
  }


  function makeUltraGlowShader(colorA, colorB, opts = {}) {
    return makeGlowShaderMaterial(colorA, colorB, opts);
  }

  function distanceToPathXZ(x, z) {
    let best = Infinity;
    const p = new THREE.Vector3(x, 0, z);
    for (let i = 0; i < curvePoints.length - 1; i++) {
      const a = curvePoints[i];
      const b = curvePoints[i + 1];
      const ab = tmpVecA.subVectors(b, a);
      const t = THREE.MathUtils.clamp(tmpVecB.subVectors(p, a).dot(ab) / ab.lengthSq(), 0, 1);
      const proj = new THREE.Vector3().copy(a).addScaledVector(ab, t);
      best = Math.min(best, proj.distanceTo(p));
    }
    return best;
  }

  function makeWave(index) {
    const cycle = ((index - 1) % 12) + 1;
    const lap = Math.floor((index - 1) / 12);
    const scale = 1 + lap * 0.22 + (cycle - 1) * 0.05;
    const lineup = [];
    const add = (type, count, mult = 1) => { for (let i = 0; i < count; i++) lineup.push(makeEnemyDef(type, scale * mult)); };

    add('raider', 5 + cycle);
    if (cycle >= 2) add('scout', 3 + Math.floor(cycle * 0.6));
    if (cycle >= 3) add('knight', 2 + Math.floor(cycle * 0.45));
    if (cycle >= 4) add('rider', 2 + Math.floor(cycle * 0.4));
    if (cycle >= 5) add('cultist', 2 + Math.floor(cycle * 0.45));
    if (cycle >= 6) add('brute', 1 + Math.floor(cycle * 0.34));
    if (cycle >= 6) add('warWagon', 1 + Math.floor(cycle * 0.25));
    if (cycle >= 8) add('plagueCart', 1 + Math.floor(cycle * 0.2));

    if (cycle === 4) { add('dreadKnight', 1, 1.06); add('raider', 6); add('scout', 4); }
    if (cycle === 7) { add('pyreAbbot', 1, 1.08); add('cultist', 8); add('rider', 5); }
    if (cycle === 10) { add('batteringRam', 1, 1.1); add('warWagon', 4); add('brute', 4); }
    if (cycle === 12) { add('astralWarden', 1, 1.12); add('dreadKnight', 1, 1.04); add('pyreAbbot', 1, 1.04); add('batteringRam', 1, 1.04); }

    lineup.sort(() => Math.random() - 0.5);
    return lineup;
  }

  function makeEnemyDef(type, scale) {
    const base = enemyDefs[type];
    return {
      type,
      maxHp: Math.round(base.hp * scale),
      hp: Math.round(base.hp * scale),
      speed: base.speed * (1 + (scale - 1) * 0.06),
      reward: Math.round(base.reward * (0.88 + scale * 0.12)),
      phase: base.phase || 'mob'
    };
  }

  function createEnemy(data) {
    const base = enemyDefs[data.type];
    const group = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color: base.color, emissive: base.emissive, emissiveIntensity: 0.28, roughness: 0.74, metalness: 0.16 });
    const clothMat = new THREE.MeshStandardMaterial({ color: (data.type === 'cultist' || data.type === 'pyreAbbot') ? 0x6d2319 : (data.type === 'scout' ? 0x355845 : data.type === 'brute' ? 0x5c2c29 : data.type === 'dreadKnight' ? 0x2e214f : 0x5b4639), roughness: 1 });
    const metalMat = new THREE.MeshStandardMaterial({ color: data.type === 'dreadKnight' ? 0x8c7dff : 0xaab4c3, metalness: 0.58, roughness: 0.4 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5a4028, roughness: 1 });
    const skinMat = new THREE.MeshStandardMaterial({ color: (data.type === 'cultist' || data.type === 'pyreAbbot') ? 0xe2b07a : 0xcbb9a7, roughness: 0.84 });

    const healthWidth = ['warWagon', 'plagueCart'].includes(data.type) ? 2.4 : (data.type === 'batteringRam' || data.type === 'astralWarden') ? 2.9 : ['dreadKnight','pyreAbbot'].includes(data.type) ? 2.55 : 1.9;
    const shadow = new THREE.Mesh(new THREE.CircleGeometry(base.size * 0.95, 22), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3 }));
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.04;
    group.add(shadow);

    const walkers = [];
    const swayers = [];

    const vehicleTypes = ['warWagon', 'plagueCart', 'batteringRam'];
    if (vehicleTypes.includes(data.type)) {
      const chassis = new THREE.Mesh(new THREE.BoxGeometry(base.size * 1.55, base.size * 0.65, base.size * 1.05), new THREE.MeshStandardMaterial({ color: data.type === 'plagueCart' ? 0x62734b : 0x6b5242, roughness: 1 }));
      chassis.position.y = base.size * 0.55;
      group.add(chassis);
      const frame = new THREE.Mesh(new THREE.BoxGeometry(base.size * 1.2, base.size * 0.18, base.size * 0.2), woodMat);
      frame.position.set(0.05, base.size * 1.18, 0);
      group.add(frame);
      for (const wx of [-0.9, 0.9]) {
        for (const wz of [-0.55, 0.55]) {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.28, base.size * 0.28, base.size * 0.18, 14), new THREE.MeshStandardMaterial({ color: 0x3d2d22, roughness: 1 }));
          wheel.rotation.z = Math.PI / 2;
          wheel.position.set(wx * base.size * 0.8, base.size * 0.28, wz * base.size * 0.85);
          group.add(wheel);
          walkers.push(wheel);
        }
      }
      if (data.type === 'warWagon') {
        const shield = new THREE.Mesh(new THREE.BoxGeometry(base.size * 0.22, base.size * 0.66, base.size * 0.96), metalMat);
        shield.position.set(base.size * 0.8, base.size * 0.98, 0);
        group.add(shield);
        const bowman = new THREE.Mesh(new THREE.CapsuleGeometry(base.size * 0.14, base.size * 0.46, 4, 8), bodyMat);
        bowman.position.set(-base.size * 0.1, base.size * 1.28, 0);
        group.add(bowman);
      } else if (data.type === 'plagueCart') {
        for (let i = 0; i < 3; i++) {
          const barrel = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.15, base.size * 0.18, base.size * 0.42, 10), new THREE.MeshStandardMaterial({ color: 0x7aa34d, emissive: 0x3f6d1f, emissiveIntensity: 0.4 }));
          barrel.position.set(-base.size * 0.25 + i * base.size * 0.28, base.size * 1.05, 0);
          group.add(barrel);
          swayers.push(barrel);
        }
      } else {
        const ram = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.18, base.size * 0.24, base.size * 1.4, 10), new THREE.MeshStandardMaterial({ color: 0x8d6c4b, roughness: 1 }));
        ram.rotation.z = Math.PI / 2;
        ram.position.set(base.size * 0.88, base.size * 0.95, 0);
        group.add(ram);
        const ramHead = new THREE.Mesh(new THREE.ConeGeometry(base.size * 0.28, base.size * 0.6, 8), new THREE.MeshStandardMaterial({ color: 0xd8b188, metalness: 0.25, roughness: 0.5 }));
        ramHead.rotation.z = -Math.PI / 2;
        ramHead.position.set(base.size * 1.55, base.size * 0.95, 0);
        group.add(ramHead);
        swayers.push(ramHead);
      }
    } else if (data.type === 'rider') {
      const beast = new THREE.Mesh(new THREE.CapsuleGeometry(base.size * 0.34, base.size * 1.0, 6, 12), new THREE.MeshStandardMaterial({ color: 0x4e3a26, roughness: 1 }));
      beast.rotation.z = Math.PI / 2;
      beast.position.y = base.size * 0.72;
      group.add(beast);
      for (const side of [-1, 1]) {
        for (const x of [-0.5, 0.45]) {
          const leg = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.07, base.size * 0.08, base.size * 0.7, 7), new THREE.MeshStandardMaterial({ color: 0x3a2a1a, roughness: 1 }));
          leg.position.set(x * base.size, base.size * 0.28, side * base.size * 0.28);
          group.add(leg);
          walkers.push(leg);
        }
      }
      const rider = new THREE.Mesh(new THREE.CapsuleGeometry(base.size * 0.13, base.size * 0.55, 4, 8), bodyMat);
      rider.position.set(0, base.size * 1.34, 0);
      group.add(rider);
      const spear = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.03, base.size * 0.03, base.size * 1.3, 6), woodMat);
      spear.position.set(base.size * 0.55, base.size * 1.55, 0);
      spear.rotation.z = -0.72;
      group.add(spear);
      swayers.push(spear);
    } else {
      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(base.size * 0.18, base.size * 0.7, 4, 10), bodyMat);
      torso.position.y = base.size * 0.92;
      group.add(torso);
      const head = new THREE.Mesh(new THREE.SphereGeometry(base.size * 0.16, 14, 14), skinMat);
      head.position.y = base.size * 1.5;
      group.add(head);
      const legs = [];
      for (const side of [-1, 1]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.055, base.size * 0.07, base.size * 0.7, 7), clothMat);
        leg.position.set(side * base.size * 0.11, base.size * 0.38, 0);
        group.add(leg);
        walkers.push(leg); legs.push(leg);
        const arm = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.045, base.size * 0.05, base.size * 0.56, 6), bodyMat);
        arm.position.set(side * base.size * 0.26, base.size * 1.02, 0);
        group.add(arm);
        swayers.push(arm);
      }
      const robe = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.18, base.size * 0.26, base.size * 0.65, 7), clothMat);
      robe.position.y = base.size * 0.82;
      if (['cultist','pyreAbbot'].includes(data.type)) group.add(robe);
      if (['knight','dreadKnight'].includes(data.type)) {
        const helm = new THREE.Mesh(new THREE.SphereGeometry(base.size * 0.18, 12, 12), metalMat);
        helm.position.y = base.size * 1.52;
        group.add(helm);
        const shield = new THREE.Mesh(new THREE.BoxGeometry(base.size * 0.18, base.size * 0.4, base.size * 0.32), metalMat);
        shield.position.set(-base.size * 0.36, base.size * 1.0, 0);
        group.add(shield);
        const sword = new THREE.Mesh(new THREE.BoxGeometry(base.size * 0.06, base.size * 0.6, base.size * 0.08), metalMat);
        sword.position.set(base.size * 0.38, base.size * 1.08, 0);
        sword.rotation.z = -0.45;
        group.add(sword);
        swayers.push(sword);
      }
      if (data.type === 'scout') {
        const hood = new THREE.Mesh(new THREE.ConeGeometry(base.size * 0.2, base.size * 0.38, 5), clothMat);
        hood.position.y = base.size * 1.65;
        group.add(hood);
      }
      if (data.type === 'brute') {
        const shoulders = new THREE.Mesh(new THREE.BoxGeometry(base.size * 1.0, base.size * 0.28, base.size * 0.5), new THREE.MeshStandardMaterial({ color: 0x5e2d2b, roughness: 0.9 }));
        shoulders.position.y = base.size * 1.38;
        group.add(shoulders);
        const club = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.1, base.size * 0.18, base.size * 1.3, 7), woodMat);
        club.position.set(base.size * 0.72, base.size * 1.02, 0);
        club.rotation.z = -0.6;
        group.add(club);
        swayers.push(club);
      }
      if (data.type === 'cultist' || data.type === 'pyreAbbot') {
        const staff = new THREE.Mesh(new THREE.CylinderGeometry(base.size * 0.04, base.size * 0.04, base.size * 1.24, 6), woodMat);
        staff.position.set(base.size * 0.35, base.size * 1.08, 0);
        staff.rotation.z = -0.15;
        group.add(staff);
        const flame = new THREE.Mesh(new THREE.SphereGeometry(base.size * 0.12, 10, 10), new THREE.MeshStandardMaterial({ color: data.type === 'pyreAbbot' ? 0xffd36b : 0xff8c4a, emissive: data.type === 'pyreAbbot' ? 0xffb347 : 0xff5a1f, emissiveIntensity: 0.9 }));
        flame.position.set(base.size * 0.42, base.size * 1.66, 0);
        group.add(flame);
        swayers.push(flame);
      }
    }

    let aura = null;
    if (data.phase === 'boss') {
      aura = new THREE.Mesh(new THREE.RingGeometry(base.size * 0.45, base.size * 1.05, 28), makeGlowShaderMaterial(0x8cdfff, 0xdb8eff, { opacity: 0.58, speed: 1.4 }));
      aura.rotation.x = -Math.PI / 2;
      aura.position.y = 0.16;
      group.add(aura);
      swayers.push(aura);
    } else if (data.phase === 'miniBoss') {
      aura = new THREE.Mesh(new THREE.RingGeometry(base.size * 0.45, base.size * 0.96, 28), makeGlowShaderMaterial(data.type === 'pyreAbbot' ? 0xff8b4e : 0xb287ff, 0xfff0cf, { opacity: 0.34, speed: 1.15 }));
      aura.rotation.x = -Math.PI / 2;
      aura.position.y = 0.12;
      group.add(aura);
    } else {
      aura = new THREE.Mesh(new THREE.CircleGeometry(base.size * 0.4, 20), makeGlowShaderMaterial(base.color, base.color, { opacity: 0.1, speed: 0.8 }));
      aura.rotation.x = -Math.PI / 2;
      aura.position.y = 0.06;
      group.add(aura);
    }

    const healthBg = new THREE.Mesh(new THREE.PlaneGeometry(healthWidth, 0.18), new THREE.MeshBasicMaterial({ color: 0x1b1212, transparent: true, opacity: 0.72 }));
    const healthColor = data.phase === 'boss' ? 0xda98ff : data.phase === 'miniBoss' ? 0xffc473 : data.type === 'knight' ? 0xb4ccff : data.type === 'plagueCart' ? 0x91f26e : 0x91f2a8;
    const healthFg = new THREE.Mesh(new THREE.PlaneGeometry(healthWidth, 0.15), new THREE.MeshBasicMaterial({ color: healthColor }));
    healthBg.position.set(0, base.size * 2.2, 0);
    healthFg.position.set(0, base.size * 2.2, 0.01);
    group.add(healthBg, healthFg);

    group.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
    world.add(group);
    const enemy = {
      type: data.type,
      phase: data.phase,
      mesh: group,
      healthFg,
      healthWidth,
      maxHp: data.maxHp,
      hp: data.hp,
      speed: data.speed,
      reward: data.reward,
      size: base.size,
      distance: 0,
      slowFactor: 1,
      slowTimer: 0,
      stunTimer: 0,
      burnTimer: 0,
      burnDamage: 0,
      poisonTimer: 0,
      poisonDamage: 0,
      anim: rand(0, Math.PI * 2),
      dead: false,
      reached: false,
      hitFlash: 0,
      walkers,
      swayers,
      hover: data.phase === 'boss',
      aura,
      phasePulse: 0
    };
    game.enemies.push(enemy);
    return enemy;
  }


  function addProceduralCracks(tower, intensity = 1.0) {
    if (!tower || !tower.mesh) return [];
    const created = [];
    const count = Math.max(2, Math.min(8, Math.round(3 + intensity * 3)));
    for (let i = 0; i < count; i++) {
      const crack = new THREE.Mesh(
        new THREE.PlaneGeometry(rand(0.22, 0.42), rand(0.03, 0.07)),
        new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 1, metalness: 0 })
      );
      crack.position.set(rand(-1.15, 1.15), rand(1.1, 3.0), 1.05 + rand(-0.25, 0.25));
      crack.rotation.set(rand(-0.25, 0.25), rand(0, Math.PI), rand(-0.18, 0.18));
      crack.renderOrder = 2;
      tower.mesh.add(crack);
      created.push(crack);
    }
    return created;
  }

  function addBloomEffect(object, intensity = 1.0) {
    if (!object || !object.parent || !object.geometry) return null;
    const bloom = new THREE.Mesh(
      object.geometry.clone(),
      new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.08 * intensity,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      })
    );
    bloom.scale.setScalar(1.08);
    bloom.position.copy(object.position);
    bloom.rotation.copy(object.rotation);
    object.parent.add(bloom);
    return bloom;
  }

  function createTowerMesh(type) {
    const def = towerDefs[type];
    const renderType = def.baseType || type;
    const group = new THREE.Group();
    const root = new THREE.Group();
    group.add(root);

    // ==================== HIGH-DETAIL BASE ====================
    const stoneBase = new THREE.Mesh(
      new THREE.CylinderGeometry(1.95, 2.15, 0.95, 32),
      new THREE.MeshStandardMaterial({ color: 0x716451, roughness: 0.91, metalness: 0.1 })
    );
    stoneBase.position.y = 0.48;
    root.add(stoneBase);

    // Procedural cracks on base
    for (let c = 0; c < 6; c++) {
      const crack = new THREE.Mesh(
        new THREE.PlaneGeometry(0.38, 0.055),
        new THREE.MeshStandardMaterial({ color: 0x1f1f1f, roughness: 1, side: THREE.DoubleSide })
      );
      crack.position.set(rand(-1.5, 1.5), 0.55, 1.4);
      crack.rotation.set(rand(-0.3, 0.3), rand(0, Math.PI), rand(-0.2, 0.2));
      root.add(crack);
    }

    const plinth = new THREE.Mesh(
      new THREE.CylinderGeometry(1.52, 1.72, 0.72, 26),
      new THREE.MeshStandardMaterial({ color: 0x8e8065, roughness: 0.87 })
    );
    plinth.position.y = 1.2;
    root.add(plinth);

    const core = new THREE.Mesh(
      new THREE.CylinderGeometry(1.18, 1.32, 1.05, 26),
      new THREE.MeshStandardMaterial({ 
        color: def.color, 
        emissive: def.glow, 
        emissiveIntensity: 0.26, 
        roughness: 0.52, 
        metalness: 0.28 
      })
    );
    core.position.y = 1.92;
    root.add(core);

    // ==================== UNIQUE MAX-DETAIL GEOMETRY PER TOWER ====================
    const animParts = [];
    const turret = new THREE.Group();
    root.add(turret);
    const fxAnchor = new THREE.Object3D();
    root.add(fxAnchor);

    if (renderType === 'arrow') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1.08, 1.22, 2.0, 12), new THREE.MeshStandardMaterial({ color: 0x795737, roughness: 0.9 }));
      body.position.y = 2.95;
      root.add(body);

      const battlement = new THREE.Mesh(new THREE.CylinderGeometry(1.16, 1.16, 0.35, 12, 1, false), new THREE.MeshStandardMaterial({ color: 0x96724e, roughness: 0.88 }));
      battlement.position.y = 4.1;
      root.add(battlement);

      for (let a = 0; a < 4; a++) {
        const archer = new THREE.Group();
        archer.add(new THREE.Mesh(new THREE.CapsuleGeometry(0.095, 0.42, 6, 9), new THREE.MeshStandardMaterial({ color: 0x4d5b72 })));
        archer.add(new THREE.Mesh(new THREE.SphereGeometry(0.085, 9, 9), new THREE.MeshStandardMaterial({ color: 0xd6c0ab })));
        const bow = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.025, 6, 16, Math.PI * 0.8), new THREE.MeshStandardMaterial({ color: 0xc8a876, metalness: 0.3 }));
        bow.rotation.z = Math.PI / 2;
        archer.add(bow);
        archer.position.set(-0.45 + a * 0.32, 3.35, 0.42 - a * 0.32);
        root.add(archer);
        animParts.push({ mesh: archer, kind: 'archer', speed: 1.7 + a * 0.25, phase: a * 1.1 });
      }

      const banner1 = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.9), new THREE.MeshStandardMaterial({ color: 0x6b1520, side: THREE.DoubleSide }));
      banner1.position.set(0.92, 3.7, 0.25);
      banner1.rotation.y = -Math.PI / 2;
      root.add(banner1);
      animParts.push({ mesh: banner1, kind: 'banner', speed: 2.4, phase: 0 });

      const banner2 = banner1.clone();
      banner2.position.z = -0.25;
      root.add(banner2);
      animParts.push({ mesh: banner2, kind: 'banner', speed: 2.1, phase: 2.3 });

      turret.position.y = 3.55;
      const bow = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.065, 10, 30, Math.PI), new THREE.MeshStandardMaterial({ color: 0xc8a876, metalness: 0.4 }));
      bow.rotation.z = Math.PI / 2;
      turret.add(bow);
      fxAnchor.position.set(1.12, 3.6, 0);
    }

    else if (renderType === 'ballista') {
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.28, 1.35, 12), new THREE.MeshStandardMaterial({ color: 0x7b6756, roughness: 0.88 }));
      drum.position.y = 2.4;
      root.add(drum);

      turret.position.y = 3.3;
      const frame = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.24, 0.85), new THREE.MeshStandardMaterial({ color: 0x6e5a46, roughness: 0.82 }));
      turret.add(frame);

      const arm1 = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.22, 0.14), new THREE.MeshStandardMaterial({ color: 0x8f755b, roughness: 0.78 }));
      arm1.position.set(0.65, 0.45, -0.28);
      arm1.rotation.z = 0.52;
      turret.add(arm1);

      const arm2 = arm1.clone();
      arm2.position.z = 0.28;
      turret.add(arm2);

      const loader = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.75, 8), new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.65 }));
      loader.position.set(1.0, 3.4, 0);
      turret.add(loader);
      animParts.push({ mesh: loader, kind: 'spinY', speed: 2.9, phase: 0 });

      fxAnchor.position.set(1.48, 3.35, 0);
    }

    else if (renderType === 'bombard') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.32, 1.25, 14), new THREE.MeshStandardMaterial({ color: 0x6b5b56, roughness: 0.9 }));
      body.position.y = 2.25;
      root.add(body);

      turret.position.y = 2.95;
      const cannon = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.34, 2.2, 16), new THREE.MeshStandardMaterial({ color: 0x4f5660, metalness: 0.62, roughness: 0.28 }));
      cannon.rotation.z = Math.PI / 2;
      cannon.position.x = 1.0;
      turret.add(cannon);

      for (let p = 0; p < 4; p++) {
        const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.95, 6), new THREE.MeshStandardMaterial({ color: 0x333333 }));
        pipe.position.set(0.58 + p * 0.13, 2.75, 0.38 - p * 0.18);
        pipe.rotation.z = 0.65 + p * 0.18;
        root.add(pipe);
      }

      fxAnchor.position.set(2.05, 3.0, 0);
    }

    else if (renderType === 'frost') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.92, 1.08, 2.25, 12), new THREE.MeshStandardMaterial({ color: 0x61788c, roughness: 0.84 }));
      body.position.y = 2.55;
      root.add(body);

      for (let i = 0; i < 5; i++) {
        const ring = new THREE.Mesh(
          new THREE.TorusGeometry(0.78 + i * 0.11, 0.042, 8, 30),
          makeGlowShaderMaterial(0xc7f3ff, 0xffffff, { opacity: 0.32, speed: 1.5 })
        );
        ring.rotation.x = Math.PI / 2 + (i * 0.22);
        ring.position.y = 3.7;
        root.add(ring);
        animParts.push({ mesh: ring, kind: 'spinY', speed: 1.15 + i * 0.35, phase: i });
      }

      for (let s = 0; s < 6; s++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.75, 6), new THREE.MeshStandardMaterial({ color: 0xa8f0ff, emissive: 0x5ce0ff, emissiveIntensity: 0.7 }));
        spike.position.set(Math.cos(s * 1.05) * 1.2, 4.05, Math.sin(s * 1.05) * 1.2);
        root.add(spike);
      }

      fxAnchor.position.set(0, 4.15, 0);
    }

    else if (renderType === 'sunfire') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.12, 2.45, 12), new THREE.MeshStandardMaterial({ color: 0x8b7056, roughness: 0.88 }));
      body.position.y = 2.65;
      root.add(body);

      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.095, 12, 28), makeGlowShaderMaterial(0xffd996, 0xfff0cb, { opacity: 0.3, speed: 1.4 }));
      halo.position.y = 4.35;
      halo.rotation.x = Math.PI / 2;
      root.add(halo);
      animParts.push({ mesh: halo, kind: 'spinY', speed: 1.15, phase: 0 });

      const sun = new THREE.Mesh(new THREE.SphereGeometry(0.42, 18, 18), new THREE.MeshStandardMaterial({ color: 0xfff7b0, emissive: 0xffe070, emissiveIntensity: 1.35 }));
      sun.position.y = 4.65;
      root.add(sun);
      animParts.push({ mesh: sun, kind: 'spinY', speed: 3.8, phase: 1.4 });

      fxAnchor.position.set(0, 4.45, 0);
    }

    else if (renderType === 'storm') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.02, 2.55, 12), new THREE.MeshStandardMaterial({ color: 0x5e5f82, roughness: 0.84 }));
      body.position.y = 2.7;
      root.add(body);

      for (let i = 0; i < 4; i++) {
        const coil = new THREE.Mesh(new THREE.TorusGeometry(0.62 + i * 0.09, 0.048, 8, 24), makeGlowShaderMaterial(0xa6dcff, 0xe4f6ff, { opacity: 0.38, speed: 1.9 }));
        coil.position.y = 4.25;
        coil.rotation.x = Math.PI / 2;
        root.add(coil);
        animParts.push({ mesh: coil, kind: 'spinY', speed: 1.7 + i * 0.4, phase: i });
      }

      const arc = new THREE.Mesh(new THREE.TorusGeometry(1.08, 0.038, 6, 28), makeGlowShaderMaterial(0x88eeff, 0xffffff, { opacity: 0.75, speed: 4.8 }));
      arc.position.y = 4.1;
      root.add(arc);
      animParts.push({ mesh: arc, kind: 'spinY', speed: 5.5, phase: 2.2 });

      fxAnchor.position.set(0, 4.5, 0);
    }

    else if (renderType === 'alchemist') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1.02, 1.16, 1.72, 12), new THREE.MeshStandardMaterial({ color: 0x6d6f57, roughness: 0.88 }));
      body.position.y = 2.2;
      root.add(body);

      const cauldron = new THREE.Mesh(new THREE.SphereGeometry(0.52, 18, 18), new THREE.MeshStandardMaterial({ color: 0xa7dd55, emissive: 0x9ef957, emissiveIntensity: 0.85, transparent: true, opacity: 0.88 }));
      cauldron.position.set(0, 3.42, 0);
      root.add(cauldron);

      for (let v = 0; v < 5; v++) {
        const vial = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.105, 0.58, 7), new THREE.MeshStandardMaterial({ color: 0xccff77, emissive: 0x97d541, emissiveIntensity: 1.1 }));
        vial.position.set(0.68 + v * 0.11, 3.0, 0.28 - v * 0.13);
        root.add(vial);
        animParts.push({ mesh: vial, kind: 'bob', speed: 2.5 + v * 0.25, phase: v, baseY: 3.0 });
      }

      fxAnchor.position.set(0, 3.52, 0);
    }

    else if (renderType === 'dragon') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1.06, 1.22, 2.05, 12), new THREE.MeshStandardMaterial({ color: 0x6f5a54, roughness: 0.88 }));
      body.position.y = 2.25;
      root.add(body);

      turret.position.y = 3.35;
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.52, 0.48), new THREE.MeshStandardMaterial({ color: 0x9a5a41, roughness: 0.75 }));
      head.position.set(0.95, 0.58, 0);
      turret.add(head);

      const hornL = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.6, 6), new THREE.MeshStandardMaterial({ color: 0x4a3028 }));
      hornL.position.set(0.78, 3.95, 0.28);
      hornL.rotation.z = -0.55;
      root.add(hornL);

      const hornR = hornL.clone();
      hornR.position.z = -0.28;
      hornR.rotation.z = 0.55;
      root.add(hornR);

      const wingL = new THREE.Mesh(new THREE.PlaneGeometry(1.15, 0.72), new THREE.MeshStandardMaterial({ color: 0x5a4030, side: THREE.DoubleSide }));
      wingL.position.set(0.28, 3.0, 0.82);
      wingL.rotation.z = -0.32;
      root.add(wingL);

      const wingR = wingL.clone();
      wingR.position.z = -0.82;
      wingR.rotation.z = 0.32;
      root.add(wingR);

      animParts.push({ mesh: head, kind: 'dragonHead', speed: 1.65, phase: 0, baseY: 0.58 });
      animParts.push({ mesh: wingL, kind: 'hover', speed: 1.35, phase: 0, baseY: 3.0 });
      animParts.push({ mesh: wingR, kind: 'hover', speed: 1.5, phase: 2.4, baseY: 3.0 });

      fxAnchor.position.set(1.42, 3.9, 0);
    }

    group.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
    return { group, turret, core, aura: null, fxAnchor, animParts };
  }


  function createBuildLaneOverlay() {
    const group = new THREE.Group();
    const segments = 220;
    const positions = [];
    function pushBand(inner, outer, color, opacity) {
      const geoPositions = [];
      const indices = [];
      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const p = pathCurve.getPointAt(t);
        const prev = pathCurve.getPointAt(Math.max(0, t - 1 / segments));
        const next = pathCurve.getPointAt(Math.min(1, t + 1 / segments));
        const tangent = next.clone().sub(prev).setY(0).normalize();
        const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
        const a = p.clone().addScaledVector(normal, inner);
        const b = p.clone().addScaledVector(normal, outer);
        geoPositions.push(a.x, 0.07, a.z, b.x, 0.07, b.z);
        if (i < segments) {
          const k = i * 2;
          indices.push(k, k + 1, k + 2, k + 1, k + 3, k + 2);
        }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(geoPositions, 3));
      geo.setIndex(indices);
      geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide }));
      group.add(mesh);
    }
    pushBand(BUILD_LANE_INNER, BUILD_LANE_OUTER, 0x55ff88, 0.08);
    pushBand(-BUILD_LANE_OUTER, -BUILD_LANE_INNER, 0x55ff88, 0.08);
    group.visible = false;
    return group;
  }

  function isInsideWorld(x, z) {
    return x >= WORLD_BOUNDS.minX && x <= WORLD_BOUNDS.maxX && z >= WORLD_BOUNDS.minZ && z <= WORLD_BOUNDS.maxZ;
  }

  function isInsideBuildLane(x, z) {
    const d = distanceToPathXZ(x, z);
    return d >= BUILD_LANE_INNER && d <= BUILD_LANE_OUTER;
  }

  function intersectsStaticFootprint(x, z, extra = 0) {
    for (const fp of staticFootprints) {
      const dx = x - fp.position.x;
      const dz = z - fp.position.z;
      const r = fp.radius + extra;
      if ((dx * dx + dz * dz) < r * r) return true;
    }
    return false;
  }

  function tooCloseToOtherTower(x, z, extra = 0) {
    for (const tower of game.towers) {
      const dx = x - tower.mesh.position.x;
      const dz = z - tower.mesh.position.z;
      const r = TOWER_FOOTPRINT + extra;
      if ((dx * dx + dz * dz) < r * r) return true;
    }
    return false;
  }

  function canPlaceTowerAt(x, z) {
    if (!isInsideWorld(x, z)) return false;
    if (!isInsideBuildLane(x, z)) return false;
    if (intersectsStaticFootprint(x, z, TOWER_FOOTPRINT)) return false;
    if (tooCloseToOtherTower(x, z, 0.9)) return false;
    return true;
  }

  function updatePlacementGhost(position) {
    if (!placementGhost) {
      placementGhost = new THREE.Group();
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(TOWER_FOOTPRINT + 0.1, TOWER_FOOTPRINT + 0.7, 40),
        new THREE.MeshBasicMaterial({ color: 0x55ff88, transparent: true, opacity: 0.45, side: THREE.DoubleSide, depthWrite: false })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.name = 'ring';
      placementGhost.add(ring);

      const cylinder = new THREE.Mesh(
        new THREE.CylinderGeometry(TOWER_FOOTPRINT + 0.1, TOWER_FOOTPRINT + 0.1, 3.8, 20, 1, true),
        new THREE.MeshBasicMaterial({ color: 0x55ff88, transparent: true, opacity: 0.12, depthWrite: false })
      );
      cylinder.position.y = 1.9;
      cylinder.name = 'cylinder';
      placementGhost.add(cylinder);
      placementGhost.visible = false;
      world.add(placementGhost);
    }

    if (!position) {
      placementGhost.visible = false;
      return;
    }

    placementGhost.visible = true;
    placementGhost.position.set(position.x, 0.02, position.z);
    const valid = canPlaceTowerAt(position.x, position.z);
    const color = valid ? 0x55ff88 : 0xff5555;
    placementGhost.children.forEach(child => {
      if (child.material && child.material.color) child.material.color.setHex(color);
    });
  }


  function buildTower(positionOrPad, type) {
    const sourceDef = towerDefs[type];
    let resolvedType = type;
    if (type === 'wildcard') resolvedType = hiddenTowerPool[Math.floor(Math.random() * hiddenTowerPool.length)];
    const def = towerDefs[resolvedType];
    const padRef = positionOrPad && positionOrPad.group ? positionOrPad : null;
    const pos = padRef ? padRef.group.position.clone() : (positionOrPad.clone ? positionOrPad.clone() : positionOrPad.position.clone());
    if (game.gold < sourceDef.cost) { showMessage('Not enough gold'); return null; }
    if (!canPlaceTowerAt(pos.x, pos.z)) { showMessage('Cannot build there'); return null; }
    game.gold -= sourceDef.cost;
    const built = createTowerMesh(resolvedType);
    built.group.position.set(pos.x, 0, pos.z);
    world.add(built.group);
    colorizeTowerMaterials(built.group, resolvedType, def.projectileColor);
    const seal = new THREE.Mesh(new THREE.RingGeometry(1.45, 1.8, 32), makeGlowShaderMaterial(def.color, def.glow, { opacity: 0.25, speed: 1.2 }));
    seal.rotation.x = -Math.PI / 2; seal.position.y = 0.06; built.group.add(seal); built.animParts.push({ mesh: seal, kind: 'groundAura', speed: 0.6, phase: rand(0, Math.PI * 2) });
    const collider = new THREE.Mesh(new THREE.CylinderGeometry(TOWER_FOOTPRINT + 0.35, TOWER_FOOTPRINT + 0.35, 4.8, 12), new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
    collider.position.y = 2.4; collider.userData.type = 'tower'; built.group.add(collider); interactive.push(collider);
    const tower = { type: def.baseType || resolvedType, displayType: resolvedType, name: def.name, mesh: built.group, collider, turret: built.turret, core: built.core, aura: built.aura, fxAnchor: built.fxAnchor, animParts: built.animParts, level: 1, baseCost: sourceDef.cost, cooldown: rand(0, def.fireRate), fireRate: def.fireRate, damage: def.damage, range: def.range, projectileSpeed: def.projectileSpeed, projectileColor: def.projectileColor, splash: def.splash || 0, slow: def.slow || 0, pierce: def.pierce || 0, chain: def.chain || 0, recoil: 0, glowPulse: 0, turretBaseY: built.turret ? built.turret.position.y : 0, persona: def.persona, shotsFired: 0, auraTick: 0, pad: padRef, rolledFromRandom: type === 'wildcard', hiddenRollName: type === 'wildcard' ? def.name : null, evolutionMarks: {}, footprint: TOWER_FOOTPRINT };
    if (padRef) padRef.tower = tower;
    addProceduralCracks(tower, 0.85);
    tower.bloomMesh = addBloomEffect(tower.core, 0.9);
    collider.userData.ref = tower; game.towers.push(tower); game.selectedTower = tower; updateRangeIndicator(tower);
    showMessage(type === 'wildcard' ? `Chaos Vault rolled ${def.name}` : `${def.name} deployed`); updateHUD(); return tower;
  }

  function updateRangeIndicator() {
    if (!game.selectedTower) {
      rangeIndicator.visible = false;
      return;
    }
    rangeIndicator.visible = true;
    rangeIndicator.position.set(game.selectedTower.mesh.position.x, 0.09, game.selectedTower.mesh.position.z);
    rangeIndicator.scale.set(game.selectedTower.range, game.selectedTower.range, 1);
  }

  
function upgradeSelectedTower() {
  const t = game.selectedTower;
  if (!t) return;
  if (t.level >= 4) return;
  const cost = getUpgradeCost(t);
  if (game.gold < cost) return;

  game.gold -= cost;
  t.level += 1;
  t.damage *= 1.24;
  t.range += 0.275;
  t.fireRate *= 0.92;
  if (t.splash) t.splash += 0.7;
  if (t.slow) t.slow = Math.min(0.72, t.slow + 0.06);
  if (t.pierce) t.pierce += 1;
  if (t.chain) t.chain += 1;
  t.core.scale.multiplyScalar(1.05);
  t.glowPulse = 1.6 + t.level * 0.18;

  const upPos = t.mesh.position.clone().add(new THREE.Vector3(0, 3.2, 0));
  explode(upPos, t.projectileColor || 0xffffff, 38 + t.level * 8, 2.8 + t.level * 0.25, { size: 0.09, life: 0.7, gravity: 0.6, drag: 0.88, flicker: true });
  addFlashLight(upPos, t.projectileColor || 0xa0ffea, 4.5 + t.level * 0.8, 26 + t.level * 4, 0.28);
  game.screenShake = Math.max(game.screenShake, 0.22 + t.level * 0.08);

  const evoLevel = t.level;
  const kind = t.displayType || t.type;
  const marks = t.evolutionMarks || (t.evolutionMarks = {});

  function addAnimMesh(mesh, part) {
    t.mesh.add(mesh);
    t.animParts.push({ mesh, ...part });
    return mesh;
  }

  if (kind === 'arrow') {
    if (evoLevel === 2 && !marks.arrow2) {
      marks.arrow2 = true;
      for (let i = 0; i < 2; i++) {
        const pennant = new THREE.Mesh(new THREE.PlaneGeometry(0.36, 0.7), new THREE.MeshStandardMaterial({ color: 0xb51f2f, side: THREE.DoubleSide }));
        pennant.position.set(i ? 0.95 : -0.95, 3.9, i ? 0.3 : -0.3);
        addAnimMesh(pennant, { kind: 'arrowBanner', speed: 1.4 + i * 0.25, phase: i * 1.7, baseY: 3.9, side: i ? 1 : -1 });
      }
    } else if (evoLevel === 3 && !marks.arrow3) {
      marks.arrow3 = true;
      for (let i = 0; i < 3; i++) {
        const arrow = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.05, 0.05), new THREE.MeshStandardMaterial({ color: 0xe0d2a8, metalness: 0.15 }));
        arrow.position.set(0, 4.15 + i * 0.14, 0);
        addAnimMesh(arrow, { kind: 'arrowOrbit', speed: 1.2 + i * 0.35, offset: i * 2.1, radius: 1.25 + i * 0.12, baseY: 4.15 + i * 0.14 });
      }
    } else if (evoLevel === 4 && !marks.arrow4) {
      marks.arrow4 = true;
      const crown = new THREE.Mesh(new THREE.TorusGeometry(1.18, 0.06, 6, 28), makeGlowShaderMaterial(0xf1d26b, 0xfff3b8, { opacity: 0.72, speed: 2.4 }));
      crown.rotation.x = Math.PI / 2;
      crown.position.y = 4.7;
      addAnimMesh(crown, { kind: 'arrowHalo', speed: 1.55, phase: 0, baseY: 4.7 });
    }
  } else if (kind === 'ballista') {
    if (evoLevel === 2 && !marks.ballista2) {
      marks.ballista2 = true;
      const armL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.0, 0.1), new THREE.MeshStandardMaterial({ color: 0xa7865a }));
      armL.position.set(0.35, 3.45, -0.45);
      const armR = armL.clone();
      armR.position.z = 0.45;
      addAnimMesh(armL, { kind: 'ballistaTension', speed: 1.4, phase: 0.2, baseY: 3.45, dir: -1 });
      addAnimMesh(armR, { kind: 'ballistaTension', speed: 1.6, phase: 1.4, baseY: 3.45, dir: 1 });
    } else if (evoLevel === 3 && !marks.ballista3) {
      marks.ballista3 = true;
      const gear = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.09, 6, 16), new THREE.MeshStandardMaterial({ color: 0x74685a, metalness: 0.45, roughness: 0.5 }));
      gear.position.set(-0.95, 2.95, 0);
      addAnimMesh(gear, { kind: 'gearSpin', speed: 2.8, phase: 0, baseY: 2.95 });
    } else if (evoLevel === 4 && !marks.ballista4) {
      marks.ballista4 = true;
      const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.8, 10), new THREE.MeshStandardMaterial({ color: 0xe7f1ff, emissive: 0xaed6ff, emissiveIntensity: 0.7, metalness: 0.65 }));
      scope.rotation.z = Math.PI / 2;
      scope.position.set(1.05, 3.55, 0);
      addAnimMesh(scope, { kind: 'scopePulse', speed: 2.6, phase: 0, baseY: 3.55 });
    }
  } else if (kind === 'bombard') {
    if (evoLevel === 2 && !marks.bombard2) {
      marks.bombard2 = true;
      for (let i = 0; i < 2; i++) {
        const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 0.4, 8), new THREE.MeshStandardMaterial({ color: 0x2f3135, metalness: 0.55 }));
        vent.position.set(-0.35 + i * 0.7, 3.1, i ? 0.45 : -0.45);
        addAnimMesh(vent, { kind: 'ventChug', speed: 2.0 + i * 0.25, phase: i, baseY: 3.1 });
      }
    } else if (evoLevel === 3 && !marks.bombard3) {
      marks.bombard3 = true;
      const shell = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), new THREE.MeshStandardMaterial({ color: 0x494c54, metalness: 0.5 }));
      shell.position.set(0.2, 3.35, 0.8);
      addAnimMesh(shell, { kind: 'bombardShell', speed: 1.8, phase: 0.3, baseY: 3.35, baseX: 0.2, baseZ: 0.8 });
    } else if (evoLevel === 4 && !marks.bombard4) {
      marks.bombard4 = true;
      const flare = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.06, 6, 24), makeGlowShaderMaterial(0xff6a33, 0xffddb1, { opacity: 0.8, speed: 4.0 }));
      flare.position.set(1.35, 2.95, 0);
      flare.rotation.y = Math.PI / 2;
      addAnimMesh(flare, { kind: 'bombardMuzzle', speed: 3.5, phase: 0, baseX: 1.35 });
    }
  } else if (kind === 'frost') {
    if (evoLevel === 2 && !marks.frost2) {
      marks.frost2 = true;
      for (let i = 0; i < 3; i++) {
        const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.17, 0), new THREE.MeshStandardMaterial({ color: 0xc9fbff, emissive: 0x86e8ff, emissiveIntensity: 0.9 }));
        shard.position.set(0, 3.95, 0);
        addAnimMesh(shard, { kind: 'frostSpiral', speed: 1.0 + i * 0.22, offset: i * 2.05, radius: 0.95 + i * 0.18, baseY: 3.95 + i * 0.08 });
      }
    } else if (evoLevel === 3 && !marks.frost3) {
      marks.frost3 = true;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.03, 6, 30), makeGlowShaderMaterial(0x9feeff, 0xffffff, { opacity: 0.7, speed: 1.8 }));
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 4.35;
      addAnimMesh(ring, { kind: 'frostRing', speed: 1.45, phase: 0, baseY: 4.35 });
    } else if (evoLevel === 4 && !marks.frost4) {
      marks.frost4 = true;
      const crown = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.9, 6), new THREE.MeshStandardMaterial({ color: 0xe6ffff, emissive: 0xb1f7ff, emissiveIntensity: 1.1 }));
      crown.position.y = 4.95;
      addAnimMesh(crown, { kind: 'frostCrown', speed: 1.2, phase: 0, baseY: 4.95 });
    }
  } else if (kind === 'sunfire') {
    if (evoLevel === 2 && !marks.sunfire2) {
      marks.sunfire2 = true;
      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.05, 10, 28), makeGlowShaderMaterial(0xffd36b, 0xffffd6, { opacity: 0.65, speed: 1.6 }));
      halo.rotation.x = Math.PI / 2;
      halo.position.y = 4.55;
      addAnimMesh(halo, { kind: 'sunHalo', speed: 1.1, phase: 0.5, baseY: 4.55 });
    } else if (evoLevel === 3 && !marks.sunfire3) {
      marks.sunfire3 = true;
      for (let i = 0; i < 4; i++) {
        const ray = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.8, 0.06), new THREE.MeshBasicMaterial({ color: 0xfff3bf, transparent: true, opacity: 0.9 }));
        ray.position.set(0, 4.75, 0);
        addAnimMesh(ray, { kind: 'sunRay', speed: 1.0 + i * 0.18, phase: i * (Math.PI / 2), radius: 1.0, baseY: 4.75 });
      }
    } else if (evoLevel === 4 && !marks.sunfire4) {
      marks.sunfire4 = true;
      const nova = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), new THREE.MeshStandardMaterial({ color: 0xffffd5, emissive: 0xffdd76, emissiveIntensity: 1.6 }));
      nova.position.y = 5.05;
      addAnimMesh(nova, { kind: 'sunNova', speed: 2.4, phase: 0, baseY: 5.05 });
    }
  } else if (kind === 'storm') {
    if (evoLevel === 2 && !marks.storm2) {
      marks.storm2 = true;
      for (let i = 0; i < 2; i++) {
        const arc = new THREE.Mesh(new THREE.TorusGeometry(0.85 + i * 0.15, 0.025, 6, 24), makeGlowShaderMaterial(0x86dcff, 0xffffff, { opacity: 0.72, speed: 4.0 }));
        arc.position.y = 4.3;
        addAnimMesh(arc, { kind: 'stormArc', speed: 3.2 + i * 0.7, phase: i, baseY: 4.3 });
      }
    } else if (evoLevel === 3 && !marks.storm3) {
      marks.storm3 = true;
      const coil = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.1, 8), new THREE.MeshStandardMaterial({ color: 0xc9e6ff, emissive: 0x8ea7ff, emissiveIntensity: 1.0 }));
      coil.position.y = 4.85;
      addAnimMesh(coil, { kind: 'stormCoil', speed: 2.0, phase: 0, baseY: 4.85 });
    } else if (evoLevel === 4 && !marks.storm4) {
      marks.storm4 = true;
      const prism = new THREE.Mesh(new THREE.OctahedronGeometry(0.22, 0), new THREE.MeshStandardMaterial({ color: 0xeaffff, emissive: 0xb4c3ff, emissiveIntensity: 1.3 }));
      prism.position.y = 5.1;
      addAnimMesh(prism, { kind: 'stormPrism', speed: 3.8, phase: 0, baseY: 5.1 });
    }
  } else if (kind === 'alchemist') {
    if (evoLevel === 2 && !marks.alchemist2) {
      marks.alchemist2 = true;
      for (let i = 0; i < 3; i++) {
        const bubble = new THREE.Mesh(new THREE.SphereGeometry(0.12 + i * 0.03, 10, 10), new THREE.MeshStandardMaterial({ color: 0xd6ff8c, emissive: 0x8ac94b, emissiveIntensity: 0.9, transparent: true, opacity: 0.85 }));
        bubble.position.set(0, 3.3, 0);
        addAnimMesh(bubble, { kind: 'alchemyBubble', speed: 1.5 + i * 0.35, phase: i, radius: 0.35 + i * 0.12, baseY: 3.3 + i * 0.12 });
      }
    } else if (evoLevel === 3 && !marks.alchemist3) {
      marks.alchemist3 = true;
      const swirl = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.035, 6, 24), makeGlowShaderMaterial(0xa5ff6a, 0xf6ffd7, { opacity: 0.66, speed: 2.4 }));
      swirl.position.y = 3.95;
      swirl.rotation.x = Math.PI / 2;
      addAnimMesh(swirl, { kind: 'alchemySwirl', speed: 2.0, phase: 0, baseY: 3.95 });
    } else if (evoLevel === 4 && !marks.alchemist4) {
      marks.alchemist4 = true;
      const flask = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 0.65, 8), new THREE.MeshStandardMaterial({ color: 0xf0ffb1, emissive: 0x8fff4d, emissiveIntensity: 1.2, transparent: true, opacity: 0.92 }));
      flask.position.y = 4.7;
      addAnimMesh(flask, { kind: 'alchemyFlask', speed: 1.7, phase: 0, baseY: 4.7 });
    }
  } else if (kind === 'dragon') {
    if (evoLevel === 2 && !marks.dragon2) {
      marks.dragon2 = true;
      const ember = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), new THREE.MeshStandardMaterial({ color: 0xffa35e, emissive: 0xff5d29, emissiveIntensity: 1.0 }));
      ember.position.set(1.15, 3.6, 0);
      addAnimMesh(ember, { kind: 'dragonEmber', speed: 2.2, phase: 0, baseX: 1.15, baseY: 3.6 });
    } else if (evoLevel === 3 && !marks.dragon3) {
      marks.dragon3 = true;
      const wingL = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.45), new THREE.MeshStandardMaterial({ color: 0x7e4a36, side: THREE.DoubleSide }));
      wingL.position.set(-0.05, 3.15, 1.05);
      const wingR = wingL.clone();
      wingR.position.z = -1.05;
      addAnimMesh(wingL, { kind: 'dragonWing', speed: 1.3, phase: 0, baseY: 3.15, side: 1 });
      addAnimMesh(wingR, { kind: 'dragonWing', speed: 1.45, phase: 1.3, baseY: 3.15, side: -1 });
    } else if (evoLevel === 4 && !marks.dragon4) {
      marks.dragon4 = true;
      const crown = new THREE.Mesh(new THREE.TorusKnotGeometry(0.28, 0.08, 56, 8), new THREE.MeshStandardMaterial({ color: 0xffd3a8, emissive: 0xff7b39, emissiveIntensity: 1.2, metalness: 0.25 }));
      crown.position.set(0.55, 4.6, 0);
      addAnimMesh(crown, { kind: 'dragonCrest', speed: 2.2, phase: 0, baseY: 4.6 });
    }
  } else if (kind === 'sniper') {
    if (evoLevel === 2 && !marks.sniper2) {
      marks.sniper2 = true;
      const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.5, 12), new THREE.MeshStandardMaterial({ color: 0xcce4ff, emissive: 0x8cb8ff, emissiveIntensity: 1.0, metalness: 0.75 }));
      lens.rotation.z = Math.PI / 2;
      lens.position.set(0.95, 3.45, 0);
      addAnimMesh(lens, { kind: 'scopePulse', speed: 2.3, phase: 0.4, baseY: 3.45 });
    } else if (evoLevel === 3 && !marks.sniper3) {
      marks.sniper3 = true;
      const marker = new THREE.Mesh(new THREE.RingGeometry(0.38, 0.46, 20), makeGlowShaderMaterial(0xb8d6ff, 0xffffff, { opacity: 0.6, speed: 2.0 }));
      marker.position.set(1.35, 3.52, 0);
      marker.rotation.y = Math.PI / 2;
      addAnimMesh(marker, { kind: 'sniperMarker', speed: 2.0, phase: 0, baseX: 1.35 });
    } else if (evoLevel === 4 && !marks.sniper4) {
      marks.sniper4 = true;
      const dial = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.045, 6, 20), new THREE.MeshStandardMaterial({ color: 0xf8fcff, emissive: 0x9fd1ff, emissiveIntensity: 1.1 }));
      dial.position.set(-0.7, 3.55, 0);
      addAnimMesh(dial, { kind: 'dialSpin', speed: 3.1, phase: 0, baseY: 3.55 });
    }
  } else if (kind === 'turret') {
    if (evoLevel === 2 && !marks.turret2) {
      marks.turret2 = true;
      const gyro = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.045, 6, 22), new THREE.MeshStandardMaterial({ color: 0xd0a084, metalness: 0.45, roughness: 0.5 }));
      gyro.position.y = 3.9;
      gyro.rotation.x = Math.PI / 2;
      addAnimMesh(gyro, { kind: 'turretGyro', speed: 3.5, phase: 0, baseY: 3.9 });
    } else if (evoLevel === 3 && !marks.turret3) {
      marks.turret3 = true;
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.95, 10), new THREE.MeshStandardMaterial({ color: 0xc89c7b, metalness: 0.55 }));
      barrel.rotation.z = Math.PI / 2;
      barrel.position.set(1.05, 3.38, 0);
      addAnimMesh(barrel, { kind: 'turretBarrel', speed: 5.2, phase: 0, baseX: 1.05 });
    } else if (evoLevel === 4 && !marks.turret4) {
      marks.turret4 = true;
      const node = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), new THREE.MeshStandardMaterial({ color: 0xffddc3, emissive: 0xffa36c, emissiveIntensity: 1.15 }));
      node.position.y = 4.55;
      addAnimMesh(node, { kind: 'turretNode', speed: 2.6, phase: 0, baseY: 4.55 });
    }
  } else if (kind === 'hawk') {
    if (evoLevel === 2 && !marks.hawk2) {
      marks.hawk2 = true;
      const bird = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.18, 0.32), new THREE.MeshStandardMaterial({ color: 0xc7a56d, roughness: 0.8 }));
      bird.position.set(0, 4.1, 0);
      addAnimMesh(bird, { kind: 'hawkGlide', speed: 1.4, phase: 0, radius: 1.1, baseY: 4.1 });
    } else if (evoLevel === 3 && !marks.hawk3) {
      marks.hawk3 = true;
      const gust = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.025, 6, 22), makeGlowShaderMaterial(0xdccfaf, 0xffffff, { opacity: 0.58, speed: 2.4 }));
      gust.position.y = 4.35;
      gust.rotation.x = Math.PI / 2;
      addAnimMesh(gust, { kind: 'hawkGust', speed: 1.8, phase: 0, baseY: 4.35 });
    } else if (evoLevel === 4 && !marks.hawk4) {
      marks.hawk4 = true;
      const feather = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.7), new THREE.MeshStandardMaterial({ color: 0xf0dfbf, side: THREE.DoubleSide }));
      feather.position.y = 4.85;
      addAnimMesh(feather, { kind: 'hawkFeather', speed: 2.1, phase: 0, baseY: 4.85 });
    }
  }

  showMessage(`${t.name} upgraded to Level ${t.level}`);
  updateHUD();
  updateRangeIndicator();
}


  function sellSelectedTower() {
    const t = game.selectedTower;
    if (!t) return;
    game.gold += Math.round(t.baseCost * (0.65 + t.level * 0.12));
    if (t.pad) t.pad.tower = null;
    const i = game.towers.indexOf(t);
    if (i >= 0) game.towers.splice(i, 1);
    const ii = interactive.indexOf(t.collider);
    if (ii >= 0) interactive.splice(ii, 1);
    world.remove(t.mesh);
    game.selectedTower = null;
    updateRangeIndicator(null);
    showMessage('Tower sold');
    updateHUD();
  }

  function spawnEnemy() {
    if (game.spawnIndex >= currentWave.length) return;
    const def = currentWave[game.spawnIndex++];
    if (def.phase === 'miniBoss') showMessage(`${enemyDefs[def.type].name} enters the field`);
    if (def.phase === 'boss') showMessage('Astral Warden arrives');
    createEnemy(def);
  }

  function startWave() {
    if (game.waveActive || game.gameOver) return;
    game.wave += 1;
    currentWave = makeWave(game.wave);
    game.waveActive = true;
    game.spawnTimer = 0;
    game.spawnIndex = 0;
    const cycle = ((game.wave - 1) % 12) + 1;
    if (cycle === 4 || cycle === 7 || cycle === 10) showMessage('Mini-boss phase');
    else if (cycle === 12) showMessage('Boss phase');
    else showMessage(`Wave ${game.wave} started`);
    updateHUD();
  }

  function makeProjectile(tower, target) {
    const logicType = tower.type;
    const group = new THREE.Group();
    const origin = tower.fxAnchor ? tower.fxAnchor.getWorldPosition(new THREE.Vector3()) : tower.mesh.position.clone().add(new THREE.Vector3(0, 3, 0));
    group.position.copy(origin);

    const projectile = {
      type: tower.type,
      mesh: group,
      target,
      tower,
      speed: tower.projectileSpeed,
      damage: tower.damage,
      splash: tower.splash,
      pierce: tower.pierce,
      chain: tower.chain || 0,
      dead: false,
      evoTrail: tower.level === 4,
      evoTrailTimer: 0
    };

    if (tower.level >= 3) {
      projectile.mesh.scale.setScalar(1.25);
    }

    if (tower.type === 'arrow') {
      const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.06, 0.06), new THREE.MeshStandardMaterial({ color: 0x5b4631, roughness: 0.85 }));
      shaft.rotation.z = Math.PI / 2;
      group.add(shaft);
      const head = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.2, 6), new THREE.MeshStandardMaterial({ color: tower.projectileColor, emissive: tower.projectileColor, emissiveIntensity: 0.28 }));
      head.rotation.z = -Math.PI / 2;
      head.position.x = 0.25;
      group.add(head);
    } else if (tower.type === 'ballista') {
      const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.1, 0.1), new THREE.MeshStandardMaterial({ color: 0xbfa27a, emissive: 0xf5e1c1, emissiveIntensity: 0.1, roughness: 0.72 }));
      bolt.rotation.z = Math.PI / 2;
      group.add(bolt);
    } else if (tower.type === 'bombard') {
      const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(0.28, 0), new THREE.MeshStandardMaterial({ color: 0x2f353e, metalness: 0.4, roughness: 0.75, emissive: 0x331507, emissiveIntensity: 0.2 }));
      group.add(shell);
      const magma = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 14), makeLavaShaderMaterial(0xff6929, 0xfff1a2, { opacity: 0.48, speed: 1.8 }));
      group.add(magma);
      projectile.coreShell = shell;
    } else if (tower.type === 'frost') {
      const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.26, 0), new THREE.MeshStandardMaterial({ color: 0xd7fbff, emissive: 0x8fe1ff, emissiveIntensity: 0.65, roughness: 0.16 }));
      group.add(shard);
      for (let i = 0; i < 3; i++) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.2 + i * 0.05, 0.012, 6, 16), makeGlowShaderMaterial(0xbff3ff, 0xffffff, { opacity: 0.28, speed: 1.6 }));
        ring.rotation.set(i * 0.7, i * 0.5, 0);
        group.add(ring);
      }
    } else if (tower.type === 'sunfire') {
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 14), new THREE.MeshStandardMaterial({ color: 0xffedb0, emissive: 0xffd978, emissiveIntensity: 1.1, roughness: 0.08 }));
      group.add(orb);
      const corona = new THREE.Mesh(new THREE.RingGeometry(0.18, 0.34, 24), makeGlowShaderMaterial(0xffd98f, 0xffffff, { opacity: 0.48, speed: 1.8 }));
      corona.rotation.y = Math.PI / 2;
      group.add(corona);
      projectile.orbit = corona;
      const light = new THREE.PointLight(0xffd790, 1.2, 8, 2);
      group.add(light);
      projectile.light = light;
    } else if (tower.type === 'storm') {
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), new THREE.MeshStandardMaterial({ color: 0xd9f7ff, emissive: 0xa8e5ff, emissiveIntensity: 1.2, roughness: 0.06 }));
      group.add(orb);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.03, 8, 18), makeGlowShaderMaterial(0x8fddff, 0xffffff, { opacity: 0.36, speed: 2.0 }));
      ring.rotation.y = Math.PI / 2;
      group.add(ring);
      projectile.orbit = ring;
    } else if (tower.type === 'alchemist') {
      const vial = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.13, 0.42, 10), new THREE.MeshStandardMaterial({ color: 0xccff77, emissive: 0x97d541, emissiveIntensity: 0.92, transparent: true, opacity: 0.88 }));
      group.add(vial);
      const cork = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.08, 8), new THREE.MeshStandardMaterial({ color: 0x8b6b4a, roughness: 1 }));
      cork.position.y = 0.24;
      group.add(cork);
    } else if (tower.type === 'dragon') {
      const fireball = new THREE.Mesh(new THREE.SphereGeometry(0.24, 14, 14), makeLavaShaderMaterial(0xff6b2d, 0xffef9d, { opacity: 0.58, speed: 2.0 }));
      group.add(fireball);
      const smoke = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 10), new THREE.MeshBasicMaterial({ color: 0x55362e, transparent: true, opacity: 0.14 }));
      group.add(smoke);
    }

    world.add(group);

    if (tower.level >= 3) {
      projectile.mesh.scale.setScalar(1.25);
    }

    if (tower.type === 'sunfire') {
      game.beams.push({ from: origin.clone(), to: target.mesh.position.clone().add(new THREE.Vector3(0, 1.4, 0)), life: 0.16, maxLife: 0.16, color: 0xfff2bd });
    }

    game.projectiles.push(projectile);
  }

  function addParticle(position, color, options = {}) {
    if (game.particles && game.particles.length > 240) return;
    const particle = new THREE.Mesh(new THREE.SphereGeometry(options.size || 0.12, 8, 8), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: options.opacity || 1 }));
    particle.position.copy(position);
    world.add(particle);
    game.particles.push({
      mesh: particle,
      velocity: options.velocity || new THREE.Vector3(rand(-1, 1), rand(1, 4), rand(-1, 1)),
      life: options.life || 0.5,
      gravity: options.gravity || 0,
      drag: options.drag || 0.95,
      shrink: options.shrink || 0.98,
      flicker: options.flicker || false
    });
  }

  function explode(position, color, count, spread, options = {}) {
    for (let i = 0; i < count; i++) {
      const velocity = new THREE.Vector3(rand(-spread, spread), rand(1, spread * 1.2), rand(-spread, spread));
      addParticle(position, color, {
        size: options.size || rand(0.08, 0.22),
        velocity,
        life: options.life || rand(0.24, 0.6),
        gravity: options.gravity || 0,
        drag: options.drag || 0.95,
        flicker: options.flicker || false
      });
    }
  }

  function addFlashLight(position, color, intensity, distance, duration) {
    const light = new THREE.PointLight(color, intensity, distance, 2);
    light.position.copy(position);
    world.add(light);
    game.flashLights.push({ light, life: duration, maxLife: duration });
  }

  function applyDamage(enemy, amount, tower) {
    enemy.hp -= amount;
    enemy.hitFlash = 0.14;
    if (tower && tower.slow) {
      enemy.slowFactor = Math.min(enemy.slowFactor, 1 - tower.slow);
      enemy.slowTimer = Math.max(enemy.slowTimer, 0.9);
    }
    if (tower && tower.type === 'storm' && tower.level >= 4) enemy.stunTimer = Math.max(enemy.stunTimer, 0.18);
    if (tower && tower.type === 'dragon' && tower.level >= 3) { enemy.burnTimer = 1.4; enemy.burnDamage = Math.max(enemy.burnDamage || 0, tower.damage * 0.08); }
    if (tower && tower.type === 'sunfire' && tower.level >= 3) { enemy.burnTimer = 1.0; enemy.burnDamage = Math.max(enemy.burnDamage || 0, tower.damage * 0.1); }
    if (tower && tower.type === 'alchemist' && tower.level >= 2) { enemy.poisonTimer = 1.6; enemy.poisonDamage = Math.max(enemy.poisonDamage || 0, tower.damage * 0.07); }
    const hitPos = enemy.mesh.position.clone().add(new THREE.Vector3(0, enemy.size * 1.2, 0));
    const burstColor = tower ? tower.projectileColor : 0xffffff;
    explode(hitPos, burstColor, 5, 1.1, { size: rand(0.06, 0.12), life: 0.24, drag: 0.9, gravity: 1.2 });
    if (enemy.hp <= 0 && !enemy.dead) {
      enemy.dead = true;
      game.gold += enemy.reward + ((tower && tower.type === 'alchemist' && tower.level >= 4) ? 3 : 0);
      const deathPos = enemy.mesh.position.clone().add(new THREE.Vector3(0, enemy.size * 0.8, 0));
      explode(deathPos, burstColor, enemy.phase === 'boss' ? 48 : enemy.phase === 'miniBoss' ? 32 : enemy.type === 'brute' ? 30 : 16, enemy.phase === 'boss' ? 4 : enemy.phase === 'miniBoss' ? 3 : 1.5, { size: rand(0.08, 0.2), life: rand(0.34, 0.7), gravity: 1.5, drag: 0.92, flicker: true });
      if (enemy.phase === 'boss') { addFlashLight(deathPos, 0xbd88ff, 4.2, 30, 0.24); game.screenShake = Math.max(game.screenShake, 0.65); }
      if (enemy.phase === 'miniBoss') { addFlashLight(deathPos, 0xffc389, 3.2, 22, 0.18); game.screenShake = Math.max(game.screenShake, 0.36); }
      if (tower && (tower.type === 'bombard' || tower.type === 'dragon')) { addFlashLight(deathPos, 0xffa55d, 2.2, 14, 0.12); game.screenShake = Math.max(game.screenShake, 0.22); }
    }
  }

  function hitProjectile(projectile, target) {
    if (projectile.type === 'bombard') {
      const splash = projectile.splash + (projectile.tower.level >= 2 ? 1.3 : 0) + (projectile.tower.level >= 4 ? 1.1 : 0);
      for (const enemy of game.enemies) {
        if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= splash) {
          applyDamage(enemy, projectile.damage * (enemy === target ? 1 : 0.72), projectile.tower);
        }
      }
      const pos = target.mesh.position.clone().add(new THREE.Vector3(0, 1.1, 0));
      explode(pos, 0xffb86a, 26, 2.6, { size: rand(0.1, 0.24), life: rand(0.3, 0.65), gravity: 1.4 });
      addFlashLight(pos, 0xffa55a, 2.8, 18, 0.16);
      game.screenShake = Math.max(game.screenShake, 0.48);
    } else if (projectile.type === 'ballista') {
      applyDamage(target, projectile.damage, projectile.tower);
      const extraPierce = projectile.tower.level >= 2 ? 1 : 0;
      const others = game.enemies.filter(e => e !== target && !e.dead).sort((a, b) => projectile.mesh.position.distanceTo(a.mesh.position) - projectile.mesh.position.distanceTo(b.mesh.position));
      let count = 0;
      for (const enemy of others) {
        if (count >= projectile.pierce + extraPierce) break;
        if (enemy.mesh.position.distanceTo(target.mesh.position) <= 5.2) {
          applyDamage(enemy, projectile.damage * 0.75, projectile.tower);
          if (projectile.tower.level >= 2) enemy.stunTimer = Math.max(enemy.stunTimer, 0.18);
          count += 1;
        }
      }
    } else if (projectile.type === 'storm') {
      applyDamage(target, projectile.damage, projectile.tower);
      const hops = projectile.chain + (projectile.tower.level >= 2 ? 1 : 0) + (projectile.tower.level >= 3 ? 1 : 0);
      const chainTargets = game.enemies.filter(e => e !== target && !e.dead && e.mesh.position.distanceTo(target.mesh.position) <= 7.8).slice(0, hops);
      let from = target.mesh.position.clone().add(new THREE.Vector3(0, target.size * 0.8, 0));
      for (const enemy of chainTargets) {
        const to = enemy.mesh.position.clone().add(new THREE.Vector3(0, enemy.size * 0.8, 0));
        game.beams.push({ from: from.clone(), to: to.clone(), life: 0.12, maxLife: 0.12, color: 0xb9ebff });
        applyDamage(enemy, projectile.damage * 0.68, projectile.tower);
        from = to;
      }
    } else if (projectile.type === 'alchemist') {
      const radius = projectile.splash + (projectile.tower.level >= 3 ? 1.3 : 0);
      for (const enemy of game.enemies) {
        if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= radius) {
          applyDamage(enemy, projectile.damage * (enemy === target ? 1 : 0.65), projectile.tower);
        }
      }
      explode(target.mesh.position.clone().add(new THREE.Vector3(0, 1.1, 0)), 0xc7ff73, 20, 1.8, { size: rand(0.08, 0.16), life: 0.35, gravity: -0.1, drag: 0.94 });
    } else if (projectile.type === 'dragon') {
      const radius = projectile.splash + (projectile.tower.level >= 4 ? 1.4 : 0);
      for (const enemy of game.enemies) {
        if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= radius) {
          applyDamage(enemy, projectile.damage * (enemy === target ? 1 : 0.72), projectile.tower);
        }
      }
      explode(target.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xff9549, 24, 2.2, { size: rand(0.08, 0.22), life: 0.38, gravity: 0.6 });
    } else {
      applyDamage(target, projectile.damage, projectile.tower);
      if (projectile.type === 'sunfire' && projectile.tower.level >= 2) {
        const extras = game.enemies.filter(e => e !== target && !e.dead && e.mesh.position.distanceTo(target.mesh.position) <= 6.5).slice(0, projectile.tower.level >= 4 ? 2 : 1);
        for (const enemy of extras) {
          game.beams.push({ from: target.mesh.position.clone().add(new THREE.Vector3(0, target.size * 0.8, 0)), to: enemy.mesh.position.clone().add(new THREE.Vector3(0, enemy.size * 0.8, 0)), life: 0.1, maxLife: 0.1, color: 0xffefbd });
          applyDamage(enemy, projectile.damage * 0.5, projectile.tower);
        }
      }
    }
    projectile.dead = true;
  }

  function removeEnemy(enemy) {
    world.remove(enemy.mesh);
    const idx = game.enemies.indexOf(enemy);
    if (idx >= 0) game.enemies.splice(idx, 1);
  }

  function updateEnemies(dt) {
    for (const enemy of [...game.enemies]) {
      enemy.anim += dt * 8;
      if (enemy.slowTimer > 0) {
        enemy.slowTimer -= dt;
        if (enemy.slowTimer <= 0) enemy.slowFactor = 1;
      }
      if (enemy.stunTimer > 0) enemy.stunTimer -= dt;
      if (enemy.burnTimer > 0) {
        enemy.burnTimer -= dt;
        enemy.hp -= (enemy.burnDamage || 0) * dt;
      }
      if (enemy.poisonTimer > 0) {
        enemy.poisonTimer -= dt;
        enemy.hp -= (enemy.poisonDamage || 0) * dt;
      }
      if (enemy.hp <= 0 && !enemy.dead) {
        enemy.dead = true;
        game.gold += enemy.reward;
      }

      enemy.distance += enemy.speed * enemy.slowFactor * (enemy.stunTimer > 0 ? 0 : 1) * dt;
      const t = THREE.MathUtils.clamp(enemy.distance / pathLength, 0, 1);
      const point = pathCurve.getPointAt(t);
      const look = pathCurve.getPointAt(Math.min(0.999, t + 0.002));
      enemy.mesh.position.set(point.x, 0, point.z);
      const bob = Math.sin(enemy.anim * 1.8) * (enemy.hover ? 0.22 : 0.09);
      const funnyTilt = Math.sin(enemy.anim * 2.4) * (enemy.phase === 'boss' ? 0.18 : 0.07);
      enemy.mesh.position.y = (enemy.hover ? 0.52 : 0) + bob;
      enemy.mesh.lookAt(look.x, 0.2 + funnyTilt * 0.5, look.z);
      enemy.mesh.rotation.z = funnyTilt * 0.6;
      if (enemy.walkers) enemy.walkers.forEach((part, i) => {
        part.rotation.x = Math.sin(enemy.anim * 1.6 + i * 1.1) * (0.65 + (enemy.phase === 'miniBoss' ? 0.3 : 0));
        part.position.y = Math.sin(enemy.anim * 2.1 + i) * 0.08;
      });
      if (enemy.swayers) enemy.swayers.forEach((part, i) => {
        part.rotation.y = Math.sin(enemy.anim * 1.1 + i * 0.7) * 0.38;
        if (enemy.phase === 'boss') { part.rotation.z += dt * 0.28; part.rotation.x = Math.sin(enemy.anim * 1.9) * 0.25; }
      });
      if (enemy.aura) {
        enemy.aura.scale.setScalar(0.92 + Math.sin(game.time * 4.2 + enemy.anim) * 0.14);
        enemy.aura.rotation.z += dt * (0.55 + (enemy.phase === 'boss' ? 0.4 : 0));
      }
      enemy.healthFg.scale.x = Math.max(0.01, enemy.hp / enemy.maxHp);
      enemy.healthFg.position.x = -((1 - enemy.hp / enemy.maxHp) * enemy.healthWidth) / 2;

      if (enemy.hitFlash > 0) enemy.hitFlash -= dt;
      if ((['cultist', 'pyreAbbot', 'astralWarden', 'plagueCart'].includes(enemy.type)) && Math.random() < dt * 10) {
        addParticle(enemy.mesh.position.clone().add(new THREE.Vector3(rand(-0.2, 0.2), 1.5 + (enemy.phase === 'boss' ? 0.6 : 0), rand(-0.2, 0.2))), enemy.type === 'plagueCart' ? 0xb8ff71 : enemy.phase === 'boss' ? 0xb287ff : 0xff9a58, { size: rand(0.05, 0.12), velocity: new THREE.Vector3(rand(-0.3, 0.3), rand(0.6, 1.6), rand(-0.3, 0.3)), life: 0.35, drag: 0.92 });
      }

      if (t >= 1) {
        enemy.reached = true;
        game.lives -= enemy.phase === 'boss' ? 8 : enemy.phase === 'miniBoss' ? 4 : ['batteringRam','warWagon','plagueCart'].includes(enemy.type) ? 3 : enemy.type === 'brute' ? 3 : enemy.type === 'knight' ? 2 : 1;
        removeEnemy(enemy);
        game.screenShake = Math.max(game.screenShake, 0.18);
        showMessage('The gate is hit!');
        if (game.lives <= 0) {
          game.lives = 0;
          game.gameOver = true;
          showMessage('Blackwall has fallen');
        }
      } else if (enemy.dead) {
        removeEnemy(enemy);
      }
    }
  }

  function updateTowers(dt) {
    for (const pad of game.pads) {
      const hover = game.hoveredPad === pad && !pad.tower;
      const pulse = (Math.sin(game.time * 3 + pad.pulse) + 1) * 0.5;
      if (pad.halo && pad.halo.material) {
        pad.halo.material.opacity = hover ? 0.4 : pad.tower ? 0.14 : 0.18 + pulse * 0.12;
        pad.halo.scale.setScalar(hover ? 1.18 : 1 + pulse * 0.1);
        pad.halo.rotation.z += dt * (hover ? 1.4 : 0.45);
      }
      if (pad.cap && pad.cap.material) {
        pad.cap.material.emissiveIntensity = hover ? 1.3 : pad.tower ? 0.5 : 0.78 + pulse * 0.22;
        pad.cap.position.y = 3.92 + (hover ? 0.08 : pulse * 0.06);
        pad.cap.rotation.y += dt * (hover ? 2.2 : 0.7);
      }
      if (pad.banner && pad.banner.material) {
        pad.banner.material.opacity = hover ? 0.9 : pad.tower ? 0.35 : 0.55 + pulse * 0.16;
        pad.banner.rotation.z = Math.sin(game.time * 2.8 + pad.pulse) * 0.08;
      }
      if (pad.obelisk && pad.obelisk.material && pad.obelisk.material.emissiveIntensity !== undefined) {
        pad.obelisk.material.emissiveIntensity = hover ? 0.26 : pad.tower ? 0.1 : 0.08 + pulse * 0.08;
      }
    }

    for (const tower of game.towers) {
      tower.cooldown -= dt;
      tower.recoil = Math.max(0, tower.recoil - dt * 4);
      tower.glowPulse = Math.max(0, tower.glowPulse - dt * 1.1);
      tower.auraTick -= dt;
      if (tower.core.material.emissiveIntensity !== undefined) tower.core.material.emissiveIntensity = 0.16 + tower.glowPulse * 0.8;
      if (tower.aura) tower.aura.scale.setScalar(1 + Math.sin(game.time * 2.0 + tower.mesh.position.x * 0.1) * 0.06 + tower.glowPulse * 0.1);
      if (tower.turret) tower.turret.position.y = tower.turretBaseY - tower.recoil * 0.08;

      if (tower.animParts) {
        for (const part of tower.animParts) {
          const mesh = part.mesh;
          if (part.kind === 'groundAura') {
            mesh.rotation.z += dt * 0.2;
          } else if (part.kind === 'banner') {
            mesh.rotation.z = Math.sin(game.time * part.speed + part.phase) * 0.08;
            mesh.position.y = 0.9 + Math.sin(game.time * part.speed * 1.2 + part.phase) * 0.04;
          } else if (part.kind === 'watcher') {
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed + part.phase) * 0.05;
            mesh.rotation.y = Math.sin(game.time * part.speed * 0.7 + part.phase) * 0.35;
          } else if (part.kind === 'wheel') {
            mesh.rotation.x += dt * 0.2;
          } else if (part.kind === 'spinY') {
            mesh.rotation.y += dt * part.speed;
          } else if (part.kind === 'spinX') {
            mesh.rotation.x += dt * part.speed;
          } else if (part.kind === 'spinXYZ') {
            mesh.rotation.x += dt * part.speed;
            mesh.rotation.y += dt * part.speed * 1.2;
            mesh.rotation.z += dt * part.speed * 0.9;
          } else if (part.kind === 'hover') {
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed + part.phase) * 0.08;
          } else if (part.kind === 'pulseY') {
            mesh.position.y = 2.52 + Math.sin(game.time * part.speed + part.phase) * 0.06;
          } else if (part.kind === 'orbit') {
            mesh.position.x = Math.cos(game.time * part.speed + part.offset) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed + part.offset) * part.radius;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 1.8 + part.offset) * 0.08;
          } else if (part.kind === 'orbitFlat') {
            mesh.position.x = Math.cos(game.time * part.speed + part.offset) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed + part.offset) * part.radius;
            mesh.rotation.z += dt * 0.8;
          } else if (part.kind === 'arrowBanner') {
            mesh.rotation.z = 0.04 + Math.sin(game.time * part.speed + part.phase) * 0.2 * (part.side || 1);
            mesh.rotation.y = (part.side || 1) * 0.2 + Math.sin(game.time * part.speed * 0.8 + part.phase) * 0.06;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 1.3 + part.phase) * 0.08;
          } else if (part.kind === 'arrowOrbit') {
            mesh.position.x = Math.cos(game.time * part.speed + part.offset) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed + part.offset) * part.radius;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 2.3 + part.offset) * 0.05;
            mesh.lookAt(0, part.baseY, 0);
          } else if (part.kind === 'arrowHalo') {
            mesh.rotation.z += dt * part.speed;
            mesh.scale.setScalar(1 + Math.sin(game.time * 2.2 + part.phase) * 0.08);
            mesh.position.y = part.baseY + Math.sin(game.time * 1.4 + part.phase) * 0.08;
          } else if (part.kind === 'ballistaTension') {
            mesh.rotation.z = 0.52 * (part.dir || 1) + Math.sin(game.time * part.speed + part.phase) * 0.22 * (part.dir || 1);
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 1.4 + part.phase) * 0.04;
          } else if (part.kind === 'gearSpin') {
            mesh.rotation.z -= dt * part.speed;
          } else if (part.kind === 'scopePulse') {
            mesh.scale.setScalar(1 + Math.sin(game.time * part.speed + part.phase) * 0.18);
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 0.7 + part.phase) * 0.03;
          } else if (part.kind === 'ventChug') {
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * part.speed + part.phase)) * 0.12;
            mesh.scale.y = 1 + Math.abs(Math.sin(game.time * part.speed * 1.3 + part.phase)) * 0.22;
          } else if (part.kind === 'bombardShell') {
            mesh.position.x = part.baseX + Math.sin(game.time * part.speed + part.phase) * 0.18;
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * part.speed * 0.7 + part.phase)) * 0.08;
            mesh.rotation.z += dt * 1.4;
          } else if (part.kind === 'bombardMuzzle') {
            mesh.rotation.z += dt * part.speed;
            mesh.scale.setScalar(0.95 + Math.abs(Math.sin(game.time * part.speed + part.phase)) * 0.35);
            mesh.position.x = part.baseX + Math.sin(game.time * 1.3 + part.phase) * 0.03;
          } else if (part.kind === 'frostSpiral') {
            mesh.position.x = Math.cos(game.time * part.speed + part.offset) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed + part.offset) * part.radius;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 2.0 + part.offset) * 0.16;
            mesh.rotation.x += dt * 2.2;
            mesh.rotation.z += dt * 1.6;
          } else if (part.kind === 'frostRing') {
            mesh.rotation.z += dt * part.speed;
            mesh.scale.setScalar(1 + Math.sin(game.time * 1.8 + part.phase) * 0.05);
          } else if (part.kind === 'frostCrown') {
            mesh.rotation.y += dt * part.speed;
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * 1.6 + part.phase)) * 0.12;
          } else if (part.kind === 'sunHalo') {
            mesh.rotation.z += dt * part.speed;
            mesh.scale.setScalar(1 + Math.sin(game.time * 2.0 + part.phase) * 0.09);
          } else if (part.kind === 'sunRay') {
            const a = part.phase + game.time * part.speed;
            mesh.position.x = Math.cos(a) * part.radius;
            mesh.position.z = Math.sin(a) * part.radius;
            mesh.position.y = part.baseY + Math.sin(game.time * 2.4 + part.phase) * 0.08;
            mesh.rotation.y = a;
            mesh.scale.y = 0.8 + Math.abs(Math.sin(game.time * 2.0 + part.phase)) * 0.7;
          } else if (part.kind === 'sunNova') {
            mesh.scale.setScalar(0.9 + Math.abs(Math.sin(game.time * part.speed + part.phase)) * 0.55);
            mesh.position.y = part.baseY + Math.sin(game.time * 2.2 + part.phase) * 0.05;
          } else if (part.kind === 'stormArc') {
            mesh.rotation.x += dt * part.speed * 0.7;
            mesh.rotation.y += dt * part.speed;
            mesh.rotation.z += dt * part.speed * 1.3;
            mesh.position.y = part.baseY + (Math.random() - 0.5) * 0.05;
            mesh.scale.setScalar(0.92 + Math.random() * 0.22);
          } else if (part.kind === 'stormCoil') {
            mesh.rotation.y += dt * part.speed;
            mesh.scale.y = 1 + Math.sin(game.time * 4.0 + part.phase) * 0.22;
          } else if (part.kind === 'stormPrism') {
            mesh.rotation.x += dt * part.speed;
            mesh.rotation.y += dt * part.speed * 1.2;
            mesh.position.y = part.baseY + Math.sin(game.time * 3.8 + part.phase) * 0.14;
          } else if (part.kind === 'alchemyBubble') {
            mesh.position.x = Math.cos(game.time * part.speed + part.phase) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed * 0.85 + part.phase) * part.radius * 0.8;
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * part.speed + part.phase)) * 0.34;
            mesh.scale.setScalar(0.85 + Math.sin(game.time * 3.0 + part.phase) * 0.12);
          } else if (part.kind === 'alchemySwirl') {
            mesh.rotation.z -= dt * part.speed;
            mesh.position.y = part.baseY + Math.sin(game.time * 1.5 + part.phase) * 0.04;
          } else if (part.kind === 'alchemyFlask') {
            mesh.rotation.z = Math.sin(game.time * part.speed + part.phase) * 0.25;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 1.3 + part.phase) * 0.15;
          } else if (part.kind === 'dragonEmber') {
            mesh.position.x = part.baseX + Math.sin(game.time * part.speed + part.phase) * 0.18;
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * part.speed * 1.5 + part.phase)) * 0.2;
            mesh.scale.setScalar(0.85 + Math.abs(Math.sin(game.time * 3.6 + part.phase)) * 0.35);
          } else if (part.kind === 'dragonWing') {
            mesh.rotation.z = 0.18 * (part.side || 1) + Math.sin(game.time * part.speed + part.phase) * 0.55 * (part.side || 1);
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 1.2 + part.phase) * 0.12;
          } else if (part.kind === 'dragonCrest') {
            mesh.rotation.y += dt * part.speed;
            mesh.rotation.z = Math.sin(game.time * 2.2 + part.phase) * 0.3;
            mesh.position.y = part.baseY + Math.sin(game.time * 1.8 + part.phase) * 0.1;
          } else if (part.kind === 'sniperMarker') {
            mesh.rotation.z += dt * part.speed;
            mesh.scale.setScalar(0.95 + Math.abs(Math.sin(game.time * 2.2 + part.phase)) * 0.18);
            mesh.position.x = part.baseX + Math.sin(game.time * 1.2 + part.phase) * 0.03;
          } else if (part.kind === 'dialSpin') {
            mesh.rotation.y += dt * part.speed;
            mesh.rotation.x += dt * part.speed * 0.35;
          } else if (part.kind === 'turretGyro') {
            mesh.rotation.z += dt * part.speed;
            mesh.rotation.x = Math.PI / 2 + Math.sin(game.time * 2.6 + part.phase) * 0.2;
          } else if (part.kind === 'turretBarrel') {
            mesh.rotation.x += dt * part.speed;
            mesh.position.x = part.baseX + Math.sin(game.time * 3.0 + part.phase) * 0.04;
          } else if (part.kind === 'turretNode') {
            mesh.scale.setScalar(0.88 + Math.abs(Math.sin(game.time * part.speed + part.phase)) * 0.42);
            mesh.position.y = part.baseY + Math.sin(game.time * 2.8 + part.phase) * 0.08;
          } else if (part.kind === 'hawkGlide') {
            mesh.position.x = Math.cos(game.time * part.speed + part.phase) * part.radius;
            mesh.position.z = Math.sin(game.time * part.speed + part.phase) * part.radius * 0.9;
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed * 2.0 + part.phase) * 0.22;
            mesh.rotation.z = Math.sin(game.time * part.speed + part.phase) * 0.45;
          } else if (part.kind === 'hawkGust') {
            mesh.rotation.z -= dt * part.speed;
            mesh.scale.setScalar(0.92 + Math.sin(game.time * 2.5 + part.phase) * 0.08);
          } else if (part.kind === 'hawkFeather') {
            mesh.rotation.z = Math.sin(game.time * part.speed + part.phase) * 0.45;
            mesh.position.y = part.baseY + Math.abs(Math.sin(game.time * part.speed * 1.4 + part.phase)) * 0.22;
          } else if (part.kind === 'bob') {
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed + part.phase) * 0.06;
          } else if (part.kind === 'dragonHead') {
            mesh.position.y = part.baseY + Math.sin(game.time * part.speed + part.phase) * 0.04;
            mesh.rotation.z = Math.sin(game.time * part.speed * 0.5 + part.phase) * 0.12;
          } else if (part.kind === 'lightPulse' && part.light) {
            part.light.intensity = 1.0 + (Math.sin(game.time * part.speed + part.phase) + 1) * 0.3;
          }
        }
      }

      const chaos = Math.max(0, (tower.level - 1) * 0.65 + (tower.level >= 4 ? 1.2 : 0));
      if (chaos > 0.1) {
        if (tower.core) {
          const pulse = Math.sin(game.time * (3.5 + chaos * 1.8)) * (0.06 + chaos * 0.04);
          tower.core.scale.setScalar(1 + pulse);
          if (tower.core.material && tower.core.material.emissiveIntensity !== undefined) {
            tower.core.material.emissiveIntensity = 0.18 + Math.sin(game.time * 7 + chaos) * (0.3 + chaos * 0.4);
          }
        }
        if (tower.level >= 3 && Math.random() < dt * 4) {
          tower.mesh.position.x += (Math.random() - 0.5) * chaos * 0.008;
          tower.mesh.position.z += (Math.random() - 0.5) * chaos * 0.008;
          tower.mesh.position.y = Math.max(0, tower.mesh.position.y + (Math.random() - 0.5) * chaos * 0.003);
        }
        if (tower.level >= 2 && Math.random() < dt * (6 + chaos * 3)) {
          const pPos = tower.fxAnchor ? tower.fxAnchor.getWorldPosition(new THREE.Vector3()) : tower.mesh.position.clone().add(new THREE.Vector3(0, 2.5, 0));
          const pColor = tower.projectileColor || 0xffffff;
          addParticle(pPos, pColor, { size: 0.04 + chaos * 0.03, velocity: new THREE.Vector3((Math.random()-0.5)*1.2, 0.8 + chaos, (Math.random()-0.5)*1.2), life: 0.35 + chaos * 0.2, drag: 0.9, flicker: tower.level >= 4 });
        }
        if (tower.level >= 4 && Math.random() < dt * 3) {
          const sparkPos = tower.mesh.position.clone().add(new THREE.Vector3(rand(-1.8,1.8), 2.8, rand(-1.8,1.8)));
          addParticle(sparkPos, 0x8d69ff, { size: 0.07, velocity: new THREE.Vector3(rand(-2,2), rand(1.5,3.5), rand(-2,2)), life: 0.55, gravity: -0.4, drag: 0.85, flicker: true });
        }
        if (tower.chaosOrbs) {
          for (const orb of tower.chaosOrbs) {
            const a = game.time * orb.speed + orb.phase;
            orb.mesh.position.x = Math.cos(a) * orb.radius;
            orb.mesh.position.z = Math.sin(a * 1.3) * orb.radius * 0.7;
            orb.mesh.position.y = 2.8 + Math.sin(a * 2.2) * 0.6 + (tower.level >= 4 ? Math.sin(a * 5) * 0.3 : 0);
            orb.mesh.scale.setScalar(0.85 + Math.sin(a * 3) * 0.25);
            if (tower.level >= 4) orb.mesh.rotation.y += dt * 4.5;
          }
        }
      }

      if ((tower.displayType === 'sniper') && Math.random() < dt * 10) { addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0xeaf4ff, { size: rand(0.03,0.08), velocity: new THREE.Vector3(rand(-0.1,0.1), rand(0.1,0.25), rand(-0.1,0.1)), life: 0.18, drag: 0.95 }); }
      if ((tower.displayType === 'turret') && Math.random() < dt * 16) { addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0xffc783, { size: rand(0.03,0.07), velocity: new THREE.Vector3(rand(-0.12,0.12), rand(0.08,0.2), rand(-0.12,0.12)), life: 0.12, drag: 0.94 }); }
      if ((tower.displayType === 'hawk') && Math.random() < dt * 9) { addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0xeed8a8, { size: rand(0.04,0.08), velocity: new THREE.Vector3(rand(-0.15,0.15), rand(0.1,0.25), rand(-0.15,0.15)), life: 0.14, drag: 0.94 }); }
      if (tower.type === 'frost' && Math.random() < dt * 18) {
        addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone().add(new THREE.Vector3(rand(-0.2,0.2), rand(-0.2,0.2), rand(-0.2,0.2))), 0xc7f3ff, { size: rand(0.04,0.08), velocity: new THREE.Vector3(rand(-0.2,0.2), rand(0.3,0.8), rand(-0.2,0.2)), life: 0.4, drag: 0.95 });
      }
      if (tower.type === 'bombard' && tower.cooldown < tower.fireRate * 0.45 && Math.random() < dt * 8) {
        addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0x6c6d75, { size: rand(0.08,0.16), velocity: new THREE.Vector3(rand(-0.2,0.2), rand(0.5,1.2), rand(-0.2,0.2)), life: 0.5, drag: 0.92 });
      }
      if (tower.type === 'storm' && Math.random() < dt * 9) {
        addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0xb6e8ff, { size: rand(0.03,0.08), velocity: new THREE.Vector3(rand(-0.3,0.3), rand(0.2,0.7), rand(-0.3,0.3)), life: 0.24, drag: 0.9 });
      }
      if (tower.type === 'dragon' && Math.random() < dt * 8) {
        addParticle(tower.fxAnchor.getWorldPosition(tempVecA).clone(), 0xff8e52, { size: rand(0.06,0.11), velocity: new THREE.Vector3(rand(-0.18,0.18), rand(0.3,0.8), rand(-0.18,0.18)), life: 0.28, drag: 0.9 });
      }

      if (tower.type === 'dragon' && tower.level >= 3 && tower.auraTick <= 0) {
        tower.auraTick = 0.35;
        for (const enemy of game.enemies) {
          if (!enemy.dead && enemy.mesh.position.distanceTo(tower.mesh.position) <= 5.25) applyDamage(enemy, tower.damage * 0.15, tower);
        }
      }

      let target = null;
      let bestDistance = -Infinity;
      for (const enemy of game.enemies) {
        const d = enemy.mesh.position.distanceTo(tower.mesh.position);
        if (d <= tower.range && enemy.distance > bestDistance) {
          bestDistance = enemy.distance;
          target = enemy;
        }
      }

      if (target) {
        const aimTarget = target.mesh.position.clone().add(new THREE.Vector3(0, target.size * 0.8, 0));
        if (tower.turret) tower.turret.lookAt(aimTarget);
        if (tower.cooldown <= 0) {
          tower.cooldown = tower.fireRate;
          tower.recoil = 1;
          tower.glowPulse = 0.82;
          tower.shotsFired += 1;
          makeProjectile(tower, target);
          const altTargets = game.enemies.filter(e => e !== target && !e.dead && e.mesh.position.distanceTo(tower.mesh.position) <= tower.range).sort((a,b)=>b.distance-a.distance);
          if (tower.type === 'arrow' && tower.level >= 2 && altTargets[0]) makeProjectile({ ...tower, damage: tower.damage * 0.75 }, altTargets[0]);
          if (tower.type === 'arrow' && tower.level >= 3 && altTargets[1]) makeProjectile({ ...tower, damage: tower.damage * 0.7 }, altTargets[1]);
          if (tower.type === 'ballista' && tower.level >= 3) makeProjectile({ ...tower, damage: tower.damage * 0.65 }, target);
          if (tower.type === 'dragon' && tower.level >= 2 && altTargets[0]) makeProjectile({ ...tower, damage: tower.damage * 0.7 }, altTargets[0]);
          if (tower.type === 'dragon' && tower.level >= 2 && altTargets[1]) makeProjectile({ ...tower, damage: tower.damage * 0.7 }, altTargets[1]);
          if (tower.type === 'frost' && tower.level >= 2 && tower.shotsFired % 4 === 0) {
            for (const enemy of game.enemies) if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= 5.5) applyDamage(enemy, tower.damage * 0.45, tower);
            addFlashLight(target.mesh.position.clone().add(new THREE.Vector3(0,1.2,0)), 0xbef3ff, 1.6, 12, 0.12);
          }
          if (tower.displayType === 'sniper') game.beams.push({ from: firePos.clone(), to: target.mesh.position.clone().add(new THREE.Vector3(0, target.size * 0.8, 0)), life: 0.05, maxLife: 0.05, color: 0xeaf4ff });
          if (tower.displayType === 'turret') addFlashLight(firePos, 0xffdaae, 0.9, 5, 0.05);
          if (tower.displayType === 'hawk') explode(firePos, 0xeed8ad, 10, 0.4, { size: 0.05, life: 0.1, drag: 0.96 });
          if (tower.type === 'sunfire') addFlashLight(tower.mesh.position.clone().add(new THREE.Vector3(0, 3, 0)), 0xffdca0, 1.6, 10, 0.1);
        }
      }
    }
  }

  function updateProjectiles(dt) {
    for (const projectile of [...game.projectiles]) {
      if (!projectile.target || projectile.target.dead || projectile.target.reached) {
        projectile.dead = true;
      }
      if (projectile.dead) {
        world.remove(projectile.mesh);
        const idx = game.projectiles.indexOf(projectile);
        if (idx >= 0) game.projectiles.splice(idx, 1);
        continue;
      }

      const targetPos = projectile.target.mesh.position.clone().add(new THREE.Vector3(0, projectile.target.size * 1.0, 0));
      const dir = targetPos.clone().sub(projectile.mesh.position);
      const dist = dir.length();
      dir.normalize();
      projectile.mesh.position.addScaledVector(dir, projectile.speed * dt);
      projectile.mesh.lookAt(targetPos);
      projectile.mesh.rotateZ(dt * projectile.spinSpeed);
      if (projectile.orbit) projectile.orbit.rotation.z += dt * 2.4;
      if (projectile.light) projectile.light.intensity = 0.9 + Math.sin(game.time * 8.0) * 0.18;
      if (projectile.coreShell && projectile.coreShell.material && projectile.coreShell.material.emissiveIntensity !== undefined) {
        projectile.coreShell.material.emissiveIntensity = 0.14 + Math.sin(game.time * 9.0) * 0.08;
      }

      if (projectile.type === 'frost') {
        projectile.mesh.material && (projectile.mesh.material.opacity = 0.88);
        addParticle(projectile.mesh.position.clone(), 0xbfefff, { size: 0.06, velocity: new THREE.Vector3(rand(-0.2, 0.2), rand(-0.1, 0.3), rand(-0.2, 0.2)), life: 0.18, drag: 0.92 });
      } else if (projectile.type === 'sunfire') {
        addParticle(projectile.mesh.position.clone(), 0xffefb8, { size: 0.08, velocity: new THREE.Vector3(rand(-0.15, 0.15), rand(-0.1, 0.2), rand(-0.15, 0.15)), life: 0.15, drag: 0.93 });
      } else if (projectile.type === 'ballista') {
        addParticle(projectile.mesh.position.clone(), 0xf5e1c1, { size: 0.06, velocity: new THREE.Vector3(rand(-0.04, 0.04), rand(-0.03, 0.03), rand(-0.04, 0.04)), life: 0.1, drag: 0.95 });
      } else if (projectile.type === 'arrow') {
        addParticle(projectile.mesh.position.clone(), 0xe8d0a0, { size: 0.04, velocity: new THREE.Vector3(rand(-0.03, 0.03), rand(-0.02, 0.02), rand(-0.03, 0.03)), life: 0.06, drag: 0.95 });
      } else if (projectile.type === 'bombard' && Math.random() < dt * 22) {
        addParticle(projectile.mesh.position.clone(), Math.random() > 0.4 ? 0xff9849 : 0x777777, { size: 0.09, velocity: new THREE.Vector3(rand(-0.15, 0.15), rand(0.1, 0.45), rand(-0.15, 0.15)), life: 0.28, drag: 0.9, gravity: -0.2 });
      }

      if (projectile.evoTrail) {
        projectile.evoTrailTimer -= dt;
        if (projectile.evoTrailTimer <= 0) {
          projectile.evoTrailTimer = 0.06;
          addParticle(projectile.mesh.position.clone(), projectile.tower.projectileColor, { size: 0.06, velocity: new THREE.Vector3(0, 0.3, 0), life: 0.25, drag: 0.94 });
        }
      }

      if (dist < 0.9) {
        hitProjectile(projectile, projectile.target);
      }
    }
  }

  function updateParticles(dt) {
    for (const particle of [...game.particles]) {
      particle.life -= dt;
      particle.velocity.multiplyScalar(particle.drag);
      particle.velocity.y -= particle.gravity * dt;
      particle.mesh.position.addScaledVector(particle.velocity, dt);
      particle.mesh.scale.multiplyScalar(particle.shrink || 0.98);
      particle.mesh.material.opacity = Math.max(0, particle.life * 2.1);
      if (particle.flicker) particle.mesh.material.opacity *= 0.8 + Math.sin(game.time * 30) * 0.2;
      if (particle.life <= 0) {
        world.remove(particle.mesh);
        const idx = game.particles.indexOf(particle);
        if (idx >= 0) game.particles.splice(idx, 1);
      }
    }
  }

  function updateBeams(dt) {
    for (const beam of [...game.beams]) {
      beam.life -= dt;
      if (beam.life <= 0) {
        const idx = game.beams.indexOf(beam);
        if (idx >= 0) game.beams.splice(idx, 1);
      }
    }
  }

  function updateFlashLights(dt) {
    for (const flash of [...game.flashLights]) {
      flash.life -= dt;
      flash.light.intensity = (flash.life / flash.maxLife) * 3;
      if (flash.life <= 0) {
        world.remove(flash.light);
        const idx = game.flashLights.indexOf(flash);
        if (idx >= 0) game.flashLights.splice(idx, 1);
      }
    }
  }

  function updateAmbient(dt) {
    for (const shader of game.shaderMats) {
      if (shader.uniforms && shader.uniforms.uTime) shader.uniforms.uTime.value = game.time;
    }

    for (const torch of game.torches) {
      const flicker = 0.85 + Math.sin(game.time * 8 + torch.seed) * 0.1 + Math.random() * 0.08;
      torch.flame.scale.setScalar(flicker);
      torch.flame.position.y = 1.34 + Math.sin(game.time * 7 + torch.seed) * 0.05;
      torch.light.intensity = 1.1 + flicker * 0.7;
      if (Math.random() < dt * 18) {
        addParticle(torch.group.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(rand(-0.1, 0.1), 1.25, rand(-0.1, 0.1))), Math.random() > 0.4 ? 0xffaa55 : 0xffdd99, {
          size: rand(0.05, 0.12),
          velocity: new THREE.Vector3(rand(-0.2, 0.2), rand(0.9, 1.9), rand(-0.2, 0.2)),
          life: 0.42,
          drag: 0.92
        });
      }
    }

    for (const mist of game.mistPlanes) {
      mist.mesh.position.x = mist.baseX + Math.sin(game.time * mist.speed + mist.phase) * mist.amp;
      mist.mesh.material.opacity = 0.02 + (Math.sin(game.time * 0.7 + mist.phase) + 1) * 0.016;
    }

    const wind = Math.sin(game.time * 0.6) * 0.9 + Math.sin(game.time * 1.4) * 0.4;
    for (const flag of game.flags) {
      flag.mesh.rotation.y = flag.baseRotY + Math.sin(game.time * 2.6 + flag.phase) * (0.14 + wind * 0.02);
      flag.mesh.rotation.z = Math.sin(game.time * 3.4 + flag.phase) * (0.08 + Math.abs(wind) * 0.015);
      flag.mesh.position.y = flag.baseY + Math.sin(game.time * 4.2 + flag.phase) * 0.04;
      if (flag.mesh.material.color) flag.mesh.material.color.setHSL(0.94 + Math.sin(game.time * 0.2 + flag.hue) * 0.02, 0.62, 0.36);
    }

    for (const fx of game.waterFX) {
      if (fx.kind === 'river') {
        fx.mesh.material.emissiveIntensity = 0.22 + Math.sin(game.time * 1.4) * 0.07;
        fx.mesh.material.color.setHSL(0.59 + Math.sin(game.time * 0.18) * 0.02, 0.48, 0.24 + Math.sin(game.time * 0.3) * 0.02);
      } else if (fx.kind === 'ripple') {
        const s = 0.95 + Math.sin(game.time * fx.speed + fx.phase) * 0.18;
        fx.mesh.scale.setScalar(s);
        fx.mesh.material.opacity = 0.04 + (Math.sin(game.time * fx.speed + fx.phase) + 1) * 0.04;
      }
    }

    for (const ufo of game.ufos) {
      ufo.group.position.x = ufo.base.x + Math.sin(game.time * ufo.speed + ufo.phase) * 2.1;
      ufo.group.position.y = ufo.base.y + Math.sin(game.time * (ufo.speed * 1.4) + ufo.phase) * 0.8;
      ufo.group.rotation.y += dt * 0.6;
      ufo.ring.rotation.z += dt * 0.9;
      ufo.beam.material.opacity = 0.08 + (Math.sin(game.time * 4 + ufo.phase) + 1) * 0.03;
      ufo.light.intensity = 1.0 + (Math.sin(game.time * 4 + ufo.phase) + 1) * 0.35;
    }

    for (const fx of game.skyFX) {
      if (fx.kind === 'planetRing') {
        fx.mesh.rotation.z += dt * fx.speed;
      } else if (fx.kind === 'nebula') {
        fx.mesh.position.y = fx.baseY + Math.sin(game.time * fx.speed + fx.phase) * 0.8;
        fx.mesh.material.opacity = 0.06 + (Math.sin(game.time * fx.speed + fx.phase) + 1) * 0.03;
      } else if (fx.kind === 'auroraArc') {
        fx.mesh.rotation.z += dt * fx.speed;
        fx.mesh.material.opacity = 0.14 + Math.sin(game.time * 0.8 * fx.speed * 10) * 0.05;
      } else if (fx.kind === 'crystal') {
        fx.mesh.position.y = fx.baseY + Math.sin(game.time * fx.speed + fx.phase) * 0.08;
        fx.mesh.rotation.y += dt * 0.4;
      } else if (fx.kind === 'cropCircle') {
        fx.mesh.rotation.y += dt * fx.speed * 0.22;
        fx.mesh.position.y = 0.05 + Math.sin(game.time * fx.speed + fx.phase) * 0.012;
      } else if (fx.kind === 'blackholeDisk') {
        fx.mesh.rotation.z += dt * fx.speed * 1.8;
        if (fx.light) fx.light.intensity = 2.4 + Math.sin(game.time * 1.6 + fx.phase) * 0.9;
        fx.mesh.position.y = fx.baseY + Math.sin(game.time * 0.4 + fx.phase) * 0.03;
      } else if (fx.kind === 'blackholeRing') {
        fx.mesh.rotation.z += dt * fx.speed * 0.6;
        fx.mesh.scale.setScalar(1.0 + Math.sin(game.time * 3.2) * 0.04);
      }
    }

    for (const fx of game.volcanoFX) {
      if (fx.kind === 'smoke') {
        fx.mesh.position.y = fx.base.y + game.time * fx.speed * 0.55 + Math.sin(game.time * fx.speed + fx.phase) * 0.4;
        fx.mesh.position.x = fx.base.x + Math.sin(game.time * 0.6 + fx.phase) * 1.2;
        fx.mesh.position.z = fx.base.z + Math.cos(game.time * 0.5 + fx.phase) * 1.1;
        fx.mesh.material.opacity = 0.2 + Math.sin(game.time * 0.9 + fx.phase) * 0.05;
        if (fx.mesh.position.y > 38) fx.mesh.position.y = fx.base.y;
      } else if (fx.kind === 'light') {
        fx.light.intensity = 1.1 + (Math.sin(game.time * 2.2 + fx.phase) + 1) * 0.28;
      } else if (fx.kind === 'emberCone') {
        fx.mesh.scale.setScalar(0.95 + Math.sin(game.time * 2.5 + fx.phase) * 0.08);
        if (Math.random() < dt * 10) addParticle(new THREE.Vector3(54 + rand(-1.4,1.4), 20.8, -62 + rand(-1.2,1.2)), Math.random() > 0.4 ? 0xff9245 : 0xffd27b, { size: rand(0.05,0.1), velocity: new THREE.Vector3(rand(-0.2,0.2), rand(1.0,2.4), rand(-0.2,0.2)), life: rand(0.4,0.8), gravity: -0.2, drag: 0.95, flicker: true });
      } else if (fx.kind === 'lavaRock') {
        fx.rock.rotation.y += dt * 0.15 * fx.speed;
        fx.crack.scale.setScalar(0.96 + Math.sin(game.time * 3.0 * fx.speed + fx.phase) * 0.08);
        if (Math.random() < dt * 0.8) addParticle(fx.group.position.clone().add(new THREE.Vector3(rand(-0.3,0.3), rand(0.6,1.2), rand(-0.3,0.3))), 0xff7f3f, { size: rand(0.04,0.08), velocity: new THREE.Vector3(rand(-0.15,0.15), rand(0.3,0.9), rand(-0.15,0.15)), life: 0.45, gravity: 0.5, drag: 0.94, flicker: true });
      }
    }

    if (game.npcs) {
      for (const npc of game.npcs) {
        const ud = npc.userData;
        ud.walkPhase += dt * ud.speed;
        ud.headBob += dt * (1.6 + ud.swagger * 0.4);
        npc.position.x = ud.home.x + Math.sin(ud.walkPhase) * (2.8 + ud.swagger);
        npc.position.z = ud.home.z + Math.cos(ud.walkPhase * 0.72) * (2.1 + ud.swagger * 0.6);
        npc.rotation.y = Math.sin(ud.walkPhase * 0.9) * 0.18 + Math.cos(ud.walkPhase * 0.35) * 0.08;
        if (ud.torso) ud.torso.rotation.z = Math.sin(ud.walkPhase * 1.8) * 0.06;
        if (ud.head) {
          ud.head.position.y = 1.24 + Math.sin(ud.headBob) * 0.035;
          ud.head.rotation.z = Math.sin(ud.walkPhase * 1.2) * 0.05;
        }
        if (ud.cape) {
          ud.cape.rotation.x = 0.18 + Math.sin(game.time * 2.2 + ud.walkPhase) * 0.12;
          ud.cape.rotation.y = Math.sin(game.time * 1.4 + ud.walkPhase) * 0.1;
        }
        if (ud.shoulderL) ud.shoulderL.position.y = 0.8 + Math.sin(ud.walkPhase * 1.8) * 0.03;
        if (ud.shoulderR) ud.shoulderR.position.y = 0.8 + Math.cos(ud.walkPhase * 1.8) * 0.03;
        if (ud.prop) {
          ud.prop.rotation.z = Math.sin(ud.walkPhase * 1.5) * 0.12;
          if (ud.role === 'merchant' && Math.random() < dt * 6) {
            addParticle(npc.position.clone().add(new THREE.Vector3(-0.22, 0.95, 0.08)), 0xffefaa, { size: 0.035, velocity: new THREE.Vector3(rand(-0.05,0.05), 0.25, rand(-0.05,0.05)), life: 0.45, drag: 0.96 });
          }
        }
        npc.lookAt(npc.position.x + Math.cos(ud.walkPhase) * 2.2, npc.position.y + 1.0, npc.position.z + Math.sin(ud.walkPhase * 0.72) * 2.2);
        if (Math.random() < dt * 2.2) {
          addParticle(npc.position.clone().add(new THREE.Vector3(0, 1.36, 0)), 0xfff2cc, { size: 0.035, velocity: new THREE.Vector3(0, 0.5, 0), life: 0.55, drag: 0.95 });
        }
      }
    }

    for (let decorIndex = 0; decorIndex < game.decorFX.length && decorIndex < 80; decorIndex++) {
      const fx = game.decorFX[decorIndex];
      if (fx.kind === 'beacon') {
        fx.group.rotation.y += dt * 0.22 * fx.speed;
        fx.core.position.y = fx.baseY + Math.sin(game.time * 1.4 * fx.speed + fx.phase) * 0.12;
        fx.core.rotation.y += dt * 1.15;
        fx.halo.rotation.z += dt * 0.6 * fx.speed;
        if (fx.halo.material.uniforms?.uOpacity) fx.halo.material.uniforms.uOpacity.value = 0.26 + (Math.sin(game.time * 2.6 + fx.phase) + 1) * 0.08;
        fx.light.intensity = 0.8 + (Math.sin(game.time * 2.3 + fx.phase) + 1) * 0.32;
      } else if (fx.kind === 'firefly') {
        fx.mesh.position.x = fx.base.x + Math.cos(game.time * fx.speed + fx.phase) * fx.radius;
        fx.mesh.position.y = fx.base.y + Math.sin(game.time * (fx.speed * 1.8) + fx.phase) * 0.3;
        fx.mesh.position.z = fx.base.z + Math.sin(game.time * (fx.speed * 0.9) + fx.phase) * fx.radius;
        fx.mesh.material.opacity = 0.2 + (Math.sin(game.time * 5.4 + fx.phase) + 1) * 0.3;
      }
    }
  }


  function spawnSkyEvent() {
    const streak = new THREE.Mesh(new THREE.PlaneGeometry(rand(10, 18), rand(0.4, 0.9)), makeGlowShaderMaterial(Math.random() > 0.5 ? 0x8fe9ff : 0xff9ae7, 0xffffff, { opacity: 0.34, speed: 2.0 }));
    streak.position.set(rand(-10, 150), rand(36, 72), rand(-95, -25));
    streak.rotation.z = rand(-0.7, -0.2);
    scene.add(streak);
    game.events.push({ kind: 'skyStreak', mesh: streak, velocity: new THREE.Vector3(rand(14, 22), rand(-1.2, 0.4), 0), life: rand(1.0, 1.8), spin: rand(-0.4, 0.4) });
  }

  function spawnMapEvent() {
    const eventType = Math.random();
    const pos = randomGroundPoint();
    if (eventType < 0.34) {
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.6, 1.2, 28), makeGlowShaderMaterial(0x8affd0, 0xc782ff, { opacity: 0.42, speed: 1.7 }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.copy(pos).add(new THREE.Vector3(0, 0.08, 0));
      world.add(ring);
      game.events.push({ kind: 'runePulse', mesh: ring, life: 1.6, scale: 1 });
    } else if (eventType < 0.67) {
      const geyser = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 1.0, 3.8, 18, 1, true), makeLavaShaderMaterial(0xff6325, 0xffdd7b, { opacity: 0.3, speed: 2.0 }));
      geyser.position.copy(pos).add(new THREE.Vector3(0, 2.0, 0));
      world.add(geyser);
      game.events.push({ kind: 'lavaGeyser', mesh: geyser, life: 1.2 });
      explode(pos.clone().add(new THREE.Vector3(0, 0.3, 0)), 0xff7b36, 10, 1.8, { size: 0.1, life: 0.8, gravity: 0.6, drag: 0.92, flicker: true });
    } else {
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 2.8, 9.5, 18, 1, true), makeGlowShaderMaterial(0x77ffda, 0xffffff, { opacity: 0.16, speed: 1.3 }));
      beam.position.copy(pos).add(new THREE.Vector3(0, 4.6, 0));
      world.add(beam);
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.8, 1.3, 28), makeGlowShaderMaterial(0x76ffe1, 0xffffff, { opacity: 0.34, speed: 1.6 }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.copy(pos).add(new THREE.Vector3(0, 0.08, 0));
      world.add(ring);
      game.events.push({ kind: 'tractorScan', mesh: beam, ring, life: 1.6 });
    }
  }

  function updateRandomEvents(dt) {
    game.skyEventTimer -= dt;
    game.mapEventTimer -= dt;
    if (game.skyEventTimer <= 0) {
      spawnSkyEvent();
      game.skyEventTimer = rand(4.0, 9.0);
    }
    if (game.mapEventTimer <= 0) {
      spawnMapEvent();
      game.mapEventTimer = rand(4.5, 8.5);
    }

    for (const event of [...game.events]) {
      event.life -= dt;
      if (event.kind === 'skyStreak') {
        event.mesh.position.addScaledVector(event.velocity, dt);
        event.mesh.rotation.z += event.spin * dt;
        event.mesh.material.opacity = Math.max(0, event.life * 0.32);
      } else if (event.kind === 'runePulse') {
        event.scale += dt * 2.6;
        event.mesh.scale.setScalar(event.scale);
        event.mesh.material.opacity = Math.max(0, event.life * 0.35);
      } else if (event.kind === 'lavaGeyser') {
        event.mesh.scale.y = 0.8 + Math.sin(game.time * 10.0) * 0.12;
        event.mesh.material.opacity = Math.max(0, event.life * 0.26);
        if (Math.random() < dt * 16) addParticle(event.mesh.position.clone().add(new THREE.Vector3(rand(-0.3, 0.3), rand(-1, 1), rand(-0.3, 0.3))), 0xff9247, { size: rand(0.04,0.1), velocity: new THREE.Vector3(rand(-0.3,0.3), rand(0.9,2.1), rand(-0.3,0.3)), life: 0.5, gravity: 1.0, drag: 0.94, flicker: true });
      } else if (event.kind === 'tractorScan') {
        event.mesh.material.opacity = Math.max(0, event.life * 0.12);
        event.ring.scale.setScalar(1 + (1.6 - event.life) * 1.2);
        event.ring.material.opacity = Math.max(0, event.life * 0.26);
      }
      if (event.life <= 0) {
        if (event.mesh) world.remove(event.mesh), scene.remove(event.mesh);
        if (event.ring) world.remove(event.ring);
        const idx = game.events.indexOf(event);
        if (idx >= 0) game.events.splice(idx, 1);
      }
    }
  }

  function updateCamera(dt) {
    if (game.cameraLerp < 1 && game.cameraTargetPos) {
      game.cameraLerp += dt * 0.28;
      const t = Math.min(1, game.cameraLerp);
      const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

      camera.position.lerpVectors(game.cameraStartPos, game.cameraTargetPos, eased);
      const newLook = game.cameraStartLook.clone().lerp(game.cameraTargetLook, eased);
      camera.lookAt(newLook);
      cameraLookAt.copy(newLook);
    } else {
      const swayX = Math.sin(game.time * 0.22) * 1.2;
      const swayY = Math.sin(game.time * 0.18 + 1.4) * 0.9;
      const shake = game.screenShake > 0 ? new THREE.Vector3(rand(-game.screenShake, game.screenShake), rand(-game.screenShake, game.screenShake), rand(-game.screenShake, game.screenShake)) : new THREE.Vector3();
      if (game.screenShake > 0) game.screenShake = Math.max(0, game.screenShake - dt * 1.4);
      camera.position.set(cameraBasePos.x + swayX + shake.x, cameraBasePos.y + swayY + shake.y, cameraBasePos.z + shake.z);
      camera.lookAt(cameraLookAt.x + swayX * 0.12, cameraLookAt.y, cameraLookAt.z + shake.z * 0.08);
    }
  }

  function update(dt) {
    if (game.paused || game.gameOver) return;
    dt *= game.speed;
    game.time += dt;

    if (game.waveActive) {
      game.spawnTimer -= dt;
      if (game.spawnIndex < currentWave.length && game.spawnTimer <= 0) {
        spawnEnemy();
        game.spawnTimer = Math.max(0.26, 0.7 - game.wave * 0.022);
      }
      if (game.spawnIndex >= currentWave.length && game.enemies.length === 0) {
        game.waveActive = false;
        const bounty = 40 + game.wave * 6;
        game.gold += bounty;
        showMessage(`Wave ${game.wave} crushed · +${bounty} gold`);
      }
    }

    updateAmbient(dt);
    updateRandomEvents(dt);
    updateEnemies(dt);
    updateTowers(dt);
    updateProjectiles(dt);
    updateParticles(dt);
    updateBeams(dt);
    updateFlashLights(dt);
    updateCamera(dt);
    updateHUD();
  }

  function renderBeams() {
    for (const beam of game.beams) {
      const alpha = beam.life / beam.maxLife;
      const material = new THREE.LineBasicMaterial({ color: beam.color, transparent: true, opacity: alpha * 0.9 });
      const geometry = new THREE.BufferGeometry().setFromPoints([beam.from, beam.to]);
      const line = new THREE.Line(geometry, material);
      world.add(line);
      beam.line = line;
    }
  }

  function cleanupBeams() {
    for (const beam of game.beams) {
      if (beam.line) {
        world.remove(beam.line);
        beam.line.geometry.dispose();
        beam.line.material.dispose();
        beam.line = null;
      }
    }
  }

  function animate() {
    const dt = Math.min(0.033, clock.getDelta());
    update(dt);
    renderBeams();
    renderer.render(scene, camera);
    cleanupBeams();
    requestAnimationFrame(animate);
  }

  function setPointer(event) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  }

  function pick(event, click = false) {
    setPointer(event);
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects(interactive, true);
    game.hoveredPad = null;

    if (hits.length) {
      for (const hit of hits) {
        let obj = hit.object;
        while (obj && !obj.userData.type && obj.parent) obj = obj.parent;
        if (!obj || !obj.userData.type) continue;

        if (obj.userData.type === 'pad') {
          const pad = obj.userData.ref;
          if (!pad.tower) {
            game.hoveredPad = pad;
            updatePlacementGhost(pad.group.position);
            if (click) {
              game.selectedTower = null;
              updateRangeIndicator();
              updateHUD();
              buildTower(pad, game.selectedBuild);
            }
            return;
          }
        }

        if (obj.userData.type === 'tower') {
          updatePlacementGhost(null);
          const tower = obj.userData.ref;
          if (click) {
            game.selectedTower = tower;
            updateRangeIndicator();
            updateHUD();
          }
          return;
        }
      }
    }

    if (buildSurface) {
      const groundHits = raycaster.intersectObject(buildSurface, false);
      if (groundHits.length) {
        const point = groundHits[0].point;
        const snapped = new THREE.Vector3(
          Math.round(point.x * 2) / 2,
          0,
          Math.round(point.z * 2) / 2
        );
        updatePlacementGhost(snapped);
        if (click) {
          game.selectedTower = null;
          updateRangeIndicator();
          updateHUD();
          buildTower(snapped, game.selectedBuild);
        }
        return;
      }
    }

    updatePlacementGhost(null);
    if (click) {
      game.selectedTower = null;
      updateRangeIndicator();
      updateHUD();
    }
  }


// ===== v18 systems expansion =====
ui.targetingControls = document.getElementById('targetingControls');
ui.routeControls = document.getElementById('routeControls');
ui.targetBtns = Array.from(document.querySelectorAll('.targetBtn'));
ui.routeBtns = Array.from(document.querySelectorAll('.routeBtn'));

Object.assign(game, {
  mines: [],
  fighters: [],
  bossNodes: [],
  secondLaneUnlocked: false,
  laneVisuals: [],
  sniperCone: null,
  terrainZones: []
});

Object.assign(towerDefs, {
  radar: { name: 'Radar Booster', baseType: 'storm', cost: 90, range: 4.5, fireRate: 1.3, damage: 0, projectileSpeed: 0, color: 0x3e83ff, glow: 0xa9deff, projectileColor: 0xdbf6ff, supportRange: 7.5, persona: 'A relay tower that boosts nearby towers and exposes cloaked enemies.' },
  mine: { name: 'Mine Thrower', baseType: 'bombard', cost: 120, range: 5.25, fireRate: 2.2, damage: 42, projectileSpeed: 0, color: 0xaa7b4f, glow: 0xffd68a, projectileColor: 0xffe0ab, splash: 4.4, persona: 'Throws proximity mines directly onto the lanes.' },
  glue: { name: 'Glue Sticker', baseType: 'alchemist', cost: 100, range: 4.75, fireRate: 0.78, damage: 9, projectileSpeed: 34, color: 0xe0ad2f, glow: 0xfff197, projectileColor: 0xffee7a, slow: 0.32, persona: 'Covers mobs in sticky resin and glues the lane shut.' },
  backthrow: { name: 'Backcaster', baseType: 'storm', cost: 130, range: 5.0, fireRate: 1.05, damage: 18, projectileSpeed: 40, color: 0x8d63ff, glow: 0xd7c9ff, projectileColor: 0xece4ff, knockback: 6.0, persona: 'Void pulses shove enemies back down the lane.' },
  flame: { name: 'Flame Blower', baseType: 'dragon', cost: 135, range: 3.35, fireRate: 0.22, damage: 8, projectileSpeed: 0, color: 0xff6d35, glow: 0xffb46f, projectileColor: 0xffd595, persona: 'Projects a short brutal cone of fire.' },
  barracks: { name: 'Lane Barracks', baseType: 'arrow', cost: 150, range: 4.75, fireRate: 2.8, damage: 12, projectileSpeed: 0, color: 0x53c98b, glow: 0xc3ffe1, projectileColor: 0xe6fff1, persona: 'Deploys fighters directly onto the lane to stall and slash.' }
});

Object.assign(enemyDefs, {
  shadeRunner: { name: 'Shade Runner', hp: 72, speed: 9.4, reward: 16, color: 0x8d73ff, emissive: 0x2d2168, size: 1.02, ability: 'cloak' },
  riftPriest: { name: 'Rift Priest', hp: 118, speed: 5.9, reward: 24, color: 0xa66df0, emissive: 0x3d1c6e, size: 1.24, ability: 'shield' },
  burrower: { name: 'Burrower', hp: 86, speed: 7.1, reward: 18, color: 0x8d6b4d, emissive: 0x3f2714, size: 1.08, ability: 'burrow' },
  healer: { name: 'Healer', hp: 96, speed: 5.8, reward: 20, color: 0x5fe3ae, emissive: 0x164e37, size: 1.1, ability: 'heal' },
  warden: { name: 'Warden', hp: 188, speed: 4.4, reward: 28, color: 0x7aacff, emissive: 0x20355a, size: 1.42, ability: 'fortify', phase: 'miniBoss' },
  colossus: { name: 'Rift Colossus', hp: 2200, speed: 2.4, reward: 260, color: 0xff935f, emissive: 0x612714, size: 2.6, ability: 'boss', phase: 'boss' }
});

const secondaryCurvePoints = curvePoints.map((p, i) => {
  const prev = curvePoints[Math.max(0, i - 1)];
  const next = curvePoints[Math.min(curvePoints.length - 1, i + 1)];
  const tangent = next.clone().sub(prev).setY(0).normalize();
  const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
  return p.clone().addScaledVector(normal, 8.5);
});
const secondaryPathCurve = new THREE.CatmullRomCurve3(secondaryCurvePoints, false, 'centripetal');
const secondaryPathLength = secondaryPathCurve.getLength();
function getCurveForLane(lane) { return lane === 1 ? secondaryPathCurve : pathCurve; }
function getLengthForLane(lane) { return lane === 1 ? secondaryPathLength : pathLength; }

const theoryLines = [
  'MKUltra was real.', 'COINTELPRO targeted activists.', 'Operation Northwoods was proposed.',
  'Tuskegee really happened.', 'Paperclip was real.', 'Snowden exposed mass surveillance.',
  'The Pentagon Papers proved deception.', 'Iran-Contra was real.', 'The Church Committee exposed abuses.',
  'Area 51 existed before admission.', 'The FBI spied on MLK.', 'Project Blue Book was real.'
];

function ensureTowerState(tower) {
  tower.targetMode = tower.targetMode || 'first';
  tower.route = tower.route || 'alpha';
  tower.routeLevel = tower.routeLevel || 0;
  tower.buffRangeBonus = tower.buffRangeBonus || 0;
  tower.buffFireRateBonus = tower.buffFireRateBonus || 0;
  tower.buffDamageBonus = tower.buffDamageBonus || 0;
}

function applyRouteUpgrade(t) {
  ensureTowerState(t);
  t.routeLevel += 1;
  if (t.route === 'alpha') {
    t.damage *= 1.22;
    if (t.splash) t.splash += 0.55;
    if (t.chain) t.chain += 1;
  } else if (t.route === 'beta') {
    t.fireRate *= 0.84;
    t.projectileSpeed = (t.projectileSpeed || 0) + 6;
    if (t.slow) t.slow = Math.min(0.85, t.slow + 0.06);
  } else {
    t.range += 0.65;
    if (t.pierce) t.pierce += 1;
    t.buffRangeBonus += 0.15;
  }
  if (t.type === 'sniper' && t.route === 'gamma') t.range += 1.2;
  if (t.type === 'bombard' && t.route === 'alpha') t.splash += 1.1;
  if (t.type === 'radar') t.supportRange = (t.supportRange || towerDefs.radar.supportRange) + 0.5;
  if (t.type === 'barracks') t.fighterDamageBonus = (t.fighterDamageBonus || 0) + 2;
}

function chooseTarget(tower) {
  const effRange = tower.range + (tower.buffRangeBonus || 0);
  const available = game.enemies.filter(enemy => !enemy.dead && !enemy.reached && !enemy.isCloaked && enemy.mesh.position.distanceTo(tower.mesh.position) <= effRange);
  if (!available.length) return null;
  if (tower.targetMode === 'last') available.sort((a, b) => a.distance - b.distance);
  else if (tower.targetMode === 'closest') available.sort((a, b) => a.mesh.position.distanceTo(tower.mesh.position) - b.mesh.position.distanceTo(tower.mesh.position));
  else if (tower.targetMode === 'strongest') available.sort((a, b) => b.hp - a.hp);
  else available.sort((a, b) => b.distance - a.distance);
  return available[0];
}

function buildSecondaryLaneVisuals() {
  function ribbon(curve, halfWidth, y, material) {
    const segments = 180, positions = [], normals = [], uvs = [], indices = [];
    for (let i = 0; i <= segments; i++) {
      const t = i / segments;
      const p = curve.getPointAt(t);
      const prev = curve.getPointAt(Math.max(0, t - 1 / segments));
      const next = curve.getPointAt(Math.min(1, t + 1 / segments));
      const tangent = next.clone().sub(prev).setY(0).normalize();
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
      const left = p.clone().addScaledVector(normal, halfWidth);
      const right = p.clone().addScaledVector(normal, -halfWidth);
      positions.push(left.x, y, left.z, right.x, y, right.z);
      normals.push(0,1,0,0,1,0);
      uvs.push(0, t * 9, 1, t * 9);
      if (i < segments) { const a = i * 2; indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    const mesh = new THREE.Mesh(geo, material);
    mesh.visible = false;
    mesh.receiveShadow = true;
    return mesh;
  }
  const shoulder = ribbon(secondaryPathCurve, 3.8, 0.04, new THREE.MeshStandardMaterial({ color: 0x57566a, roughness: 1, transparent: true, opacity: 0.8 }));
  const road = ribbon(secondaryPathCurve, 2.9, 0.11, new THREE.MeshStandardMaterial({ color: 0x8a89a7, roughness: 0.92, metalness: 0.05, transparent: true, opacity: 0.9 }));
  const glow = ribbon(secondaryPathCurve, 0.55, 0.125, new THREE.MeshStandardMaterial({ color: 0x7db8ff, emissive: 0x3668c1, emissiveIntensity: 0.3, transparent: true, opacity: 0.2 }));
  game.laneVisuals.push(shoulder, road, glow);
  world.add(shoulder, road, glow);
}

function unlockSecondLane() {
  if (game.secondLaneUnlocked) return;
  game.secondLaneUnlocked = true;
  for (const mesh of game.laneVisuals) mesh.visible = true;
  showMessage('Second lane breached open!');
}

function registerTerrainZones() {
  game.terrainZones = [
    { kind: 'swamp', x: 41, z: 43, radius: 9, slow: 0.58, color: 0x53744a },
    { kind: 'lava', x: 55, z: -8, radius: 8, burn: 14, color: 0xff7a39 },
    { kind: 'crystal', x: 106, z: 56, radius: 9, buff: 0.18, color: 0x7fd5ff },
    { kind: 'rift', x: 22, z: 63, radius: 8, pull: 0.85, color: 0x9f7dff }
  ];
  for (const zone of game.terrainZones) {
    const ring = new THREE.Mesh(new THREE.RingGeometry(zone.radius * 0.75, zone.radius, 48), new THREE.MeshBasicMaterial({ color: zone.color, transparent: true, opacity: 0.18, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(zone.x, 0.09, zone.z);
    world.add(ring);
    zone.visual = ring;
  }
}

const _origCreateTowerMesh = createTowerMesh;
createTowerMesh = function(type) {
  if (!['radar', 'mine', 'glue', 'backthrow', 'flame', 'barracks'].includes(type)) return _origCreateTowerMesh(type);
  const def = towerDefs[type];
  const group = new THREE.Group(), root = new THREE.Group(), turret = new THREE.Group(), fxAnchor = new THREE.Object3D(), animParts = [];
  group.add(root); root.add(turret); root.add(fxAnchor);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.85, 2.05, 0.9, 28), new THREE.MeshStandardMaterial({ color: 0x716451, roughness: 0.92 }));
  base.position.y = 0.45; root.add(base);
  const core = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.18, 1.0, 18), new THREE.MeshStandardMaterial({ color: def.color, emissive: def.glow, emissiveIntensity: 0.3, roughness: 0.42 }));
  core.position.y = 1.8; root.add(core);
  if (type === 'radar') {
    turret.position.y = 3.2;
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 1.4, 10), new THREE.MeshStandardMaterial({ color: 0xa9c5ff, metalness: 0.7, roughness: 0.3 }));
    mast.position.y = 0.45; turret.add(mast);
    const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.78, 0.35, 18), new THREE.MeshStandardMaterial({ color: 0x8fd8ff, emissive: 0x4db5ff, emissiveIntensity: 0.8, metalness: 0.4, roughness: 0.18 }));
    dish.rotation.z = -Math.PI / 2; dish.position.set(0.3, 0.95, 0); turret.add(dish);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.04, 8, 28), makeGlowShaderMaterial(0x94e8ff, 0xffffff, { opacity: 0.45, speed: 1.9 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 1.0; turret.add(ring);
    animParts.push({ mesh: turret, kind: 'spinY', speed: 1.2, phase: 0 });
    animParts.push({ mesh: ring, kind: 'spinY', speed: -2.1, phase: 0 });
    fxAnchor.position.set(0.6, 4.0, 0);
  } else if (type === 'mine') {
    turret.position.y = 3.05;
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.18, 0.28), new THREE.MeshStandardMaterial({ color: 0x8d6f49, roughness: 0.82 }));
    arm.position.x = 0.35; turret.add(arm);
    const cup = new THREE.Mesh(new THREE.SphereGeometry(0.35, 14, 14), new THREE.MeshStandardMaterial({ color: 0xd3af74, metalness: 0.2, roughness: 0.4 }));
    cup.position.set(0.95, 0.15, 0); turret.add(cup);
    animParts.push({ mesh: cup, kind: 'bob', speed: 1.45, phase: 0, baseY: 0.15 });
    fxAnchor.position.set(1.05, 3.2, 0);
  } else if (type === 'glue') {
    turret.position.y = 3.0;
    const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.65, 1.5, 14), new THREE.MeshStandardMaterial({ color: 0xf2cc58, emissive: 0xffea98, emissiveIntensity: 0.4, roughness: 0.32 }));
    turret.add(tank);
    const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 1.2, 10), new THREE.MeshStandardMaterial({ color: 0x6b624d, metalness: 0.55 }));
    nozzle.rotation.z = Math.PI / 2; nozzle.position.x = 0.85; turret.add(nozzle);
    fxAnchor.position.set(1.45, 3.0, 0);
  } else if (type === 'backthrow') {
    turret.position.y = 3.15;
    const prism = new THREE.Mesh(new THREE.OctahedronGeometry(0.52, 0), new THREE.MeshStandardMaterial({ color: 0xd6ceff, emissive: 0x9e7dff, emissiveIntensity: 1.2, metalness: 0.25, roughness: 0.12 }));
    turret.add(prism);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.84, 0.04, 8, 26), makeGlowShaderMaterial(0xbdadff, 0xffffff, { opacity: 0.5, speed: 2.0 }));
    ring.rotation.x = Math.PI / 2; turret.add(ring);
    animParts.push({ mesh: prism, kind: 'spinXYZ', speed: 1.15, phase: 0 });
    animParts.push({ mesh: ring, kind: 'spinY', speed: -1.7, phase: 0 });
    fxAnchor.position.set(0, 3.8, 0);
  } else if (type === 'flame') {
    turret.position.y = 3.0;
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 1.4, 12), new THREE.MeshStandardMaterial({ color: 0x704a3e, metalness: 0.35, roughness: 0.5 }));
    barrel.rotation.z = Math.PI / 2; barrel.position.x = 0.75; turret.add(barrel);
    const flamePilot = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 12), new THREE.MeshStandardMaterial({ color: 0xffd275, emissive: 0xff8f42, emissiveIntensity: 1.3 }));
    flamePilot.position.set(1.45, 0, 0); turret.add(flamePilot);
    fxAnchor.position.set(1.6, 3.0, 0);
  } else if (type === 'barracks') {
    const keep = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.05, 2.1, 10), new THREE.MeshStandardMaterial({ color: 0x567e64, roughness: 0.88 }));
    keep.position.y = 2.8; root.add(keep);
    const banner = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.78), new THREE.MeshStandardMaterial({ color: 0xcefbe0, emissive: 0x58d889, emissiveIntensity: 0.3, side: THREE.DoubleSide }));
    banner.position.set(0.86, 3.25, 0); banner.rotation.y = -Math.PI / 2; root.add(banner);
    animParts.push({ mesh: banner, kind: 'banner', speed: 2.2, phase: 0 });
    fxAnchor.position.set(0.3, 3.45, 0);
  }
  group.traverse(obj => { if (obj.isMesh) obj.castShadow = obj.receiveShadow = true; });
  return { group, turret, core, aura: null, fxAnchor, animParts };
};

const _origBuildScene = buildScene;
buildScene = function() {
  _origBuildScene();
  buildSecondaryLaneVisuals();
  registerTerrainZones();
};

const _origBuildNPCs = buildNPCs;
buildNPCs = function() {
  _origBuildNPCs();
  for (const npc of game.npcs) {
    npc.userData.talkCooldown = rand(2, 9);
    npc.userData.speechBubble = null;
  }
};

const _origCreateEnemy = createEnemy;
createEnemy = function(data) {
  const enemy = _origCreateEnemy(data);
  enemy.lane = data.lane || 0;
  enemy.ability = enemyDefs[data.type] ? enemyDefs[data.type].ability : null;
  enemy.abilityTimer = rand(0.8, 2.2);
  enemy.healTick = 0;
  enemy.shield = enemy.type === 'riftPriest' ? 60 + game.wave * 4 : 0;
  enemy.isCloaked = false;
  enemy.burrowPhase = 0;
  if (enemy.type === 'shadeRunner') enemy.hover = true;
  return enemy;
};

const _origMakeWave = makeWave;
makeWave = function(index) {
  const cycle = ((index - 1) % 12) + 1;
  const lap = Math.floor((index - 1) / 12);
  const scale = 1 + lap * 0.2 + (cycle - 1) * 0.06;
  const lineup = [];
  const add = function(type, count, lane, mult) {
    for (let i = 0; i < count; i++) lineup.push(Object.assign(makeEnemyDef(type, scale * (mult || 1)), { lane: lane || 0 }));
  };
  add('raider', 4 + cycle, 0, 1);
  add('scout', 2 + Math.floor(cycle * 0.6), 0, 1);
  if (cycle >= 3) add('knight', 1 + Math.floor(cycle * 0.45), 0, 1);
  if (cycle >= 4) add('rider', 1 + Math.floor(cycle * 0.35), 0, 1);
  if (cycle >= 5) add('cultist', 1 + Math.floor(cycle * 0.35), 0, 1);
  if (cycle >= 6) add('burrower', 1 + Math.floor(cycle * 0.25), 0, 1);
  if (cycle >= 7) add('healer', 1 + Math.floor(cycle * 0.2), 0, 1);
  if (cycle >= 8) add('riftPriest', 1 + Math.floor(cycle * 0.2), 0, 1);
  if (cycle >= 9) add('shadeRunner', 2 + Math.floor(cycle * 0.2), 0, 1);
  if (index >= 25) {
    if (!game.secondLaneUnlocked) unlockSecondLane();
    add('shadeRunner', 3 + Math.floor(cycle * 0.4), 1, 1);
    add('burrower', 2 + Math.floor(cycle * 0.25), 1, 1);
    add('healer', 1 + Math.floor(cycle * 0.2), 1, 1);
    add('riftPriest', 1 + Math.floor(cycle * 0.2), 1, 1);
    if (cycle >= 6) add('warden', 1, 1, 1);
  }
  if (cycle === 4) add('dreadKnight', 1, 0, 1.02);
  if (cycle === 7) add('pyreAbbot', 1, 0, 1.04);
  if (cycle === 10) add('batteringRam', 1, 0, 1.05);
  if (cycle === 12) {
    add('astralWarden', 1, 0, 1.08);
    if (index >= 25) add('colossus', 1, 1, 1.04);
  }
  lineup.sort(() => Math.random() - 0.5);
  return lineup;
};

const _origUpdateHUD = updateHUD;
updateHUD = function() {
  _origUpdateHUD();
  const t = game.selectedTower;
  if (ui.targetingControls) ui.targetingControls.style.display = t ? 'flex' : 'none';
  if (ui.routeControls) ui.routeControls.style.display = t ? 'flex' : 'none';
  if (t) {
    ensureTowerState(t);
    ui.targetBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.mode === t.targetMode));
    ui.routeBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.route === t.route));
    ui.towerDetails.innerHTML += `<br><strong>Route:</strong> ${t.route.toUpperCase()} (${t.routeLevel}/3)`;
  }
};

ui.targetBtns.forEach(btn => btn.addEventListener('click', function() {
  if (!game.selectedTower) return;
  ensureTowerState(game.selectedTower);
  game.selectedTower.targetMode = btn.dataset.mode;
  updateHUD();
}));

ui.routeBtns.forEach(btn => btn.addEventListener('click', function() {
  if (!game.selectedTower) return;
  ensureTowerState(game.selectedTower);
  game.selectedTower.route = btn.dataset.route;
  updateHUD();
}));

const _origUpgradeSelectedTower = upgradeSelectedTower;
upgradeSelectedTower = function() {
  if (!game.selectedTower) return;
  ensureTowerState(game.selectedTower);
  _origUpgradeSelectedTower();
  if (game.selectedTower) applyRouteUpgrade(game.selectedTower);
  updateHUD();
};

const _origBuildTower = buildTower;
buildTower = function(positionOrPad, type) {
  const tower = _origBuildTower(positionOrPad, type);
  if (tower) {
    ensureTowerState(tower);
    tower.supportRange = towerDefs[tower.displayType || tower.type] && towerDefs[tower.displayType || tower.type].supportRange ? towerDefs[tower.displayType || tower.type].supportRange : 0;
    tower.mineCooldown = 0;
    tower.spawnCooldown = 0;
  }
  return tower;
};

const _origUpdateRangeIndicator = updateRangeIndicator;
updateRangeIndicator = function() {
  _origUpdateRangeIndicator();
  if (!game.sniperCone) {
    const geo = new THREE.CircleGeometry(1, 48, -Math.PI / 6, Math.PI / 3);
    const mat = new THREE.MeshBasicMaterial({ color: 0xaedcff, transparent: true, opacity: 0.14, side: THREE.DoubleSide, depthWrite: false });
    game.sniperCone = new THREE.Mesh(geo, mat);
    game.sniperCone.rotation.x = -Math.PI / 2;
    game.sniperCone.visible = false;
    world.add(game.sniperCone);
  }
  const t = game.selectedTower;
  if (t && (t.displayType === 'sniper' || t.type === 'sniper')) {
    const effRange = t.range + (t.buffRangeBonus || 0);
    game.sniperCone.visible = true;
    game.sniperCone.position.set(t.mesh.position.x, 0.08, t.mesh.position.z);
    game.sniperCone.scale.set(effRange, effRange, 1);
    if (t.turret) game.sniperCone.rotation.z = -t.turret.rotation.y;
  } else {
    game.sniperCone.visible = false;
  }
};

const _origApplyDamage = applyDamage;
applyDamage = function(enemy, amount, tower) {
  if (enemy.shield && enemy.shield > 0) {
    const absorbed = Math.min(enemy.shield, amount * 0.75);
    enemy.shield -= absorbed;
    amount -= absorbed;
    if (amount <= 0.1) return;
  }
  _origApplyDamage(enemy, amount * (1 + ((tower && tower.buffDamageBonus) || 0)), tower);
};

const _origHitProjectile = hitProjectile;
hitProjectile = function(projectile, target) {
  if (projectile.type === 'glue') {
    target.slowFactor = Math.min(target.slowFactor, 0.18);
    target.slowTimer = Math.max(target.slowTimer, 2.8 + projectile.tower.level * 0.35);
    _origApplyDamage(target, projectile.damage, projectile.tower);
    explode(target.mesh.position.clone().add(new THREE.Vector3(0,1,0)), 0xffe46a, 16, 1.6, { size: rand(0.06,0.16), life: 0.28, gravity: 0.2, drag: 0.93 });
    projectile.dead = true;
    return;
  }
  if (projectile.type === 'backthrow') {
    _origApplyDamage(target, projectile.damage, projectile.tower);
    target.distance = Math.max(0, target.distance - ((projectile.tower.knockback || 6) + projectile.tower.level));
    target.stunTimer = Math.max(target.stunTimer, 0.16 + projectile.tower.level * 0.04);
    explode(target.mesh.position.clone().add(new THREE.Vector3(0,1,0)), 0xd7c8ff, 20, 1.6, { size: rand(0.07,0.16), life: 0.3, gravity: 0.1, drag: 0.92 });
    projectile.dead = true;
    return;
  }
  _origHitProjectile(projectile, target);
};

const _origMakeProjectile = makeProjectile;
makeProjectile = function(tower, target) {
  if (tower.type === 'glue' || tower.type === 'backthrow') {
    const origin = tower.fxAnchor ? tower.fxAnchor.getWorldPosition(new THREE.Vector3()) : tower.mesh.position.clone().add(new THREE.Vector3(0, 3, 0));
    const mesh = new THREE.Mesh(
      tower.type === 'glue' ? new THREE.SphereGeometry(0.16, 12, 12) : new THREE.OctahedronGeometry(0.2, 0),
      new THREE.MeshStandardMaterial({ color: tower.type === 'glue' ? 0xffee7a : 0xece4ff, emissive: tower.type === 'glue' ? 0xffcf49 : 0xb092ff, emissiveIntensity: 1.0 })
    );
    mesh.position.copy(origin);
    world.add(mesh);
    game.projectiles.push({ type: tower.type, mesh, target, tower, speed: tower.projectileSpeed || 34, damage: tower.damage, splash: 0, pierce: 0, chain: 0, dead: false });
    return;
  }
  _origMakeProjectile(tower, target);
};

const _origUpdateTowers = updateTowers;
updateTowers = function(dt) {
  for (const tower of game.towers) {
    ensureTowerState(tower);
    tower.buffRangeBonus = 0;
    tower.buffFireRateBonus = 0;
    tower.buffDamageBonus = 0;
  }

  for (const tower of game.towers) {
    if (tower.type === 'radar') {
      const radius = (tower.supportRange || towerDefs.radar.supportRange) + tower.level * 0.4;
      for (const other of game.towers) {
        if (other !== tower && other.mesh.position.distanceTo(tower.mesh.position) <= radius) {
          other.buffRangeBonus = Math.max(other.buffRangeBonus, 0.85 + tower.level * 0.18);
          other.buffFireRateBonus = Math.max(other.buffFireRateBonus, 0.08 + tower.level * 0.02);
        }
      }
    }
    for (const zone of game.terrainZones) {
      if (zone.kind === 'crystal' && tower.mesh.position.distanceTo(new THREE.Vector3(zone.x, 0, zone.z)) <= zone.radius) {
        tower.buffDamageBonus = Math.max(tower.buffDamageBonus, zone.buff);
      }
    }
  }

  _origUpdateTowers(dt);

  for (const tower of game.towers) {
    const target = chooseTarget(tower);
    if (tower.type === 'mine') {
      tower.mineCooldown -= dt;
      if (tower.mineCooldown <= 0 && target) {
        tower.mineCooldown = Math.max(0.8, 3.3 - tower.level * 0.28);
        const pos = target.mesh.position.clone(); pos.y = 0.12;
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.18, 10), new THREE.MeshStandardMaterial({ color: 0x413225, emissive: 0xe2b06a, emissiveIntensity: 0.35, metalness: 0.4 }));
        mesh.position.copy(pos);
        world.add(mesh);
        game.mines.push({ mesh, tower, radius: 2.6 + tower.level * 0.25 + tower.routeLevel * 0.1, damage: 42 + tower.level * 14, life: 8 });
      }
    } else if (tower.type === 'flame') {
      if (target && tower.cooldown <= 0) {
        tower.cooldown = tower.fireRate;
        const origin = tower.fxAnchor.getWorldPosition(new THREE.Vector3());
        if (tower.turret) tower.turret.lookAt(target.mesh.position.clone().add(new THREE.Vector3(0, 1, 0)));
        for (const enemy of game.enemies) {
          if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= 2.7 + tower.level * 0.18) {
            _origApplyDamage(enemy, tower.damage, tower);
            enemy.burnTimer = Math.max(enemy.burnTimer, 2.2);
            enemy.burnDamage = Math.max(enemy.burnDamage || 0, tower.damage * 0.55);
          }
        }
        for (let i = 0; i < 8; i++) addParticle(origin.clone(), 0xffae63, { size: rand(0.07,0.15), velocity: new THREE.Vector3(rand(1.0,2.7), rand(-0.15,0.8), rand(-0.7,0.7)).applyAxisAngle(new THREE.Vector3(0,1,0), tower.turret ? tower.turret.rotation.y : 0), life: 0.28, drag: 0.88, flicker: true });
      }
    } else if (tower.type === 'barracks') {
      tower.spawnCooldown -= dt;
      if (tower.spawnCooldown <= 0) {
        tower.spawnCooldown = Math.max(2.2, 5.0 - tower.level * 0.4);
        const group = new THREE.Group();
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.48, 4, 8), new THREE.MeshStandardMaterial({ color: 0xddfff0, roughness: 0.72 }));
        group.add(body);
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.46, 0.05), new THREE.MeshStandardMaterial({ color: 0xd8eaff, metalness: 0.62, roughness: 0.25 }));
        blade.position.set(0.2, 0.18, 0); group.add(blade);
        group.position.copy(tower.mesh.position).add(new THREE.Vector3(rand(-0.8, 0.8), 0, rand(-0.8, 0.8)));
        world.add(group);
        game.fighters.push({ mesh: group, tower, damage: 10 + tower.level * 3 + (tower.fighterDamageBonus || 0), speed: 8.5, life: 9.2, cooldown: 0 });
      }
    }
  }

  for (const mine of [...game.mines]) {
    mine.life -= dt;
    mine.mesh.rotation.y += dt * 2.2;
    let detonated = false;
    for (const enemy of game.enemies) {
      if (!enemy.dead && enemy.mesh.position.distanceTo(mine.mesh.position) <= mine.radius) {
        for (const hit of game.enemies) {
          if (!hit.dead && hit.mesh.position.distanceTo(mine.mesh.position) <= mine.radius + 0.6) _origApplyDamage(hit, mine.damage * (hit === enemy ? 1 : 0.7), mine.tower);
        }
        explode(mine.mesh.position.clone().add(new THREE.Vector3(0,0.15,0)), 0xffc980, 26, 2.3, { size: rand(0.07,0.2), life: 0.4, gravity: 0.4, drag: 0.92 });
        detonated = true;
        break;
      }
    }
    if (detonated || mine.life <= 0) {
      world.remove(mine.mesh);
      game.mines.splice(game.mines.indexOf(mine), 1);
    }
  }

  for (const fighter of [...game.fighters]) {
    fighter.life -= dt;
    fighter.cooldown -= dt;
    const nearby = game.enemies.filter(e => !e.dead && e.mesh.position.distanceTo(fighter.mesh.position) <= 6.2).sort((a, b) => a.mesh.position.distanceTo(fighter.mesh.position) - b.mesh.position.distanceTo(fighter.mesh.position));
    if (nearby[0]) {
      const target = nearby[0];
      const dir = target.mesh.position.clone().sub(fighter.mesh.position); dir.y = 0;
      const dist = dir.length();
      if (dist > 1.15) {
        dir.normalize();
        fighter.mesh.position.addScaledVector(dir, fighter.speed * dt);
        fighter.mesh.lookAt(target.mesh.position.x, fighter.mesh.position.y, target.mesh.position.z);
      } else if (fighter.cooldown <= 0) {
        fighter.cooldown = 0.52;
        _origApplyDamage(target, fighter.damage, fighter.tower);
      }
    }
    fighter.mesh.position.y = Math.abs(Math.sin(game.time * 8 + fighter.mesh.position.x * 0.1)) * 0.06;
    if (fighter.life <= 0) {
      world.remove(fighter.mesh);
      game.fighters.splice(game.fighters.indexOf(fighter), 1);
    }
  }
};

const _origUpdateAmbient = updateAmbient;
updateAmbient = function(dt) {
  _origUpdateAmbient(dt);
  for (const npc of game.npcs) {
    const ud = npc.userData;
    if (!ud) continue;
    ud.talkCooldown -= dt;
    if (ud.talkCooldown <= 0) {
      ud.talkCooldown = rand(5, 11);
      if (ud.speechBubble) npc.remove(ud.speechBubble);
      ud.speechBubble = makeSpeechBubbleSprite(theoryLines[Math.floor(Math.random() * theoryLines.length)]);
      ud.speechBubble.position.set(0, 2.3, 0);
      npc.add(ud.speechBubble);
    }
    if (ud.speechBubble) ud.speechBubble.material.rotation = Math.sin(game.time * 0.8 + npc.position.x * 0.07) * 0.02;
  }
};

updateEnemies = function(dt) {
  for (const enemy of [...game.enemies]) {
    enemy.anim += dt * 8;
    if (enemy.slowTimer > 0) { enemy.slowTimer -= dt; if (enemy.slowTimer <= 0) enemy.slowFactor = 1; }
    if (enemy.stunTimer > 0) enemy.stunTimer -= dt;
    if (enemy.burnTimer > 0) { enemy.burnTimer -= dt; enemy.hp -= (enemy.burnDamage || 0) * dt; }
    if (enemy.poisonTimer > 0) { enemy.poisonTimer -= dt; enemy.hp -= (enemy.poisonDamage || 0) * dt; }
    if (enemy.hp <= 0 && !enemy.dead) { enemy.dead = true; game.gold += enemy.reward; }

    enemy.abilityTimer -= dt;
    if (enemy.ability === 'cloak') {
      enemy.isCloaked = Math.sin(game.time * 3 + enemy.anim) > 0.6;
      enemy.mesh.traverse(obj => { if (obj.material && obj.material.opacity !== undefined) { obj.material.transparent = enemy.isCloaked; obj.material.opacity = enemy.isCloaked ? 0.28 : 1; } });
    } else if (enemy.ability === 'shield' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 6.2;
      enemy.shield = Math.max(enemy.shield, 80 + game.wave * 4);
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xc7b0ff, 1.6, 10, 0.18);
    } else if (enemy.ability === 'heal') {
      enemy.healTick += dt;
      if (enemy.healTick >= 1.2) {
        enemy.healTick = 0;
        for (const other of game.enemies) {
          if (!other.dead && other !== enemy && other.mesh.position.distanceTo(enemy.mesh.position) <= 5.4) other.hp = Math.min(other.maxHp, other.hp + 18 + game.wave);
        }
        addParticle(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.3, 0)), 0x87ffc2, { size: 0.1, velocity: new THREE.Vector3(0, 0.6, 0), life: 0.4, drag: 0.94 });
      }
    } else if (enemy.ability === 'burrow') {
      enemy.burrowPhase += dt;
    } else if (enemy.ability === 'fortify' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 7.0;
      for (const other of game.enemies) {
        if (!other.dead && other.mesh.position.distanceTo(enemy.mesh.position) <= 6.5) other.shield = Math.max(other.shield || 0, 40);
      }
    } else if (enemy.ability === 'boss' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 8.0;
      if (game.bossNodes.length < 2) {
        const node = new THREE.Mesh(new THREE.OctahedronGeometry(0.58, 0), new THREE.MeshStandardMaterial({ color: 0xf1e8ff, emissive: 0xa27cff, emissiveIntensity: 1.0, metalness: 0.3, roughness: 0.16 }));
        node.position.copy(enemy.mesh.position).add(new THREE.Vector3(rand(-4,4), 1.2, rand(-4,4)));
        world.add(node);
        game.bossNodes.push({ mesh: node, hp: 180 + game.wave * 5, owner: enemy, spin: rand(0.8, 1.6) });
      }
      const summonType = Math.random() > 0.5 ? 'shadeRunner' : 'riftPriest';
      const def = makeEnemyDef(summonType, 1 + game.wave * 0.01);
      def.lane = enemy.lane || 1;
      def.wasSummoned = true;
      createEnemy(def);
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.8, 0)), 0xffa372, 2.2, 16, 0.2);
    }

    for (const zone of game.terrainZones) {
      const distZone = Math.hypot(enemy.mesh.position.x - zone.x, enemy.mesh.position.z - zone.z);
      if (distZone <= zone.radius) {
        if (zone.kind === 'swamp') {
          enemy.slowFactor = Math.min(enemy.slowFactor, zone.slow);
          enemy.slowTimer = Math.max(enemy.slowTimer, 0.3);
        } else if (zone.kind === 'lava') {
          enemy.hp -= zone.burn * dt;
        } else if (zone.kind === 'rift') {
          enemy.distance = Math.max(0, enemy.distance - zone.pull * dt);
        }
      }
    }

    enemy.distance += enemy.speed * enemy.slowFactor * (enemy.stunTimer > 0 ? 0 : 1) * dt;
    if (enemy.ability === 'burrow' && Math.sin(enemy.burrowPhase * 2.6) > 0.82) enemy.distance += 8 * dt;
    const laneLength = getLengthForLane(enemy.lane || 0);
    const curve = getCurveForLane(enemy.lane || 0);
    const t = THREE.MathUtils.clamp(enemy.distance / laneLength, 0, 1);
    const point = curve.getPointAt(t);
    const look = curve.getPointAt(Math.min(0.999, t + 0.002));
    enemy.mesh.position.set(point.x, 0, point.z);
    const bob = Math.sin(enemy.anim * 1.8) * (enemy.hover ? 0.22 : 0.09);
    const funnyTilt = Math.sin(enemy.anim * 2.4) * (enemy.phase === 'boss' ? 0.18 : 0.07);
    enemy.mesh.position.y = (enemy.hover ? 0.52 : 0) + bob + (enemy.ability === 'burrow' ? -Math.abs(Math.sin(enemy.burrowPhase * 2.6)) * 0.35 : 0);
    enemy.mesh.lookAt(look.x, 0.2 + funnyTilt * 0.5, look.z);
    enemy.mesh.rotation.z = funnyTilt * 0.6;
    if (enemy.walkers) enemy.walkers.forEach((part, i) => { part.rotation.x = Math.sin(enemy.anim * 1.6 + i * 1.1) * (0.65 + (enemy.phase === 'miniBoss' ? 0.3 : 0)); part.position.y = Math.sin(enemy.anim * 2.1 + i) * 0.08; });
    if (enemy.swayers) enemy.swayers.forEach((part, i) => { part.rotation.y = Math.sin(enemy.anim * 1.1 + i * 0.7) * 0.38; if (enemy.phase === 'boss') { part.rotation.z += dt * 0.28; part.rotation.x = Math.sin(enemy.anim * 1.9) * 0.25; } });
    if (enemy.aura) { enemy.aura.scale.setScalar(0.92 + Math.sin(game.time * 4.2 + enemy.anim) * 0.14); enemy.aura.rotation.z += dt * (0.55 + (enemy.phase === 'boss' ? 0.4 : 0)); }
    enemy.healthFg.scale.x = Math.max(0.01, enemy.hp / enemy.maxHp);
    enemy.healthFg.position.x = -((1 - enemy.hp / enemy.maxHp) * enemy.healthWidth) / 2;

    if (t >= 1) {
      enemy.reached = true;
      game.lives -= enemy.phase === 'boss' ? 8 : enemy.phase === 'miniBoss' ? 4 : ['batteringRam','warWagon','plagueCart'].includes(enemy.type) ? 3 : enemy.type === 'brute' ? 3 : enemy.type === 'knight' ? 2 : 1;
      removeEnemy(enemy);
      game.screenShake = Math.max(game.screenShake, 0.18);
      showMessage('The gate is hit!');
      if (game.lives <= 0) { game.lives = 0; game.gameOver = true; showMessage('Blackwall has fallen'); }
    } else if (enemy.dead) {
      removeEnemy(enemy);
    }

    if (enemy.hp <= enemy.maxHp * 0.45 && !enemy.enraged) {
      enemy.enraged = true;
      enemy.speed *= 1.18;
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xff6b6b, 1.2, 9, 0.16);
    }
  }

  for (const node of [...game.bossNodes]) {
    node.mesh.rotation.y += dt * node.spin;
    const towersNear = game.towers.filter(t => t.mesh.position.distanceTo(node.mesh.position) <= 4.6);
    if (towersNear.length) node.hp -= dt * 32;
    if (!node.owner || node.owner.dead) node.hp = 0;
    if (node.hp <= 0) {
      world.remove(node.mesh);
      game.bossNodes.splice(game.bossNodes.indexOf(node), 1);
    }
  }
};


// ===== v19 balance, tuning, and polish pass =====
const v19SupportTypes = new Set(['radar', 'mine', 'glue', 'backthrow', 'flame', 'barracks']);
const v19EliteTypes = new Set(['dreadKnight', 'pyreAbbot', 'batteringRam', 'astralWarden', 'warden', 'colossus']);

game.gold = Math.max(game.gold, 300);
game.lives = Math.max(game.lives, 30);
game.balanceNotes = 'v19 tuned economy, enemy pacing, support towers, terrain, bosses, and route upgrades';

Object.assign(towerDefs.arrow, { cost: 50, damage: 15, range: 4.9, fireRate: 0.44 });
Object.assign(towerDefs.ballista, { cost: 90, damage: 50, range: 6.1, fireRate: 1.08 });
Object.assign(towerDefs.bombard, { cost: 135, damage: 40, splash: 6.4, fireRate: 1.72 });
Object.assign(towerDefs.frost, { cost: 105, damage: 12, slow: 0.42, fireRate: 0.92 });
Object.assign(towerDefs.sunfire, { cost: 150, damage: 62, fireRate: 1.22 });
Object.assign(towerDefs.storm, { cost: 155, damage: 26, chain: 2, fireRate: 1.02 });
Object.assign(towerDefs.alchemist, { cost: 120, damage: 20, splash: 4.6, fireRate: 0.82 });
Object.assign(towerDefs.dragon, { cost: 180, damage: 49, splash: 5.2, fireRate: 1.12 });
Object.assign(towerDefs.sniper, { cost: 165, damage: 92, range: 9.2, fireRate: 2.08 });
Object.assign(towerDefs.turret, { cost: 130, damage: 8, range: 4.8, fireRate: 0.26 });
Object.assign(towerDefs.hawk, { cost: 150, damage: 26, range: 5.8, fireRate: 0.98 });
Object.assign(towerDefs.radar, { cost: 85, supportRange: 8.2, range: 0.1 });
Object.assign(towerDefs.mine, { cost: 115, damage: 36, splash: 4.8, range: 5.6 });
Object.assign(towerDefs.glue, { cost: 95, damage: 7, slow: 0.36, fireRate: 0.9 });
Object.assign(towerDefs.backthrow, { cost: 125, damage: 14, knockback: 4.2, fireRate: 1.24 });
Object.assign(towerDefs.flame, { cost: 125, damage: 7, range: 3.25, fireRate: 0.18 });
Object.assign(towerDefs.barracks, { cost: 140, damage: 11, range: 4.6, fireRate: 3.1 });

Object.assign(enemyDefs.raider, { hp: 52, reward: 11 });
Object.assign(enemyDefs.scout, { hp: 39, reward: 10 });
Object.assign(enemyDefs.knight, { hp: 118, reward: 19 });
Object.assign(enemyDefs.rider, { hp: 84, reward: 15 });
Object.assign(enemyDefs.cultist, { hp: 96, reward: 17 });
Object.assign(enemyDefs.brute, { hp: 220, reward: 30 });
Object.assign(enemyDefs.warWagon, { hp: 195, reward: 26 });
Object.assign(enemyDefs.plagueCart, { hp: 205, reward: 28 });
Object.assign(enemyDefs.dreadKnight, { hp: 620, reward: 100 });
Object.assign(enemyDefs.pyreAbbot, { hp: 670, reward: 105 });
Object.assign(enemyDefs.batteringRam, { hp: 840, reward: 115 });
Object.assign(enemyDefs.astralWarden, { hp: 1400, reward: 205 });
Object.assign(enemyDefs.shadeRunner, { hp: 58, speed: 8.6, reward: 17 });
Object.assign(enemyDefs.riftPriest, { hp: 102, speed: 5.55, reward: 25 });
Object.assign(enemyDefs.burrower, { hp: 72, speed: 6.65, reward: 19 });
Object.assign(enemyDefs.healer, { hp: 88, speed: 5.4, reward: 22 });
Object.assign(enemyDefs.warden, { hp: 165, speed: 4.1, reward: 34 });
Object.assign(enemyDefs.colossus, { hp: 1850, speed: 2.25, reward: 300 });

getUpgradeCost = function(tower) {
  ensureTowerState(tower);
  return Math.round(tower.baseCost * (0.66 + tower.level * 0.35 + tower.routeLevel * 0.12));
};

applyRouteUpgrade = function(t) {
  ensureTowerState(t);
  if (t.routeLevel >= 3) return;
  t.routeLocked = true;
  t.routeLevel += 1;
  if (t.route === 'alpha') {
    t.damage *= 1.1;
    if (t.splash) t.splash += 0.35;
    if (t.chain && t.routeLevel === 3) t.chain += 1;
  } else if (t.route === 'beta') {
    t.fireRate *= 0.94;
    t.projectileSpeed = (t.projectileSpeed || 0) + 3.5;
    if (t.slow) t.slow = Math.min(0.72, t.slow + 0.035);
  } else {
    t.range += 0.35;
    if (t.pierce && t.routeLevel >= 2) t.pierce += 1;
    t.buffRangeBonus = (t.buffRangeBonus || 0) + 0.08;
  }
  if (t.type === 'sniper' && t.route === 'gamma') t.range += 0.45;
  if (t.type === 'bombard' && t.route === 'alpha') t.splash += 0.45;
  if (t.type === 'radar') t.supportRange = (t.supportRange || towerDefs.radar.supportRange) + 0.35;
  if (t.type === 'barracks') t.fighterDamageBonus = (t.fighterDamageBonus || 0) + 1.25;
  if (t.type === 'backthrow' && t.route === 'gamma') t.knockback = (t.knockback || towerDefs.backthrow.knockback) + 0.4;
};

ui.routeBtns.forEach(btn => btn.addEventListener('click', function(ev) {
  if (game.selectedTower && game.selectedTower.routeLocked && game.selectedTower.route !== btn.dataset.route) {
    ev.preventDefault();
    ev.stopImmediatePropagation();
    showMessage('Route locked after first route upgrade');
    updateHUD();
  }
}, true));

chooseTarget = function(tower) {
  ensureTowerState(tower);
  const effRange = Math.max(0, tower.range + (tower.buffRangeBonus || 0));
  const available = game.enemies.filter(enemy => {
    if (enemy.dead || enemy.reached) return false;
    if (enemy.isCloaked && !(enemy.revealedTimer > 0) && tower.type !== 'radar') return false;
    return enemy.mesh.position.distanceTo(tower.mesh.position) <= effRange;
  });
  if (!available.length) return null;
  if (tower.targetMode === 'last') available.sort((a, b) => a.distance - b.distance);
  else if (tower.targetMode === 'closest') available.sort((a, b) => a.mesh.position.distanceTo(tower.mesh.position) - b.mesh.position.distanceTo(tower.mesh.position));
  else if (tower.targetMode === 'strongest') available.sort((a, b) => (b.hp + (b.shield || 0)) - (a.hp + (a.shield || 0)));
  else available.sort((a, b) => b.distance - a.distance);
  return available[0];
};

makeWave = function(index) {
  const cycle = ((index - 1) % 12) + 1;
  const lap = Math.floor((index - 1) / 12);
  const scale = 1 + lap * 0.16 + (cycle - 1) * 0.043;
  const lineup = [];
  const add = (type, count, lane = 0, mult = 1) => {
    for (let i = 0; i < count; i++) lineup.push(Object.assign(makeEnemyDef(type, scale * mult), { lane }));
  };

  add('raider', 4 + Math.ceil(cycle * 0.85));
  if (cycle >= 2) add('scout', 2 + Math.floor(cycle * 0.42));
  if (cycle >= 3) add('knight', 1 + Math.floor(cycle * 0.32));
  if (cycle >= 4) add('rider', 1 + Math.floor(cycle * 0.26));
  if (cycle >= 5) add('cultist', 1 + Math.floor(cycle * 0.25));
  if (cycle >= 6) add('burrower', 1 + Math.floor(cycle * 0.16));
  if (cycle >= 7 && index >= 10) add('healer', 1);
  if (cycle >= 8 && index >= 14) add('riftPriest', 1);
  if (cycle >= 9) add('shadeRunner', 1 + Math.floor(cycle * 0.12));

  if (index >= 25) {
    if (!game.secondLaneUnlocked) unlockSecondLane();
    const secondScale = Math.max(0.82, scale * 0.9);
    add('shadeRunner', 2 + Math.floor(cycle * 0.22), 1, secondScale / scale);
    add('burrower', 1 + Math.floor(cycle * 0.16), 1, secondScale / scale);
    if (cycle >= 5) add('healer', 1, 1, secondScale / scale);
    if (cycle >= 7) add('riftPriest', 1, 1, secondScale / scale);
    if (cycle >= 10) add('warden', 1, 1, 0.92);
  }

  if (cycle === 4) add('dreadKnight', 1, 0, 0.96);
  if (cycle === 7) add('pyreAbbot', 1, 0, 0.98);
  if (cycle === 10) add('batteringRam', 1, 0, 1.0);
  if (cycle === 12) {
    add('astralWarden', 1, 0, 1.0);
    if (index >= 36) add('colossus', 1, 1, 0.92);
  }
  lineup.sort((a, b) => (a.lane || 0) - (b.lane || 0) || Math.random() - 0.5);
  return lineup;
};

const v19CreateEnemyPrev = createEnemy;
createEnemy = function(data) {
  const e = v19CreateEnemyPrev(data);
  e.abilityTimer = rand(2.2, 4.4);
  e.healTick = rand(0, 1.2);
  e.shield = Math.min(e.shield || 0, 42 + game.wave * 2);
  e.revealedTimer = 0;
  if (e.type === 'colossus') { e.bossPhase = 1; e.abilityTimer = 5.5; }
  if (e.type === 'shadeRunner') e.mesh.traverse(obj => { if (obj.material && obj.material.opacity !== undefined) obj.material.opacity = 0.9; });
  return e;
};

applyDamage = function(enemy, amount, tower) {
  if (!enemy || enemy.dead) return;
  if (enemy.shield && enemy.shield > 0) {
    const absorbed = Math.min(enemy.shield, amount * 0.58);
    enemy.shield -= absorbed;
    amount -= absorbed;
    if (Math.random() < 0.35) addParticle(enemy.mesh.position.clone().add(new THREE.Vector3(0, enemy.size * 1.35, 0)), 0xbfd7ff, { size: 0.06, velocity: new THREE.Vector3(rand(-0.25,0.25), rand(0.35,0.9), rand(-0.25,0.25)), life: 0.24, drag: 0.92 });
    if (amount <= 0.1) return;
  }
  _origApplyDamage(enemy, amount * (1 + ((tower && tower.buffDamageBonus) || 0)), tower);
};

const v19MakeProjectilePrev = makeProjectile;
makeProjectile = function(tower, target) {
  if (tower && ['radar', 'mine', 'flame', 'barracks'].includes(tower.type)) return null;
  return v19MakeProjectilePrev(tower, target);
};

hitProjectile = function(projectile, target) {
  if (projectile.type === 'glue') {
    applyDamage(target, projectile.damage, projectile.tower);
    target.slowFactor = Math.min(target.slowFactor, 0.28);
    target.slowTimer = Math.max(target.slowTimer, 2.2 + projectile.tower.level * 0.22 + projectile.tower.routeLevel * 0.12);
    explode(target.mesh.position.clone().add(new THREE.Vector3(0,1,0)), 0xffe46a, 13, 1.35, { size: rand(0.05,0.13), life: 0.24, gravity: 0.15, drag: 0.93 });
    projectile.dead = true;
    return;
  }
  if (projectile.type === 'backthrow') {
    applyDamage(target, projectile.damage, projectile.tower);
    const shove = Math.min(7, (projectile.tower.knockback || towerDefs.backthrow.knockback) + projectile.tower.level * 0.38 + projectile.tower.routeLevel * 0.28);
    target.distance = Math.max(0, target.distance - shove);
    target.stunTimer = Math.max(target.stunTimer, 0.12 + projectile.tower.level * 0.025);
    explode(target.mesh.position.clone().add(new THREE.Vector3(0,1,0)), 0xd7c8ff, 16, 1.4, { size: rand(0.06,0.14), life: 0.26, gravity: 0.1, drag: 0.92 });
    projectile.dead = true;
    return;
  }
  _origHitProjectile(projectile, target);
};

updateTowers = function(dt) {
  for (const tower of game.towers) {
    ensureTowerState(tower);
    tower.buffRangeBonus = 0;
    tower.buffFireRateBonus = 0;
    tower.buffDamageBonus = 0;
  }

  for (const tower of game.towers) {
    if (tower.type === 'radar') {
      const radius = (tower.supportRange || towerDefs.radar.supportRange) + tower.level * 0.28 + tower.routeLevel * 0.18;
      for (const other of game.towers) {
        if (other !== tower && other.mesh.position.distanceTo(tower.mesh.position) <= radius) {
          other.buffRangeBonus = Math.max(other.buffRangeBonus, 0.45 + tower.level * 0.11);
          other.buffFireRateBonus = Math.max(other.buffFireRateBonus, 0.045 + tower.level * 0.012);
        }
      }
      for (const enemy of game.enemies) {
        if (!enemy.dead && enemy.mesh.position.distanceTo(tower.mesh.position) <= radius + 1.5) enemy.revealedTimer = Math.max(enemy.revealedTimer || 0, 0.45);
      }
      if (Math.random() < dt * 5) addParticle(tower.fxAnchor.getWorldPosition(new THREE.Vector3()), 0x9fe8ff, { size: rand(0.04,0.08), velocity: new THREE.Vector3(rand(-0.25,0.25), rand(0.25,0.7), rand(-0.25,0.25)), life: 0.28, drag: 0.9 });
    }
    for (const zone of game.terrainZones) {
      if (zone.kind === 'crystal' && tower.mesh.position.distanceTo(new THREE.Vector3(zone.x, 0, zone.z)) <= zone.radius) {
        tower.buffDamageBonus = Math.max(tower.buffDamageBonus, zone.buff * 0.72);
      }
    }
  }

  const restoreRanges = [];
  for (const tower of game.towers) {
    if (v19SupportTypes.has(tower.type)) {
      restoreRanges.push([tower, tower.range]);
      tower.range = 0.01;
    }
  }
  _origUpdateTowers(dt);
  for (const [tower, range] of restoreRanges) tower.range = range;

  for (const tower of game.towers) {
    ensureTowerState(tower);
    const target = chooseTarget(tower);
    if (tower.type === 'mine') {
      tower.mineCooldown = (tower.mineCooldown || 0) - dt;
      if (tower.mineCooldown <= 0 && target) {
        tower.mineCooldown = Math.max(1.25, 3.45 - tower.level * 0.22 - tower.routeLevel * 0.08);
        const pos = target.mesh.position.clone(); pos.y = 0.12;
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.18, 10), new THREE.MeshStandardMaterial({ color: 0x413225, emissive: 0xe2b06a, emissiveIntensity: 0.35, metalness: 0.4 }));
        mesh.position.copy(pos);
        world.add(mesh);
        game.mines.push({ mesh, tower, radius: 2.25 + tower.level * 0.18 + tower.routeLevel * 0.08, damage: 30 + tower.level * 9 + tower.routeLevel * 4, life: 7.2 });
      }
    } else if (tower.type === 'flame') {
      tower.flameCooldown = (tower.flameCooldown || 0) - dt;
      if (target && tower.flameCooldown <= 0) {
        tower.flameCooldown = Math.max(0.12, tower.fireRate * (1 - (tower.buffFireRateBonus || 0)));
        const origin = tower.fxAnchor.getWorldPosition(new THREE.Vector3());
        if (tower.turret) tower.turret.lookAt(target.mesh.position.clone().add(new THREE.Vector3(0, 1, 0)));
        const radius = 2.35 + tower.level * 0.14 + tower.routeLevel * 0.07;
        for (const enemy of game.enemies) {
          if (!enemy.dead && enemy.mesh.position.distanceTo(target.mesh.position) <= radius) {
            applyDamage(enemy, tower.damage * 0.82, tower);
            enemy.burnTimer = Math.max(enemy.burnTimer, 1.55 + tower.routeLevel * 0.12);
            enemy.burnDamage = Math.max(enemy.burnDamage || 0, tower.damage * 0.34);
          }
        }
        for (let i = 0; i < 5; i++) addParticle(origin.clone(), 0xffae63, { size: rand(0.055,0.12), velocity: new THREE.Vector3(rand(0.9,2.2), rand(-0.1,0.65), rand(-0.55,0.55)).applyAxisAngle(new THREE.Vector3(0,1,0), tower.turret ? tower.turret.rotation.y : 0), life: 0.22, drag: 0.88, flicker: true });
      }
    } else if (tower.type === 'barracks') {
      tower.spawnCooldown = (tower.spawnCooldown || 0) - dt;
      const activeFighters = game.fighters.filter(f => f.tower === tower).length;
      const maxFighters = 1 + Math.floor((tower.level + tower.routeLevel) / 2);
      if (tower.spawnCooldown <= 0 && activeFighters < maxFighters) {
        tower.spawnCooldown = Math.max(2.8, 5.6 - tower.level * 0.32 - tower.routeLevel * 0.16);
        const group = new THREE.Group();
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.48, 4, 8), new THREE.MeshStandardMaterial({ color: 0xddfff0, roughness: 0.72 }));
        group.add(body);
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.46, 0.05), new THREE.MeshStandardMaterial({ color: 0xd8eaff, metalness: 0.62, roughness: 0.25 }));
        blade.position.set(0.2, 0.18, 0); group.add(blade);
        group.position.copy(tower.mesh.position).add(new THREE.Vector3(rand(-0.8, 0.8), 0, rand(-0.8, 0.8)));
        world.add(group);
        game.fighters.push({ mesh: group, tower, damage: 8 + tower.level * 2.2 + (tower.fighterDamageBonus || 0), speed: 7.6, life: 8.4 + tower.level * 0.5, cooldown: 0 });
      }
    }
  }

  for (const mine of [...game.mines]) {
    mine.life -= dt;
    mine.mesh.rotation.y += dt * 2.2;
    let detonated = false;
    for (const enemy of game.enemies) {
      if (!enemy.dead && enemy.mesh.position.distanceTo(mine.mesh.position) <= mine.radius) {
        for (const hit of game.enemies) {
          if (!hit.dead && hit.mesh.position.distanceTo(mine.mesh.position) <= mine.radius + 0.45) applyDamage(hit, mine.damage * (hit === enemy ? 1 : 0.62), mine.tower);
        }
        explode(mine.mesh.position.clone().add(new THREE.Vector3(0,0.15,0)), 0xffc980, 20, 1.9, { size: rand(0.06,0.16), life: 0.34, gravity: 0.35, drag: 0.92 });
        detonated = true;
        break;
      }
    }
    if (detonated || mine.life <= 0) { world.remove(mine.mesh); game.mines.splice(game.mines.indexOf(mine), 1); }
  }

  for (const fighter of [...game.fighters]) {
    fighter.life -= dt;
    fighter.cooldown -= dt;
    const nearby = game.enemies.filter(e => !e.dead && e.mesh.position.distanceTo(fighter.mesh.position) <= 5.5).sort((a, b) => a.mesh.position.distanceTo(fighter.mesh.position) - b.mesh.position.distanceTo(fighter.mesh.position));
    if (nearby[0]) {
      const target = nearby[0];
      const dir = target.mesh.position.clone().sub(fighter.mesh.position); dir.y = 0;
      const dist = dir.length();
      if (dist > 1.15) { dir.normalize(); fighter.mesh.position.addScaledVector(dir, fighter.speed * dt); fighter.mesh.lookAt(target.mesh.position.x, fighter.mesh.position.y, target.mesh.position.z); }
      else if (fighter.cooldown <= 0) { fighter.cooldown = 0.62; applyDamage(target, fighter.damage, fighter.tower); target.stunTimer = Math.max(target.stunTimer || 0, 0.035); }
    }
    fighter.mesh.position.y = Math.abs(Math.sin(game.time * 8 + fighter.mesh.position.x * 0.1)) * 0.06;
    if (fighter.life <= 0) { world.remove(fighter.mesh); game.fighters.splice(game.fighters.indexOf(fighter), 1); }
  }
};

updateEnemies = function(dt) {
  for (const enemy of [...game.enemies]) {
    enemy.anim += dt * 8;
    enemy.revealedTimer = Math.max(0, (enemy.revealedTimer || 0) - dt);
    if (enemy.slowTimer > 0) { enemy.slowTimer -= dt; if (enemy.slowTimer <= 0) enemy.slowFactor = 1; }
    if (enemy.stunTimer > 0) enemy.stunTimer -= dt;
    if (enemy.burnTimer > 0) { enemy.burnTimer -= dt; enemy.hp -= (enemy.burnDamage || 0) * dt; }
    if (enemy.poisonTimer > 0) { enemy.poisonTimer -= dt; enemy.hp -= (enemy.poisonDamage || 0) * dt; }
    if (enemy.hp <= 0 && !enemy.dead) { enemy.dead = true; game.gold += enemy.reward; }

    enemy.abilityTimer -= dt;
    if (enemy.ability === 'cloak') {
      enemy.isCloaked = enemy.revealedTimer <= 0 && Math.sin(game.time * 2.3 + enemy.anim) > 0.82;
      enemy.mesh.traverse(obj => { if (obj.material && obj.material.opacity !== undefined) { obj.material.transparent = enemy.isCloaked; obj.material.opacity = enemy.isCloaked ? 0.38 : 1; } });
    } else if (enemy.ability === 'shield' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 8.6;
      enemy.shield = Math.max(enemy.shield || 0, 42 + game.wave * 2.2);
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xc7b0ff, 1.1, 9, 0.14);
    } else if (enemy.ability === 'heal') {
      enemy.healTick += dt;
      if (enemy.healTick >= 1.65) {
        enemy.healTick = 0;
        for (const other of game.enemies) if (!other.dead && other !== enemy && other.mesh.position.distanceTo(enemy.mesh.position) <= 4.7) other.hp = Math.min(other.maxHp, other.hp + 9 + game.wave * 0.45);
        addParticle(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.3, 0)), 0x87ffc2, { size: 0.08, velocity: new THREE.Vector3(0, 0.5, 0), life: 0.32, drag: 0.94 });
      }
    } else if (enemy.ability === 'burrow') {
      enemy.burrowPhase += dt;
    } else if (enemy.ability === 'fortify' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 9.0;
      for (const other of game.enemies) if (!other.dead && other.mesh.position.distanceTo(enemy.mesh.position) <= 5.6) other.shield = Math.max(other.shield || 0, 24 + game.wave * 0.75);
    } else if (enemy.ability === 'boss' && enemy.abilityTimer <= 0) {
      enemy.abilityTimer = 11.5;
      const maxNodes = game.wave >= 60 ? 2 : 1;
      if (game.bossNodes.length < maxNodes) {
        const node = new THREE.Mesh(new THREE.OctahedronGeometry(0.58, 0), new THREE.MeshStandardMaterial({ color: 0xf1e8ff, emissive: 0xa27cff, emissiveIntensity: 1.0, metalness: 0.3, roughness: 0.16 }));
        node.position.copy(enemy.mesh.position).add(new THREE.Vector3(rand(-4,4), 1.2, rand(-4,4)));
        world.add(node);
        game.bossNodes.push({ mesh: node, hp: 90 + game.wave * 2.6, owner: enemy, spin: rand(0.8, 1.6) });
      }
      if (Math.random() < 0.72) {
        const summonType = Math.random() > 0.5 ? 'shadeRunner' : 'riftPriest';
        const def = makeEnemyDef(summonType, 0.78 + game.wave * 0.006);
        def.lane = enemy.lane || 1;
        def.wasSummoned = true;
        createEnemy(def);
      }
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.8, 0)), 0xffa372, 1.6, 14, 0.16);
    }

    for (const zone of game.terrainZones) {
      const distZone = Math.hypot(enemy.mesh.position.x - zone.x, enemy.mesh.position.z - zone.z);
      if (distZone <= zone.radius) {
        if (zone.kind === 'swamp') { enemy.slowFactor = Math.min(enemy.slowFactor, 0.68); enemy.slowTimer = Math.max(enemy.slowTimer, 0.28); }
        else if (zone.kind === 'lava') enemy.hp -= 7.5 * dt;
        else if (zone.kind === 'rift') enemy.distance = Math.max(0, enemy.distance - 0.34 * dt);
      }
    }

    enemy.distance += enemy.speed * enemy.slowFactor * (enemy.stunTimer > 0 ? 0 : 1) * dt;
    if (enemy.ability === 'burrow' && Math.sin(enemy.burrowPhase * 2.2) > 0.88) enemy.distance += 4.2 * dt;
    const laneLength = getLengthForLane(enemy.lane || 0);
    const curve = getCurveForLane(enemy.lane || 0);
    const t = THREE.MathUtils.clamp(enemy.distance / laneLength, 0, 1);
    const point = curve.getPointAt(t);
    const look = curve.getPointAt(Math.min(0.999, t + 0.002));
    enemy.mesh.position.set(point.x, 0, point.z);
    const bob = Math.sin(enemy.anim * 1.8) * (enemy.hover ? 0.22 : 0.09);
    const funnyTilt = Math.sin(enemy.anim * 2.4) * (enemy.phase === 'boss' ? 0.18 : 0.07);
    enemy.mesh.position.y = (enemy.hover ? 0.52 : 0) + bob + (enemy.ability === 'burrow' ? -Math.abs(Math.sin(enemy.burrowPhase * 2.2)) * 0.26 : 0);
    enemy.mesh.lookAt(look.x, 0.2 + funnyTilt * 0.5, look.z);
    enemy.mesh.rotation.z = funnyTilt * 0.6;
    if (enemy.walkers) enemy.walkers.forEach((part, i) => { part.rotation.x = Math.sin(enemy.anim * 1.6 + i * 1.1) * (0.65 + (enemy.phase === 'miniBoss' ? 0.3 : 0)); part.position.y = Math.sin(enemy.anim * 2.1 + i) * 0.08; });
    if (enemy.swayers) enemy.swayers.forEach((part, i) => { part.rotation.y = Math.sin(enemy.anim * 1.1 + i * 0.7) * 0.38; if (enemy.phase === 'boss') { part.rotation.z += dt * 0.28; part.rotation.x = Math.sin(enemy.anim * 1.9) * 0.25; } });
    if (enemy.aura) { enemy.aura.scale.setScalar(0.92 + Math.sin(game.time * 4.2 + enemy.anim) * 0.14); enemy.aura.rotation.z += dt * (0.55 + (enemy.phase === 'boss' ? 0.4 : 0)); }
    enemy.healthFg.scale.x = Math.max(0.01, enemy.hp / enemy.maxHp);
    enemy.healthFg.position.x = -((1 - enemy.hp / enemy.maxHp) * enemy.healthWidth) / 2;

    if (t >= 1) {
      enemy.reached = true;
      game.lives -= enemy.phase === 'boss' ? 8 : enemy.phase === 'miniBoss' ? 4 : ['batteringRam','warWagon','plagueCart'].includes(enemy.type) ? 3 : enemy.type === 'brute' ? 3 : enemy.type === 'knight' ? 2 : 1;
      removeEnemy(enemy);
      game.screenShake = Math.max(game.screenShake, 0.18);
      showMessage('The gate is hit!');
      if (game.lives <= 0) { game.lives = 0; game.gameOver = true; showMessage('Blackwall has fallen'); }
    } else if (enemy.dead) removeEnemy(enemy);

    if (enemy.hp <= enemy.maxHp * 0.42 && !enemy.enraged && (enemy.phase === 'miniBoss' || enemy.phase === 'boss' || game.wave >= 18)) {
      enemy.enraged = true;
      enemy.speed *= enemy.phase === 'boss' ? 1.06 : 1.1;
      addFlashLight(enemy.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xff6b6b, 1.0, 8, 0.14);
    }
  }

  for (const node of [...game.bossNodes]) {
    node.mesh.rotation.y += dt * node.spin;
    node.mesh.position.y += Math.sin(game.time * 2.5 + node.spin) * 0.002;
    const towersNear = game.towers.filter(t => t.mesh.position.distanceTo(node.mesh.position) <= 5.2);
    node.hp -= dt * (8 + towersNear.length * 28);
    if (!node.owner || node.owner.dead) node.hp = 0;
    if (node.hp <= 0) {
      explode(node.mesh.position.clone(), 0xcab8ff, 18, 1.7, { size: 0.08, life: 0.32, drag: 0.9 });
      world.remove(node.mesh);
      game.bossNodes.splice(game.bossNodes.indexOf(node), 1);
    }
  }
};

const v19UpdateHUDPrev = updateHUD;
updateHUD = function() {
  v19UpdateHUDPrev();
  if (game.selectedTower) {
    const t = game.selectedTower;
    if (t.routeLocked) ui.towerDetails.innerHTML += '<br><strong>Route locked</strong>';
    if (v19SupportTypes.has(t.type)) ui.towerDetails.innerHTML += '<br><em>Support towers now use dedicated behavior, not duplicate basic shots.</em>';
  }
};

const v19StartWavePrev = startWave;
startWave = function() {
  const before = game.wave;
  v19StartWavePrev();
  if (game.wave !== before && game.wave === 25) {
    game.gold += 140;
    showMessage('Second lane opens · emergency war chest +140');
  }
};

  renderer.domElement.addEventListener('mousemove', e => pick(e, false));
  renderer.domElement.addEventListener('pointermove', e => pick(e, false));
  renderer.domElement.addEventListener('click', e => pick(e, true));

  ui.startWaveBtn.addEventListener('click', startWave);
  ui.pauseBtn.addEventListener('click', () => {
    game.paused = !game.paused;
    ui.pauseBtn.textContent = game.paused ? 'Resume' : 'Pause';
  });
  ui.speedBtn.addEventListener('click', () => {
    game.speed = game.speed === 1 ? 2 : 1;
    ui.speedBtn.textContent = `${game.speed}x Speed`;
  });
  ui.upgradeBtn.addEventListener('click', upgradeSelectedTower);
  ui.sellBtn.addEventListener('click', sellSelectedTower);

  document.querySelectorAll('.towerBtn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.towerBtn').forEach(x => x.classList.remove('selected'));
      btn.classList.add('selected');
      game.selectedBuild = btn.dataset.type;
    });
  });


  window.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'b' && buildLaneOverlay) {
      buildLaneOverlay.visible = !buildLaneOverlay.visible;
      showMessage(buildLaneOverlay.visible ? 'Build lanes shown' : 'Build lanes hidden');
    }
  });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  buildScene();
  updateHUD();
  showMessage('Blackwall Siege ready');
  animate();
})();
